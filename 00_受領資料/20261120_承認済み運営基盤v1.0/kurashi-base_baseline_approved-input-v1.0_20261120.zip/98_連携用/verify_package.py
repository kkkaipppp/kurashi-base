from pathlib import Path
import argparse, csv, hashlib, json
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--baseline',action='store_true');args=p.parse_args()
manifest=json.loads((root/'98_連携用/package_manifest.json').read_text(encoding='utf-8'))
missing=[]; changed=[]
for rel,sha in manifest['files'].items():
    f=root/rel
    if not f.is_file(): missing.append(rel)
    elif args.baseline and hashlib.sha256(f.read_bytes()).hexdigest()!=sha: changed.append(rel)
with (root/'00_プロジェクト管理/意思決定台帳.csv').open(encoding='utf-8-sig',newline='') as f:
    dec=list(csv.DictReader(f))
assert {x['ID'] for x in dec if x['状態']=='確定'} >= {f'DEC-{i:02}' for i in range(1,11)}
print(json.dumps({'missing':missing,'baseline_changed':changed,'baseline_check':args.baseline,'meaning':'management package only; not product QA'},ensure_ascii=False,indent=2))
raise SystemExit(1 if missing or changed else 0)
