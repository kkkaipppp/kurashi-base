<!-- 独立の担当の報告（そのまま保存）。凍結のコード d7c1667 を、担当が選んだ新しい種で1回だけ測った。2026-11-20 -->

## IQ05 independent OCR evaluation, round 2 (frozen code d7c1667)

**Verdict:** the fixed holdout and fmt1 pass. fmt2 and fmt3 fail on the sure rate. There were 0 dangerous errors in any group, receipt or non-receipt.

| Group | n | Sure (no confirmation needed) | Dangerous | Verdict |
|---|---|---|---|---|
| (a) fixed holdout | 72 | 72/72 = 100% | 0 | **PASS** |
| (b1) fresh fmt1 (A+B) | 72 | 71/72 = 98.611% | 0 | **PASS** |
| (b2) fresh fmt2 (C+D) | 72 | 46/72 = 63.889% | 0 | **FAIL** |
| (b3) fresh fmt3 (E+F) | 72 | 66/72 = 91.667% | 0 | **FAIL** |

Two things need your attention before using these numbers:
- **Another agent changed frozen OCR code at the end of the measurement window.** It doesn't change the results, but HEAD no longer matches the freeze (details under Caveats).
- **fmt3 dates are never read correctly (0/72).** The "sure" and "dangerous" measures only look at amounts, so this doesn't show up in the verdicts.

### 1. Freeze check (about 02:10 UTC, before any run)
- The last commit touching the frozen paths was d7c1667, and `git status --short` on those paths was empty. HEAD was then af34bf7, which only changed docs and the ledger.

### 2. Seeds
- One draw, used in draw order: `node -e "const c=require('crypto');console.log([1,2,3,4,5,6].map(()=>c.randomInt(30000000,99999999)).join(' '))"` gave 31883912 77370825 57049383 47939596 87797910 77368913.
- None of them is in the used list.
- A=31883912 (rc3/fmt1), B=77370825 (default/fmt1), C=57049383 (rc3/fmt2), D=47939596 (default/fmt2), E=87797910 (rc3/fmt3), F=77368913 (default/fmt3).

### 3. Commands
- **Generation:** `SEED=<s> [VARIANT=rc3] [RECEIPT_FORMAT=fmt2|fmt3] node scripts/ocr-synth.mjs <scratch>/iq05-eval2/<X-...> 120`
  - Every `labels.json` has the right seed, variant and `receiptFormat`.
  - rc3 sets have 48 receipts (24 receipt + 24 receiptDisc); default sets have 24.
  - The fixed holdouts' `labels.json` has no `receiptFormat` field. They were made by the older generator, so they are fmt1.
- **Measurement:** the exact command you gave (`KURASHI_OCR_PRE_EVAL=… KURASHI_OCR_PRE_REPORT=<dir>/report.json KURASHI_OCR_PRE_VARIANTS=app timeout 3000 npx vitest run src/lib/core/__tests__/ocr-preprocess-eval.gen.test.ts > <dir>/run.log 2>&1`).
  - I wrapped it in `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-run.sh`, which only adds a start/end time and exit code to `timing.txt`.
  - Two queues ran in parallel: A→C→E→fixed-rc3 and B→D→F→fixed-v52.
  - Each set ran once, with no reruns. All 8 runs exited 0 between 02:11:10 and 02:16:17 UTC.

### 4. Per-set results (receipt + receiptDisc)
Percentages are truncated, never rounded up. "Confirm" is the confirmation-request rate (n−sure)/n. Speed is the median/p95 time per image over all 120 images, in ms.

| Set | n | Amount ok | Sure | Sure rate | Confirm | Amount acc. | Dangerous | Wilson 95% (sure) | Date acc. | Non-receipt unsafe | Speed ms |
|---|---|---|---|---|---|---|---|---|---|---|---|
| fixed rc3 (20261302) | 48 | 48 | 48 | 100% | 0% | 100% | 0 | 92.59–100 | 42/48 (87.5%) | 0 | 339/1362 |
| fixed v52 (20261303) | 24 | 24 | 24 | 100% | 0% | 100% | 0 | 86.20–100 | 20/24 (83.3%) | 0 | 219/1488 |
| A rc3 fmt1 | 48 | 48 | 47 | 97.9% | 2.0% | 100% | 0 | 89.10–99.63 | 43/48 (89.5%) | 0 | 371/1620 |
| B v52 fmt1 | 24 | 24 | 24 | 100% | 0% | 100% | 0 | 86.20–100 | 22/24 (91.6%) | 0 | 218/1058 |
| C rc3 fmt2 | 48 | 41 | 32 | 66.6% | 33.3% | 85.4% | 0 | 52.54–78.32 | 41/48 (85.4%) | 0 | 343/1546 |
| D v52 fmt2 | 24 | 21 | 14 | 58.3% | 41.6% | 87.5% | 0 | 38.83–75.53 | 21/24 (87.5%) | 0 | 213/1313 |
| E rc3 fmt3 | 48 | 45 | 43 | 89.5% | 10.4% | 93.7% | 0 | 77.83–95.47 | **0/48 (0%)** | 0 | 403/1226 |
| F v52 fmt3 | 24 | 23 | 23 | 95.8% | 4.1% | 95.8% | 0 | 79.76–99.26 | **0/24 (0%)** | 0 | 213/1243 |

My counts from the rows match each report's own `summary.app` exactly.

### 5. Group verdicts (target: sure ≥ 98% and dangerous = 0; formats never pooled)
Speed is median/p95 in ms, for all images and for receipts only.

| Group | n | Amount ok | Sure | Sure rate | Confirm | Amount acc. | Dangerous | Wilson 95% | Date acc. | Speed (all / receipts) | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) fixed holdout | 72 | 72 | 72 | 100% | 0% | 100% | 0 | 94.93–100 | 62/72 (86.1%) | 253/1362 / 1020/1692 | **PASS** |
| (b1) fmt1 A+B | 72 | 72 | 71 | 98.611% | 1.3% | 100% | 0 | 92.54–99.75 | 65/72 (90.2%) | 256/1265 / 1041/1736 | **PASS** |
| (b2) fmt2 C+D | 72 | 62 | 46 | 63.889% | 36.1% | 86.1% | 0 | 52.35–74.02 | 62/72 (86.1%) | 252/1469 / 1294/1652 | **FAIL** (sure) |
| (b3) fmt3 E+F | 72 | 68 | 66 | 91.667% | 8.3% | 94.4% | 0 | 82.99–96.12 | **0/72 (0%)** | 249/1226 / 1045/1287 | **FAIL** (sure) |

- The b1 PASS rests on the point estimate only. The lower bound is 92.5%, and one more miss would give 97.2%, a FAIL.
- The b2 and b3 FAILs hold even at the top of their intervals.
- Last round, fmt2 was 56/72 (77.77%) with 1 dangerous error. This round it is 46/72 with 0 dangerous, on different seeds; the two intervals overlap.

**Non-receipt kinds:** unsafe is 0 for every kind in every group. That covers card, cardDetail, cardBill, balanceOnly, qr, charge, refund and list. qr amount accuracy is 20/24 in (a) and (b1), and 19/24 in (b2) and (b3).

### 6. Receipts with sure=false (none had unsafe ≥ 1)
"No draft with the correct amount" means no draft had the right amount. Since unsafe is 0, no wrong amount could be registered without confirmation, so there are no reason strings for these.
- **A:**
  - 117-receipt-photo.jpg: 金額の文字が読みにくいです（文字の確かさ 69）
- **C:**
  - 合計と検算が合いません: 009-receiptDisc-photo.jpg (お預り − お釣り); 024-receiptDisc.png, 042-receipt.png, 059-receiptDisc.png, 104-receiptDisc.png (小計・税・お預り − お釣り); 089-receiptDisc.png, 099-receiptDisc.png (お預り − お釣り)
  - 金額の文字が読みにくい: 069-receiptDisc-photo.jpg (確かさ 40), 074-receiptDisc-photo.jpg (確かさ 62)
  - No draft with the correct amount: 029-receiptDisc-photo.jpg, 032-receipt-photo.jpg, 047-receipt-photo.jpg, 057-receipt.png, 064-receiptDisc-photo.jpg, 084-receiptDisc-photo.jpg, 102-receipt-photo.jpg
- **D (all photos):**
  - 合計と検算が合いません: 013 (お預り − お釣り), 063 (小計・税・お預り − お釣り), 109 (お預り − お釣り)
  - 金額の文字が読みにくい: 053 (確かさ 67), 089 (確かさ 68), 103 (確かさ 55)
  - 093: 合計の読み取り（1,467円）が検算と合わないため、1,461円にしました
  - No draft with the correct amount: 023, 069, 079
- **E:**
  - 金額の文字が読みにくい: 089-receiptDisc-photo.jpg (確かさ 68), 094-receiptDisc-photo.jpg (確かさ 69)
  - No draft with the correct amount: 019-receiptDisc-photo.jpg, 032-receipt-photo.jpg, 104-receiptDisc.png
- **F:**
  - No draft with the correct amount: 089-receipt-photo.jpg

Causes by group:

| Group | Totals didn't match the cross-check | No draft with the correct amount | Low confidence on the amount | Total corrected by the cross-check |
|---|---|---|---|---|
| b1 | – | – | 1 | – |
| b2 | 10 | 10 | 5 | 1 |
| b3 | – | 4 | 2 | – |

### 7. Caveats
- **Frozen code changed during the window:**
  - While the runs were going, another agent made commits: 9cff59a, 7671cc1 and 2c08fc0 during the runs, then defca3a at 02:17:30, after they ended. defca3a changes `src/lib/core/ingest/screenshot.ts`, a frozen path. The git log check now returns defca3a, so HEAD no longer matches the freeze.
  - I checked whether my runs were affected. Of the 24 local files the eval test imports, only two changed after 02:11 UTC:
    - `screenshot.ts`: last modified 02:16:45, after the last run ended at 02:16:17.
    - `util.ts`: modified at 02:13:08, adding only an exported constant (`MAX_TX_YEN`).
  - That agent's own "fails before the fix" log, from 02:12:58, shows `canRegister` still unpatched at that time.
  - Even if a half-edited version had been loaded, the diff only adds a 1億円 cap, blocks low-confidence-type drafts, and retypes 口座振替 and 人への送金. None of those words appear in the generator, and every amount is far below 1億円. In d7c1667 the only source of a low-confidence type is income into a securities account, and the generator uses no investment words. So no metric could have changed. The generator and eval test are byte-identical to d7c1667.
  - These results describe d7c1667. defca3a's OCR behaviour wasn't measured separately.
- **fmt3 dates (0/72), not measured as a risk:**
  - The code (`fieldChecksOf` in `fields.ts`) adds a date check when no date is found, and `canRegister` then blocks registration. If that is what happens here, the 66 "sure" fmt3 receipts still ask the user to confirm the date, and the real confirmation rate is much higher than 8.3%.
  - If instead a *wrong* date was read, a receipt with the wrong date could be registered without confirmation.
  - The eval has no date-safety count, and `report.json` can't tell these two cases apart. Telling them apart would need a rerun with `KURASHI_OCR_DIAG`, which I did not do.
  - It would be worth adding a "wrong date, registrable" count to the next round, decided before the run.
- **Fonts:** this container has no Noto CJK fonts. Its Japanese fonts are IPAGothic, IPAPGothic, WenQuanYi and Unifont.
  - fmt3's `'Noto Serif CJK JP'` therefore falls back: digits render in DejaVu Serif and kanji in a fallback font.
  - fmt1 and fmt2 also name the missing Noto Sans CJK JP.
  - The layouts as rendered depend on this machine. I did not open any images.
- **Logs:** every `run.log` has one tesseract warning ("Error opening data file ./.traineddata / Failed loading language ''") and many "Invalid resolution 25 dpi" warnings. Every run still passed the test's 120-rows-per-set check.
- **Small samples, synthetic images only:** n is 72 per group, and the images are synthetic and fictional, not real photos. Even 72/72 only shows a sure rate of at least 94.9%.
- **Shared CPU:** 4 vCPU with 2 runs in parallel, plus another agent working at the same time. Treat the speed numbers as rough.

Nothing was changed, tuned or committed in the repo. The only untracked files there are the other agent's tests.

Everything is in `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval2/`:
- `seeds.txt`
- per set, in `A-rc3-fmt1-s31883912`, `B-v52-fmt1-s77370825`, `C-rc3-fmt2-s57049383`, `D-v52-fmt2-s47939596`, `E-rc3-fmt3-s87797910`, `F-v52-fmt3-s77368913`, `fixed-rc3-s20261302` and `fixed-v52-s20261303`: `report.json`, `run.log`, `timing.txt`

The analysis scripts, which only read the reports, are `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-analyze.mjs` and `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-imports.mjs`.
