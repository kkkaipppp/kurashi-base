<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

**IQ02 oracle is on N3-d: 162 tests, 162 pass, 0 fail.** No new discrepancy (no N5): the implementation matches the N3-d model in every hand test, all 40 random worlds and the cross-screen checks. Nothing committed; `impl.ts` and the implementation are untouched, and I read no implementation source.

**Baseline before my changes:** the old model failed 9 of 135 against the current implementation. Two were the old "later amount wins" hand tests. The rest were random seeds 2, 5, 8, 10 and 19, plus the `invariant:base` and `invariant:credit` random checks. The shrunk repros I looked at (seeds 2, 8, 10, 19) all have two payments with the same operation key and different amounts. The old model merged them into one row; the implementation keeps two, as N3-d requires. All 9 follow from the rule change.

**Files changed** (all under `/home/user/kabu-hantei/kurashi-calendar/`):
- `src/lib/core/__tests__/iq02/model.ts`: payment rows are keyed by (operation key, amount); the key is unchanged from N3-c. The N3-b allowance only applies when an identical row is already live. Cancelling goes through the row the op was recorded as.
- `src/lib/core/__tests__/iq02/sim.ts`: generator settings are now explicit (`GenOpts`). Defaults keep the main suite's mix.
  - Identical re-sends now use the original op's account and prefer an op whose row is still live.
  - Same-dialog ops with a different amount use `allowOverpay` 30% of the time.
  - An optional double tap re-sends an accepted payment in the next slot.
  - The cancel picker only picks accepted ops.
- `src/lib/core/__tests__/iq02-independent-oracle.test.ts`: the ACC08 block is renamed "N3-d: payment row = operation key + amount". There is a new payment-focused random block, and two N3-d markers were added to the main coverage list.
- `src/lib/core/__tests__/iq02/REPORT.md`: N3-d added to the rules table. N3-c's "same key = same row, later amount wins" and N3-b's old allowance are struck through as superseded. New readings R9–R11, a section on what changed with its own table, and the result.
- `quality/evidence/rcr-iq02/iq02-n3d-vitest.log`: the exact command's output, plus a verbose run listing each test.

**Hand tests** (statement 10,000 and bank A 200,000 unless noted; "sequential" means the second op reuses the first dialog's key but is checked on the current data):

| Test | Expected | Reasoning |
| --- | --- | --- |
| Example 1 (new): statement 80,000, both devices compute on the same stale data, 80,000 and 79,000 | Both accepted; two rows; linked 159,000; overpaid; remaining −79,000; A 41,000; card −79,000 (overpaid 79,000); no open bill | Each is ≤ 80,000 on the stale data. Same key, different amounts, so two rows. Same result in either sync order, and when device 1's change arrives twice. |
| Example 2 (new): same, both 80,000 | One row; paid; A 120,000; card 0 | Same key and amount, so the same row. |
| Example 3a (rewrites "second device records 6,000 … later amount wins"): 10,000 then 6,000, sequential | 6,000 rejected; one row; paid; A 190,000 | Remaining 0, and no row (key, 6,000) exists, so no allowance. |
| Example 3b: as 3a with `allowOverpay` | Second row; overpaid; paid 16,000; remaining −6,000; A 184,000; card −6,000 | A different amount is a separate row; the excess is shown as overpaid. |
| Rewrite of "first 4,000 then 10,000": 4,000 / 10,000 / 4,000 / 6,000 / 6,000 / 11,000, sequential | ok / rejected / ok / ok / ok / rejected; rows 4,000 + 6,000; paid; A 190,000 | 10,000 > 6,000 left + 0. The repeated 4,000 and 6,000 are identical re-sends. 11,000 > 0 + 0. |
| Kept: both devices 10,000 | One row; A 190,000 | Same key and amount. |
| Kept: double tap 3,000 | One row; remaining 7,000; A 197,000 | Same key and amount. |
| Kept: RC-F05, new dialog after a partial payment | Two rows; paid | The second dialog has a different key. |
| Overpaid-row re-send (new) | After 3b, re-sending 10,000 is rejected without `allowOverpay` and ok with it; still two rows | N3-b as written: −6,000 + 10,000 = 4,000 < 10,000. |
| Pay 3,000, cancel, new dialog pays 3,000 (new; my reading R10) | Ok; live 3,000; A 197,000 | The new dialog gets the same key, so this is the cancelled row's identity. Recording it again makes it live rather than silently dropping it. |
| Model self-check (new) | Model reproduces example 1 sequentially with `allowOverpay` | Checks the model's row identity directly. |

**One new random block, because the main suite barely exercises N3-d.** The main 20 seeds produced only 4–7 same-dialog payments and no accepted identical re-send. Pushing those up inside the main suite dropped the clean-invariant coverage to 9, below the existing ≥ 10 threshold, so the main suite keeps its defaults (11). The new block runs seeds 21–40 × 50 ops with `{ sameDialog: 0.7, doubleTap: 0.4 }`, the same aspects plus D1/D2 and the cross-screen check. Its coverage test requires:
- identical re-sends (27)
- separate rows without and with `allowOverpay` (10 and 10)
- rejections (7)
- re-recording a cancelled row (4)

No existing assertion or threshold was loosened.

**Points that need a product decision.** The implementation already agrees with all three; they are my readings, not defects:
- **R9:** an identical re-send keeps the existing row. Which account or date wins when a re-send uses a different account is never tested.
- **R10:** a cancelled row recorded again from a new dialog becomes live.
- **R11:** on an overpaid statement, an identical re-send without `allowOverpay` is rejected. This follows from the N3-b wording and does no harm, since the row already exists once.

Also, true stale-state concurrency is covered only by the two hand examples; the random suites apply ops one after another.
