<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

## Storage / data-integrity review: kurashi-calendar

I did not edit the repo. I wrote scratch repro tests and ran them with the repo's vitest and fake-indexeddb: `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/review-storage/repro.test.ts` and `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/review-storage/repro2.test.ts`. The config is `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/review-storage/vitest.config.mts`. All 6 repro tests pass, so the defects they target are confirmed.

**Bottom line:** the old review's two claims are fixed in the normal build. One P0 is new: switching away from cloud mode while a cloud request is still running can overwrite the user's local data with cloud data. The old localStorage race still exists in the rollback ("bridge") build only.

### Findings

**P0-1. Leaving cloud mode while a cloud request is still running: cloud data replaces the local view, and the next local save overwrites the local IndexedDB record.** Confirmed by reading the code; I did not run it.
- **Where:** `src/lib/store/StoreProvider.tsx`
  - `loadCloud` (455-543) only checks `if (uidRef.current !== uid) return;` (504, 526). It never checks `modeRef`. It then calls `setData(replay(base, outbox))` (520), the cached-data `setData` in its catch block (536), or `setData(emptyDataset(...))` when there is no session (478).
  - `setMode` for local/demo (797-805) does not clear `uidRef`, `baseRef` or `retryTimer`.
  - The cloud effect cleanup clears the timer once (572). A `scheduleRetry()` (369-372) that runs after the cleanup survives. It then calls `flushRef` → `loadCloud` (547-549) every 20 s, in local mode.
  - `flush` calls `await loadRef.current()` after a 409/400 refusal (438). `transferIn` calls `await loadCloud()` at the end of a cloud transfer (756, 772).
  - The local save uses `revRef` from the local load and `dataRef` from the `data` effect (277-279, 615), so the version check passes.
- **Repro:**
  1. Have local-only records, plus a cloud account.
  2. In cloud mode on a slow network (or with `/api/dataset` delayed about 5 s), foreground or reload the app. This starts `loadCloud`.
  3. While the request is pending, go to Settings → データの置き場所 → この端末だけ → 切り替える. The local data loads from IndexedDB.
  4. The delayed response arrives and `loadCloud` calls `setData` with the cloud dataset. The "この端末だけ" screen now shows cloud data.
  5. Add any expense. `commitLocal('local', revRef, cloudData + expense)` succeeds. The original local-only rows are gone after a reload.
- **Variants:**
  - If the fetch fails, the cached cloud data is shown instead, and the retry loop keeps running in local mode.
  - If there is no session, the view becomes empty, and the next save leaves only the new row.
  - Demo mode works the same way, so real cloud data ends up in the demo record.
- **Suggested test:** browser E2E. Seed the local IndexedDB record, mock the session, delay `/api/dataset` with a route, switch mode, wait for the response, add one expense. Then assert the IndexedDB `local` record still has the original rows and no cloud rows. A unit alternative: jsdom + fake-indexeddb rendering `StoreProvider`, with `./cloud` mocked by deferred promises.
- **Fix idea:** abandon `loadCloud`/`flush` continuations when `modeRef.current !== 'cloud'` (or use a load-generation token). On a switch away from cloud, clear the retry timer and `uidRef`/`baseRef`.

**P1-2. Rollback build (`NEXT_PUBLIC_KURASHI_STORAGE_ROLLBACK=1`) still has the old same-version race. Both tabs report success and one change is lost.** Confirmed by a scratch test (`aOk true bOk true stored ['A']`).
- **Where:** `src/lib/store/local.ts:209-223` (`saveLocal`), used through `legacyCommit` (330-333) and `persist` (`StoreProvider.tsx:603-609`).
- **Why:** after writing, `saveLocal` re-reads and compares only `revOf(...) !== rev`. Both writers compute the same `current+1`, so the re-read cannot tell them apart. Even a full-string comparison cannot detect a write that landed before your own. Only a cross-tab lock (`navigator.locks`) fixes it.
- **Repro:** tab A checks the version, tab B saves completely, then A writes. Both are told "saved"; B's change is gone.
- **Suggested test:** unit, with a localStorage mock whose `getItem` hook runs the other tab's `saveLocal`. This is the same idea as `MemStorage.onGet` in `qr-p0-storage.test.ts`.

**P1-3. "クラウドへ移す" card says it is safe to delete local data, and "この端末側を消す" deletes it in one tap, even when local data was never sent.**
- **Where:**
  - `src/components/DataTransfer.tsx:24`: `useState(() => migratedAt())`.
  - `DataTransfer.tsx:36`: `markMigrated()`.
  - `DataTransfer.tsx:51-58`: the text "この端末側は消してかまいません" and a `resetLocal('local', today)` button with no confirmation.
  - `src/lib/store/local.ts:175-181`: `kurashi.local.migratedAt` is a single global key, never cleared, and not tied to an account or a local version.
- **Repro A:**
  1. Migrate local data to account A.
  2. Switch to この端末だけ and add records.
  3. Switch back to cloud. The card shows "クラウドへ移しました（old date）。この端末側は消してかまいません".
  4. Tap この端末側を消す. The new local-only records are wiped.
- **Repro B:** after migrating to A, sign in as B. The card says the data was migrated, but it never reached B.
- **Suggested test:** E2E covering the flow above. Expected: delete is refused or confirmed while the local version is newer than the migrated version, or the migrated marker is stored per account.

**P1-4. Double-tapping one-tap buttons that create new ids saves the operation twice (a duplicate expense).** Confirmed at the core level: two `recordFixedPayment` calls on the same data give 2 transactions and 2 occurrences for the same rule/date.
- **Where:**
  - `src/components/views/FixedViews.tsx:167`: `onClick={() => void saveChanges(recordFixedPayment(data, ruleId, date, now()), …)}`, with no busy guard and no fixed operation ID.
  - `src/lib/core/ops.ts:112-114`: `blankTransaction` → `newId()`.
  - `src/lib/core/ops.ts:325`: the occurrence gets `id: stored?.id ?? newId()`.
  - The `serial` queue (`StoreProvider.tsx:304-308`, 653-655) rebuilds `next` from the updated `dataRef`, and the version check passes because both saves come from the same tab.
- **Repro:** local mode with a large dataset (each save writes the whole dataset, which is slow), or CPU throttling. On a fixed cost, double-tap 「払った」. Result: two expenses, and two `recurring_occurrences` rows with the same rule/date. In cloud mode the second save is rejected by the unique constraint and shows up as a "受け付けられなかった" conflict.
- **Same pattern:** `TripsView.tsx:238` (inline todo `crypto.randomUUID()`), `EventEditor.tsx:164` (複製), `AccountsView.tsx:196` (請求の保存 `newId()`).
- **Not affected:** the main forms MoneyForm, NewEvent, EventEditor save and TodoView new are guarded.
- **Suggested test:** E2E with two `click({noWaitAfter:true})` plus CPU throttling, asserting a single row. Or a unit test asserting fixed-payment ids are deterministic (for example from rule|date), so the save is idempotent.

**P1-5 (low likelihood). The "読めなかったデータを書き出す" button can export the wrong data, and approving then destroys the actual unreadable record.** Confirmed by a scratch test: the export returned `OLD-INCIDENT`; after approving, `CURRENT-DATA` existed nowhere.
- **Where:** `src/lib/store/localdb.ts:426-429`: `const key = b?.backupKey ?? (await listUnreadable(kind))[0] ?? null; if (!key) return b ? legacyRaw(kind) : null;`.
- **Why:** when backing up the current unreadable IndexedDB record fails (for example a quota error), `backupKey` is null. The export then falls back to the newest older backup, or to the old localStorage marker. The recovery screen (`LocalRecovery.tsx:38, 44, 49-51`) asks the user to export first, reports "書き出しました", and approving overwrites the record (`localdb.ts:333-334`).
- **Fix idea:** when `backupKey` is null, export the current record via `readRecord`.

**P2 (lower impact or narrow windows):**

- **P2-6. Replay of an interrupted save can overwrite a newer edit of the same row, silently.** Confirmed: T went 100 → 300 saved later, then the stale 200 was replayed over it.
  - `replay.ts:14-20` applies `p.changes` to the current data with no check against the version or row timestamps the change was based on.
  - When a tab reloads because another tab saved, the reload is "quiet" (`StoreProvider.tsx:360`), so the replay notice is never shown.
  - Suggested test: unit, with pending entries plus a later commit, as in my repro.
- **P2-7. Interrupted-save entries survive "clear data".** Confirmed.
  - `clearLocal` and `resetDemo` (`StoreProvider.tsx:838-851`, `localdb.ts:358-361`) do not remove `*.pending.*` keys. The reload right after then replays an old change into the freshly wiped dataset.
  - Entries older than 7 days are only counted (`replay.ts:17`). No UI lets the user apply or discard them, so the notice repeats on every load.
- **P2-8. Approving after a `readfail` block leaves the old-version data stranded for good.** Confirmed.
  - The recovery screen offers the approve button for `readfail`; it hides it only for `unavailable` and `outdated` (`LocalRecovery.tsx:14`).
  - `approveLocalReset` then calls `commitLocalFresh` (`localdb.ts:326-328, 342-352`), which writes an empty record without the legacy marker.
  - After that, the old localStorage data is never migrated and no "data from the old version" notice appears.
- **P2-9. Switching local → cloud while a local save is running puts local data into the cloud view.**
  - The local save finishes with `dataRef.current = next; setData(next)` (657-658) after `setMode('cloud')` has already set cloud data (786-796).
  - If offline, that view stays, and edits to local-only rows are then queued and sent to the cloud account. The window is narrow.
- **P2-10. Possible account mixing (unconfirmed, narrow window).**
  - `flush`'s `onSent` and its final `writeCloudCache(uid, baseRef.current)` (388-391, 441) do not check the user. If B signs in while A's request is in flight, B's data plus A's change is written into A's offline cache.
  - `uidRef` is set to `lastUser()` at boot and in `setMode` (262, 791) without checking against the stored session. The offline branch (459-465) then adopts that user.
- **P2-11. Old-version tab write can be silently overwritten during the one-time upgrade.** `fenceLegacy` (`local.ts:293-296`) checks, then writes, without a lock. A write from an old-version tab landing in that gap is overwritten by the marker, and no divergence notice appears.
- **P2-12. Silent re-import of a stale snapshot.** If the IndexedDB record is missing but the "moved" marker in localStorage remains, the data is migrated again from that marker (data as of the original migration), with no warning (`localdb.ts:275-277`).
- **P2-13 (unconfirmed). "Complete" may not mean flushed to disk.** Transactions use the default durability (`localdb.ts:101`). Chrome's default is relaxed, so a save reported complete may not survive power loss. Consider `{durability:'strict'}` for data writes.
- **P2-14. Operation-ID store grows forever.** One record per save is added (`localdb.ts:166`; every commit gets an operation ID at `StoreProvider.tsx:655`) and never pruned.
- **P2-15. Writes are never validated, but reads reject the whole dataset over one bad row.**
  - The local save path never runs `recordProblem` before writing (`makeRecord` at 128-137).
  - On open, a single invalid row blocks the entire dataset and steers the user toward "新しく始める". I found no current code path that writes an invalid row.
- **P2-16. Restore error message can be wrong.** The cloud one-transaction restore says "何も入っていません" even when the response was lost after the server committed (752-753). Retrying is idempotent, so nothing is lost.

### Areas checked and believed safe
- **Normal local saves (localdb):** read, version compare, operation-ID record and put happen in one readwrite transaction. Success is resolved only in `oncomplete`; abort, error or a throw rejects. The old review's local.ts race claim is fixed for the normal build.
- **`ingestText` and ImportView:** a failed save is returned as failure and the paste box keeps the text (old claim fixed; covered by e2e QG04).
- **Duplicate saves after reloads:** the operation-ID store persists. Replay reuses the same operation ID, so it is applied once at most (verified).
- **useSave forms (AddSheet, EventEditor, TodoView new, NoteEditor):** they keep a stable operation ID until success, block re-entry while saving, and keep input on failure. MoneyForm has its own busy guard.
- **Migration from the old version:** old data is not deleted. The marker is written only after the copy is read back and matches. Old-version tabs are fenced (version 2 plus a version bump). Divergence is detected by signatures. Two tabs migrating at once produce one record.
- **Other-tab reloads:** they never reset form state. The version check plus row-level merge prevents unrelated changes being lost.
- **Restore into local mode:** a single checked save (all or nothing).
- **Cloud outbox:**
  - One key per entry, so concurrent appends are not lost.
  - Queues are kept per user, and sending checks the logged-in user, so A's queue is never sent as B.
  - Signing out keeps the queue.
  - A rejected entry is moved to the conflict list before it is removed from the queue, one key at a time.
  - "Mine" resends reuse a fixed `:mine` ID.
  - The in-memory server treats an identical `updatedAt` as not a conflict, so resends are idempotent. I did not check the SQL path.
- **`versionchange`** sets `outdated` and refuses writes; the input is kept.

### Test-validity gaps
- `rc3-local-protect.test.ts:232-250` (same-tab race) injects a write with `rev: 99`, a different number. It does not model two writers with the same version, which my repro shows still loses data.
- Quota is simulated by `put()` throwing synchronously in `qr-p0-storage.test.ts:129-144` and e2e QG04. Real browsers report quota as an asynchronous transaction abort when committing, so the abort-to-`'quota'` mapping is untested. The abort test accepts either `'abort'` or `'storage'`. The abort test would still catch success being reported before completion.
- Nothing tests StoreProvider itself: `persist`, the save queue, mode switching, `loadCloud` guards. P0-1 has no coverage. The e2e "デモに混ざらない" check only covers static separation.
- Replay unit tests run without `navigator.locks` (only the 5-second fallback), and do not cover stale replay over newer data or pending entries surviving a clear.
- The UI12 double-tap e2e covers only the guarded forms, not one-tap buttons like 固定費「払った」.
- `qr-p0-contract` source checks only catch syntax. For example, `void saveChanges(...)` followed by clearing state is matched only for back, router, onDone, `setEditing(false)` and onClose.

