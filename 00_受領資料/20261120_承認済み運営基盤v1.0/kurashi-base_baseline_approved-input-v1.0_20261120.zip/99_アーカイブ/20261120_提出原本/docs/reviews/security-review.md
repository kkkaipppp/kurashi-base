<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

## Security review: kurashi-calendar (Next 16.4.6, read-only)

I made no edits to the repo. I wrote one scratch PoC test at `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/review-security/poc/poc.test.ts` and ran it once from the repo root with `npx vitest run --config <that dir>/vitest.config.mts`. All 3 tests passed. It proves findings 1, 2 and 3. I found no Critical or High issues.

### 1. Medium: open redirect after the gate (`safeNext`), confirmed with PoC
- **Where:** `src/lib/server/gate.ts:79-80`. The result is used in `src/app/api/gate/route.ts:9` (`Location: new URL(to, req.url)`).
- **Evidence:** `if (!next || !next.startsWith('/') || next.startsWith('//') || next.startsWith('/\\') || ...) return '/'`
- **Why it fails:** the URL parser silently deletes TAB, LF and CR. So `"/\t/evil.example"` passes the check, then `new URL()` turns it into `https://evil.example/`. The same happens with `/\n/` and `/\t\\`.
- **Attack:** send a friend `https://<app>/gate?next=/%09/evil.example/login`. The GET gate page accepts the value, and `esc()` keeps the tab in the hidden input. The friend types the real code and gets a 303 to evil.example. A fake "session expired, log in again" page there can harvest their Supabase password.
- **PoC:** a POST with `next="/\t/evil.example/login"` returns a Location whose host is `evil.example`.
- **Fix:** resolve with `new URL(next, origin)`, require the origin to match, and return pathname + search. Or reject any control or whitespace character.
- **Test:** unit tests in `gate.test.ts` checking that `safeNext('/\t/evil.example')`, `'/\n/x'`, `'/\r\n/x'` and `'/\t\\x'` all return `'/'`. Plus a route-level test that the Location origin is always the app origin.

### 2. Medium: device keys skip every revocation path, and the server never checks the allowlist for them
- **Where:** `src/lib/server/auth.ts:123-136`. `requireDevice` only checks hash, scope and `revokedAt`. It never checks the owner's Auth status or `KURASHI_ALLOWED_EMAILS`.
- **What this means:** a friend who is removed from both lists, or Banned ("いったん止めるだけなら Ban", `docs/beta/BETA_SUPABASE_SETUP.md:136-137`), keeps working ingest, widget and backup keys. They can still write through `/api/ingest`, read `/api/widget/summary`, and download a full export through `/api/backup`.
  - Only deleting the Auth user cascades to `ingest_devices`.
  - **PoC:** after removing the email from the allowlist, `/api/dataset` returns 403 but `/api/widget/summary` with the old key returns 200.
- **Persistence after a stolen session:** `POST /api/ingest-devices` (`handlers.ts:358`) and `PUT /api/backup-key` (`handlers.ts:906`) need only a Bearer token, with no recent login.
  - An attacker with a stolen or phished session can register their own public key and mint a `kc_bk_` key.
  - `GET /api/backup` then returns all future data encrypted to the attacker's key, indefinitely.
  - Keys do not expire and are not revoked by a password change or by "sign out other devices".
- **Related gap:** the RLS policies only check `user_id = auth.uid()`. The allowlist and email-confirmed checks exist only in the API. A removed-but-not-deleted user with an unexpired JWT can still read and write their own rows directly through PostgREST. Whether a Banned user's existing access token stays valid until expiry is Supabase behaviour and unconfirmed.
- **Status:** confirmed from code. Only the Ban/JWT detail depends on the platform.
- **Fix:**
  - In `requireDevice`, check the owner (email allowed, not banned), with a short cache.
  - Revoke all of a user's keys when removing or banning them.
  - Require a recent login to issue keys or replace the backup key.
  - Optionally add key expiry.
- **Test:** MemoryRepo unit test: remove the email from the allowlist, then expect 403 from widget, ingest and backup. Integration test on local Postgres/Supabase: ban the user, then expect the device key to be rejected.

### 3. Low on Vercel, Medium elsewhere: gate brute-force protection is weak
- **Where:** `src/app/api/gate/route.ts:25-26` and `src/lib/server/rate-limit.ts:3`.
- **Evidence:** `const ip = (req.headers.get('x-forwarded-for') ?? '').split(',')[0].trim() || 'local'`, then `rateLimit(\`gate:${ip}\`, 10, 10*60*1000)`.
- **What is weak:**
  - The gate route does not use `clientIp()`, despite decision D12.
  - The limiter is in memory only, so each server instance counts separately and the count resets on a cold start.
  - There is no global cap and no DB limiter. The widget exchange has both (`handlers.ts:203,215`).
- **Spoofing `X-Forwarded-For`:**
  - Off Vercel, anyone can rotate the header to bypass the limit. PoC: 50 guesses with rotating `x-forwarded-for` gave 0 "limit" responses. With no header at all, every client shares one `'local'` bucket, so one attacker can lock everyone out.
  - On Vercel, Vercel's public docs say the edge overwrites `x-forwarded-for` and sets `x-real-ip` and `x-vercel-forwarded-for` to the client IP. Nothing in the repo verifies this, so it is unconfirmed.
- **Bypasses that work even on Vercel:**
  - The effective limit is 10 per 10 minutes multiplied by the number of warm instances.
  - IPv6 address rotation gives an unlimited number of keys.
  - Friends behind the same mobile carrier NAT can lock each other out.
- **Constant-time comparison:** yes. Both sides are SHA-256 hashed, then compared with `timingSafeEqual` (`gate.ts:39-43`).
- **Logging:** neither the code nor its hash is logged anywhere in the gate route, `gate.ts` or `proxy.ts`.
- **Cookie (question 2):**
  - It is `HttpOnly; SameSite=Lax; Secure` on https, HMAC'd, expiry-checked and compared in constant time.
  - It is bound to the code: rotating the code revokes every cookie.
  - However, the HMAC key is only `kurashi-gate-v1:${code}` (`gate.ts:19`). One stolen cookie lets an attacker guess the code offline with no rate limit. Using the same code on review and production makes cookies interchangeable between them.
- **Is 400 days OK?** It is acceptable only because the gate is a second layer behind Supabase login and the allowlist. I'd recommend 30–90 days, a separate server secret in the HMAC key, a minimum code length, and different codes for review and production.
- **Impact if bypassed:** the app shell, the JS bundle (which holds the anon key), `/api/health` and `/api/push/key`. No user data without a friend's login.
- **Test:** unit test with a fixed `x-vercel-forwarded-for` and varying `x-forwarded-for`; expect the 11th attempt to be limited. Also a global-cap test and an integration test of the DB limiter (`kurashi_rate_hit`).

### 4. Low: on a shared device, push stays bound to the previous account
- **Where:** `repo.ts:482` (`if (this.service) await ...delete().eq('endpoint', ...).neq('user_id', userId)`) and `handlers.ts:689`.
- **Why:** `handlers.ts:689` calls this through `u.repo`, which is not the service-role client, so the "take over a device's subscription" delete never runs in production. The upsert then hits A's row, fails the RLS `USING` check, and returns 500. That ON CONFLICT behaviour is documented Postgres; confirm it on a local DB.
- **Sign-out:** `signOut` (`StoreProvider.tsx:880-901`) does not unsubscribe push.
- **Result:** A keeps getting a daily digest on B's device. By default it shows counts only; with `KURASHI_PUSH_DETAIL=full` it shows amounts and titles.
- **Hidden by tests:** `MemoryRepo.savePushSubscription` (`repo.ts:791`) always removes the other owner's row, so unit tests miss this.
- **Test:** local Postgres integration: A subscribes endpoint E, B subscribes E, expect success and B as owner. E2E: sign out, expect the server row to be gone.

### 5. Low: account data left in localStorage after sign-out
- Sign-out only clears the cache key (`StoreProvider.tsx:891`, `clearCloudCache`).
- The outbox, conflict records, pending commits and note drafts (`kurashi.cloud.notedraft:<uid>:…`) stay in plaintext. This is by design so they can be resent later, but the next person using the same browser profile can read them in devtools.
- **Test:** E2E: change something while offline, sign out, then inspect localStorage.

### 6. Low: latent gap in the service-role path of `kurashi_apply_changes`
- **Where:** `supabase/migrations/20261119020000_v54_rc.sql:277`.
- **Evidence:** `... and x.user_id <> $2` evaluates to NULL for the shared default categories (`user_id is null`). A service-role upsert of a default-category id would overwrite it and take ownership, so it would disappear for everyone else.
- **Not reachable today:** the only service-role caller is ingest, and `planIngest` writes only `capture_events`, `transactions` and `ingest_parsing_candidates`, with server-generated ids.
- **Fix:** use `is distinct from`.
- **Test:** on local Postgres as service_role, call `kurashi_apply_changes` with a categories upsert for `00000000-0000-4000-8000-000000000001`; expect error 42501.

### 7. Low: login CSRF / session swap through email links
- `/auth/accept#access_token=…&refresh_token=…` (implicit flow) or a `token_hash` link is accepted from any link and signed in after one click (`cloud.ts:299-302`).
- An invited friend with bad intent can sign another friend's browser into the attacker's account, so the victim's entries land there.
- **Fix:** accept the PKCE `code` flow only, or show which email is being signed in and ask for confirmation.

### 8. Low / informational
- **`/api/health`:** sits behind the gate only, with no user login (`handlers.ts:551-664`). It reveals config flags and makes about 8 service-role requests to Supabase per call, which is cheap amplification for anyone with the code. Require a login or cache the result.
- **Cron secret:** compared with `!==` (`handlers.ts:752`), not in constant time. Not practically exploitable over the network.
- **Scriptable legacy setup:** saves the new URL to the Keychain before checking the key (`scriptable/kurashi-widget.js:638`). If a user is talked into entering an attacker's URL, their stored `kc_wg_` key is sent there on the next refresh.
- **CSP:** allows `'unsafe-inline'` scripts while Supabase tokens live in localStorage, so any XSS would mean account takeover. I found no XSS sinks: the only `dangerouslySetInnerHTML` is a static theme script, and user URLs are https-only by schema.

### Checked and OK
- **Owner derivation:** every user route gets the owner from `requireUser`, where Supabase verifies the token via `getUser`, never from the body. That covers dataset, mutate, restore, export, calendar, summary, transactions, report/year, backup-key, push subscribe/prefs/test, widget/link, ingest-devices, account and withdraw. The same function also enforces email confirmation and the allowlist; an empty allowlist in production fails closed with 503.
- **Service-role use:** every service-role call in the handlers filters by `u.userId` or `device.userId`. For example, `revokeDevice` filters on both id and user_id, and `deleteAllData` filters on user_id for every table.
- **`kurashi_apply_changes` / `kurashi_export_snapshot`:** both are SECURITY INVOKER. They reject `authenticated` callers when `auth.uid() <> p_user` and reject anon, and RLS still applies.
- **SECURITY DEFINER functions that take a user id** (issue/exchange link, `kurashi_ref_foreign`, `kurashi_rate_hit`, purge): EXECUTE is revoked from public, anon and authenticated and granted to service_role only. `kurashi_check_event_parent` is revoked in the `20261120…` migration.
- **Cross-owner references:** blocked by deferred `kurashi_check_refs_owner` triggers.
- **Table grants:** RLS is on for every table. `secret_hash` is not selectable by users. Link codes, rate events, the push report log and the invite list are hidden from anon and authenticated.
- **Device keys:** 256-bit random, stored as SHA-256, scope enforced by both prefix and DB column, revocation checked on every request.
- **Link codes:** 50-bit, 5-minute TTL, single-use under a row lock, bound to the origin, previous codes revoked on reissue, with memory, DB and global rate limits.
- **Withdraw:** requires a recent login (amr within 10 minutes) plus a confirm string.
- **CSRF:** API auth uses the Bearer header, not cookies. Only the gate's "lock" action is CSRF-able, which is a nuisance at most.
- **Service worker:** it never caches `/api/` or `/gate`, non-GET requests or other origins. The cached pages are client-rendered shells with no `cookies()`/`headers()` use, so no account data can cross over.
- **Cache-Control:** `no-store` on all API, proxy, export and backup responses. GET route handlers are not cached by default in Next 16, and cacheComponents is off.
- **Proxy file:** `src/proxy.ts` with `export function proxy` and matcher `/:path*` is the correct Next 16 convention (per `proxy.md`). Open paths match exactly.
- **Review mode (question 6):** fails closed. It needs both flags, refuses `VERCEL_ENV=production`, and returns 503 on every path if any Supabase, cron, VAPID or allowlist variable is present. When it does run, every API except gate and health returns 403. The client disables review mode when cloud is configured and uses a separate IndexedDB name. A review deployment cannot reach real data through the app.
- **Push SSRF:** endpoints go through an allowlist, a canonical-href check and a check against the old `url.parse` host before sending.
- **Logs:** only error names are logged.
- **Secrets:** none in tracked files, only placeholders and test fixtures.

