<!-- 独立の担当の報告（そのまま保存）。凍結のコード f8abb54 を、担当が選んだ新しい種で1回だけ測った（日付の危ない誤りの数つき）。2026-11-20 -->

# IQ05 independent OCR evaluation, round 3 (frozen f8abb54)

Measured each set once on the frozen OCR code. **All four groups FAIL.** The amount-safety result held: unsafe = 0 in every set and every kind. The groups fail for different reasons: (a) and (b1) only because of the new dateUnsafe metric, (b2) and (b3) because the sure rate is far below 98%.

## 1. Freeze check
- **At start:** `git log --oneline -1` gave `f8abb54 根本原因の工程 18: …`. `git status --short src scripts eval` was empty.
- **At end:** HEAD had moved to `a5b05f8 根本原因の工程 19: IQ05 の説明書に2回目の評価の結果を書く` (committer time 02:21:29Z). That commit changes only `kurashi-calendar/docs/rootcause_20261120/IQ05_OCR.md`. `git diff f8abb54 HEAD -- src scripts eval` is empty and `git status --short src scripts eval` is still empty, so the measured code and generator are identical to f8abb54. I made no code changes, no commits, and opened no images.

## 2. Seeds and commands
- **How chosen:** `crypto.randomInt(30000000, 99999999)`, drawn in a loop that rejects the excluded list. Drawn: `73505190 42705512 90655740 36883340 52035711 63736559`.
- **Sets:** A rc3/fmt1 = 73505190, B default/fmt1 = 42705512, C rc3/fmt2 = 90655740, D default/fmt2 = 36883340, E rc3/fmt3 = 52035711, F default/fmt3 = 63736559.
- **Generate** (120 images each): `SEED=<s> [VARIANT=rc3] [RECEIPT_FORMAT=fmt2|fmt3] node scripts/ocr-synth.mjs <scratch>/iq05-eval3/<X-…-s<seed>> 120`. Each labels.json confirms the seed, variant and format.
- **Measure:** `KURASHI_OCR_PRE_EVAL=<set> KURASHI_OCR_PRE_REPORT=<out>/report.json KURASHI_OCR_PRE_VARIANTS=app timeout 3000 npx vitest run src/lib/core/__tests__/ocr-preprocess-eval.gen.test.ts > <out>/run.log 2>&1`. Two queues ran in sequence, so at most 2 runs were in parallel. All 8 exited 0 ("1 passed"), each in 50–88 s.

## 3. Receipts (receipt + receiptDisc)
Percentages are truncated, never rounded up. Wilson 95% bounds are rounded outward. "Confirm-req" means the amount is correct but flagged for confirmation. "Not sure" is n − sure. Date accuracy counts only receipts whose amount was found.

| set | n | amount ok | sure | sure rate | confirm-req | not sure | amount acc | unsafe | dateUnsafe | date acc | Wilson95 sure |
|---|---|---|---|---|---|---|---|---|---|---|---|
| fixed rc3-20261302 | 48 | 48 | 48 | 100% | 0% | 0 | 100% | 0 | **1** | 87.5% | 92.5–100% |
| fixed v52-20261303 | 24 | 24 | 24 | 100% | 0% | 0 | 100% | 0 | **1** | 83.3% | 86.2–100% |
| A rc3/fmt1 | 48 | 48 | 48 | 100% | 0% | 0 | 100% | 0 | 0 | 95.8% | 92.5–100% |
| B def/fmt1 | 24 | 24 | 24 | 100% | 0% | 0 | 100% | 0 | **2** | 83.3% | 86.2–100% |
| C rc3/fmt2 | 48 | 43 | 30 | 62.5% | 27.0% (13) | 18 | 89.5% | 0 | 0 | 89.5% | 48.3–74.8% |
| D def/fmt2 | 24 | 23 | 19 | 79.1% | 16.6% (4) | 5 | 95.8% | 0 | 0 | 95.8% | 59.5–90.8% |
| E rc3/fmt3 | 48 | 44 | 44 | 91.6% | 0% | 4 | 91.6% | 0 | 0 | 2.0% (1) | 80.4–96.8% |
| F def/fmt3 | 24 | 22 | 21 | 87.5% | 4.1% (1) | 3 | 91.6% | 0 | 0 | 0% | 68.9–95.7% |

| group | n | amount ok | sure | sure rate | confirm-req | amount acc | unsafe | dateUnsafe | date acc | Wilson95 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) fixed | 72 | 72 | 72 | 100% | 0% | 100% | 0 | **2** | 86.1% | 94.9–100% | **FAIL** (dateUnsafe) |
| (b1) fmt1 A+B | 72 | 72 | 72 | 100% | 0% | 100% | 0 | **2** | 91.6% | 94.9–100% | **FAIL** (dateUnsafe) |
| (b2) fmt2 C+D | 72 | 66 | 49 | 68.0% | 23.6% (17) | 91.6% | 0 | 0 | 91.6% | 56.6–77.7% | **FAIL** (sure) |
| (b3) fmt3 E+F | 72 | 66 | 65 | 90.2% | 1.3% (1) | 91.6% | 0 | 0 | 1.3% | 81.2–95.3% | **FAIL** (sure) |

- **fmt3 dates:** dates are still almost never read correctly (1/72; the previous round had 0/72). But dateUnsafe = 0, so none of the 64 drafts with a correct amount and wrong date can be registered without confirmation. The new canRegister blocks these wrong dates. Read accuracy itself has not improved.
- **fmt1 and fixed:** dateUnsafe is non-zero. A wrong date on a correctly read amount can be registered with no confirmation step.

## 4. Non-receipt kinds
unsafe = 0 for every kind in every group (card, cardDetail, cardBill, qr, charge, refund, list).

dateUnsafe = 0 everywhere except **(a): qr = 1** (`072-qr-dark.png` in the v52 fixed set), which breaks the "must be 0" rule.

For context only, qr sure counts are low: 15/24 in (a), 10/24 in (b1), 12/24 in (b2), 10/24 in (b3).

## 5. Flagged files
**dateUnsafe ≥ 1** (all have the correct amount, sure=true, no why string):
- fixed-rc3: `107-receipt.png`
- fixed-v52: `069-receipt-photo.jpg`, and the non-receipt `072-qr-dark.png`
- B: `013-receipt-photo.jpg`, `093-receipt-photo.jpg`

**sure=false** (unsafe = 0 for all of them):

C, amount not found (no why):
- `009-receiptDisc.png`, `017-receipt-photo.jpg`, `019-receiptDisc-photo.jpg`, `059-receiptDisc-photo.jpg`, `067-receipt-photo.jpg`

C, amount found but flagged:
- "金額の文字が読みにくいです（文字の確かさ N）…": `002-receipt-photo` (69), `007-receipt-photo` (58), `042-receipt-photo` (54), `079-receiptDisc` (66), `099-receiptDisc` (66)
- "合計と検算（小計・税・お預り − お釣り）が合いません…": `047-receipt`, `062-receipt`, `082-receipt`, `112-receipt`, `039-receiptDisc-photo`
- "合計と検算（小計・税）が合いません…": `054-receiptDisc-photo`
- "合計と検算（お預り − お釣り）が合いません…": `094-receiptDisc-photo`
- "合計の読み取り（1,859円）が検算（小計 ＋ 税）と合わないため、1,829円にしました…": `057-receipt-photo`

D:
- Amount not found: `059-receipt-photo.jpg`
- "合計の読み取り（なし）が検算（小計 ＋ 税）と合わないため、2,922円にしました…": `019-receipt-photo`
- "合計と検算（小計・税）が合いません…": `063-receipt-photo`
- "金額の文字が読みにくいです…": `069-receipt-photo` (62), `109-receipt-photo` (68)

E, amount not found (no why):
- `022-receipt-photo.jpg`, `079-receiptDisc.png`, `102-receipt-photo.jpg`, `117-receipt-photo.jpg`

F:
- Amount not found: `019-receipt.png`, `029-receipt-photo.jpg`
- `083-receipt-photo.jpg`: amount correct, date wrong, "金額の文字が読みにくいです（文字の確かさ 62）…"

## 6. Speed (app variant, Node + tesseract.js in this container)
- **All items:** median 207–418 ms, p95 1.21–1.69 s.
- **Receipts:** median 0.98–1.39 s, p95 1.26–1.81 s, max 1.9 s.
- **Per-set wall time:** 47–84 s for 120 images.

## 7. Caveats
- **Fonts:** Noto Sans/Serif CJK JP, which the generator's CSS asks for, are not installed. `fc-match` resolves them to Inter. Japanese text falls back to WenQuanYi Zen Hei for both `sans-serif:lang=ja` and `serif:lang=ja`; IPAGothic, IPAPGothic and Unifont-JP are also installed. There is no Japanese Mincho font, so fmt3's "明朝" is probably DejaVu Serif for Latin and digits plus a gothic or Chinese-style fallback for kana and kanji. I can't confirm this without opening images. Results may not carry over to other font setups.
- **Reruns:** none; each set was measured exactly once. A helper wait command of mine exited 1 because of its own glob, which did not affect any measurement.
- **CPU sharing:** 4 vCPUs with 2 runs in parallel (load average 2–3.5), so speed numbers are indicative only. They are Node figures, not phone-browser figures.
- **Small samples:** 72 receipts per group. A 98% target means at most 1 miss out of 72. Even 72/72 gives a Wilson lower bound of only 94.9%; about 189 receipts with zero misses would be needed to show ≥98% at 95% confidence.
- **What the report records:** it stores only booleans for dates, not the date the draft produced, so the cause of the dateUnsafe errors can't be determined from report.json.
- **Synthetic data only:** all images are synthetic and fictional, not real screenshots or receipts. The fixed holdout sets have been measured in earlier rounds as well.

## Files
Everything is in `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/`. Each set folder holds `report.json`, `run.log` and `timing.txt`:
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/A-rc3-fmt1-s73505190/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/B-default-fmt1-s42705512/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/C-rc3-fmt2-s90655740/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/D-default-fmt2-s36883340/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/E-rc3-fmt3-s52035711/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/F-default-fmt3-s63736559/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/fixed-rc3-unseen-seed20261302/`
- `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/fixed-v52-unseen-seed20261303/`

The tables above were produced by `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval3/analyze.mjs`, which reads only the report.json files.
