<!-- 独立の担当の報告（そのまま保存）／Independent evaluator's report, saved as-is. 凍結のコード 17c6d26 を、担当が選んだ新しい種（9桁）で1回だけ測った。2026-11-20 -->

# IQ05 independent OCR evaluation, round 4 (frozen 17c6d26)

Each set was measured once on the frozen OCR code. **(a) fixed: PASS. (b1) fmt1: PASS, but with no margin at all. (b2) fmt2: FAIL. (b3) fmt3: FAIL.**

- **Amount safety held.** unsafe = 0 in every set and for every kind.
- **dateUnsafe is now 0 everywhere,** in receipts and in every non-receipt kind (round 3 had 4 receipts and 1 qr).
- **fmt2 and fmt3 fail only on the sure rate,** which is far below 98% (77.7% and 88.8%).

**Important caveat on what "sure" means.** The sure metric checks the amount only: a correct amount with no amount check on it. A receipt whose date was read wrongly still counts as sure, even though its date check stops it from being registered without confirmation.

Under a stricter reading, "the whole draft is right and can be registered with no confirmation", the counts would be at most:

| group | at most | rate |
|---|---|---|
| (a) | 62/72 | 86.1% |
| (b1) | 67/72 | 93.0% |
| (b2) | 56/72 | 77.7% |
| (b3) | 1/72 | 1.3% |

So (a) and (b1) would not meet 98% under that reading (see §3.1). The verdicts below use the metric as defined (unchanged from round 3).

## 1. Freeze check
- **At start (before 06:19Z, per the reflog):** `git log --oneline -1` gave `9a70994 根本原因の工程 31: 最終の全回帰（17c6d26）：…`.
  - This is a later commit than 17c6d26. `git diff --name-only 17c6d26 HEAD` lists only files under `kurashi-calendar/quality/` (evidence, ledger) and `kurashi-calendar/docs/`.
  - `git diff 17c6d26 HEAD -- src scripts eval` was empty, and `git status --short src scripts eval` was empty.
  - So the measured code and generator are identical to 17c6d26.
- **At end:** see §9.
- I made no code changes and no commits, ran no state-changing git command, and opened no images.

## 2. Seeds and commands
- **Generator check (before drawing):** `scripts/ocr-synth.mjs` reads `SEED` with `Number(process.env.SEED)`. A 9-digit value is a safe integer and is accepted as is. `labels.json` records `seed`, `variant` and `receiptFormat`, and all 6 sets confirm the expected values.
  - The generator's LCG multiplies in floating point beyond 2^53. This is true for every seed, including the earlier 8-digit ones; it is deterministic and not specific to 9-digit seeds.
  - The first 5000 draws for each of my seeds were all distinct.
- **How chosen:** `node -e "console.log(require('crypto').randomInt(100000000, 999999999))"`, one call per seed, 6 calls.
  - None of the 6 values appeared in the repository working tree (ripgrep, excluding node_modules and .git), in any commit message, or in the scratchpad. No redraw was needed.
- **Seeds drawn:** `168223064 922924330 788590333 974056092 865846583 179676996`.
- **Sets:**

  | set | variant / format | seed |
  |---|---|---|
  | A | rc3/fmt1 | 168223064 |
  | B | default/fmt1 | 922924330 |
  | C | rc3/fmt2 | 788590333 |
  | D | default/fmt2 | 974056092 |
  | E | rc3/fmt3 | 865846583 |
  | F | default/fmt3 | 179676996 |

  Each set has 120 images. The rc3 sets have 48 receipts and the default sets have 24.
- **Generate:** `SEED=<s> [VARIANT=rc3] [RECEIPT_FORMAT=fmt2|fmt3] node scripts/ocr-synth.mjs <scratch>/iq05-eval4/<X-…-s<seed>> 120`. All 6 runs exited 0 with 120 images.
- **Fixed holdout sets:** `eval/ocr-fixed/rc3-unseen-seed20261302` and `eval/ocr-fixed/v52-unseen-seed20261303`.
  - Both were measured in rounds 1–3.
  - In round 3, three of their file names were published as dateUnsafe failures, before the implementer's date fix.
  - So they are seen sets, not unseen evidence.
- **Measure:** `KURASHI_OCR_PRE_EVAL=<set> KURASHI_OCR_PRE_REPORT=<out>/report.json KURASHI_OCR_PRE_VARIANTS=app timeout 3000 npx vitest run src/lib/core/__tests__/ocr-preprocess-eval.gen.test.ts > <out>/run.log 2>&1`.
  - Two queues ran in sequence, so at most 2 runs were in parallel: Q1 was fixed-rc3, A, C, E and Q2 was fixed-v52, B, D, F.
  - All 8 runs exited 0 ("1 passed"), each in 57–99 s of wall time. **No reruns.**

## 3. Receipts (receipt + receiptDisc)
How to read the tables:
- Percentages are truncated, never rounded up. Wilson 95% bounds are rounded outward.
- "Confirm-req" means the amount is correct but flagged for confirmation.
- "Not sure" is n − sure.
- Date accuracy counts receipts whose amount was found and whose date is correct.

| set | n | amount ok | sure | sure rate | confirm-req | not sure | amount acc | unsafe | dateUnsafe | date acc | Wilson95 sure |
|---|---|---|---|---|---|---|---|---|---|---|---|
| fixed rc3-20261302 | 48 | 48 | 48 | 100% | 0% | 0 | 100% | 0 | 0 | 87.5% | 92.5–100% |
| fixed v52-20261303 | 24 | 24 | 24 | 100% | 0% | 0 | 100% | 0 | 0 | 83.3% | 86.2–100% |
| A rc3/fmt1 | 48 | 48 | 48 | 100% | 0% | 0 | 100% | 0 | 0 | 91.6% | 92.5–100% |
| B def/fmt1 | 24 | 24 | 23 | 95.8% | 4.1% (1) | 1 | 100% | 0 | 0 | 100% | 79.7–99.3% |
| C rc3/fmt2 | 48 | 46 | 39 | 81.2% | 14.5% (7) | 9 | 95.8% | 0 | 0 | 95.8% | 68.0–89.9% |
| D def/fmt2 | 24 | 21 | 17 | 70.8% | 16.6% (4) | 7 | 87.5% | 0 | 0 | 87.5% | 50.8–85.1% |
| E rc3/fmt3 | 48 | 45 | 42 | 87.5% | 6.2% (3) | 6 | 93.7% | 0 | 0 | 0% (0) | 75.2–94.2% |
| F def/fmt3 | 24 | 23 | 22 | 91.6% | 4.1% (1) | 2 | 95.8% | 0 | 0 | 4.1% (1) | 74.1–97.7% |

| group | n | amount ok | sure | sure rate | confirm-req | amount acc | unsafe | dateUnsafe | date acc | Wilson95 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) fixed | 72 | 72 | 72 | 100% | 0% | 100% | 0 | 0 | 86.1% | 94.9–100% | **PASS** (seen set) |
| (b1) fmt1 A+B | 72 | 72 | 71 | 98.6% | 1.3% (1) | 100% | 0 | 0 | 94.4% | 92.5–99.8% | **PASS** (one more miss would fail) |
| (b2) fmt2 C+D | 72 | 67 | 56 | 77.7% | 15.2% (11) | 93.0% | 0 | 0 | 93.0% | 66.9–85.9% | **FAIL** (sure) |
| (b3) fmt3 E+F | 72 | 68 | 64 | 88.8% | 5.5% (4) | 94.4% | 0 | 0 | 1.3% | 79.5–94.3% | **FAIL** (sure) |

Verdict rule: receipts sure/n ≥ 98% AND unsafe = 0 AND dateUnsafe = 0. In addition, unsafe and dateUnsafe must be 0 for every non-receipt kind in the group (§4: all 0).

### 3.1 Sure vs the whole draft (context, not a verdict change)
`report.json` does not store whether the matched draft is registrable, only booleans. But dateUnsafe = 0 means that every draft with a correct amount and a wrong date is **not** registrable without confirmation. So the receipts that count as sure but have a wrong date are all blocked by a confirmation.

| group | sure | sure & date correct | sure & date wrong (blocked) |
|---|---|---|---|
| (a) | 72 | 62 | 10 |
| (b1) | 71 | 67 | 4 |
| (b2) | 56 | 56 | 0 |
| (b3) | 64 | 1 | 63 |

"Sure & date correct" is an upper bound on "the whole draft is right and registrable without confirmation". Other field checks are not visible in report.json.

In fmt3, the date is still almost never read: 1/72 (round 3: 1/72). Almost every fmt3 receipt therefore needs a date confirmation, even though its amount is sure.

## 4. Non-receipt kinds
**unsafe = 0 and dateUnsafe = 0 for every kind in every group:** card, cardDetail, cardBill, qr, charge, refund, list and balanceOnly. For balanceOnly there is no expected transaction, so 0 means no registrable spurious draft.

Some non-receipt items have a correct amount but a wrong date, and all of them are blocked:
- (a): two qr items, `072-qr-dark.png` and `092-qr.png` in the v52 fixed set.
- (b1): one qr item, `042-qr-dark.png` in B.

Sure counts, for context only:

| kind | (a) | (b1) | (b2) | (b3) |
|---|---|---|---|---|
| card | 48/48 | 48/48 | 48/48 | 48/48 |
| cardDetail | 24/24 | 24/24 | 24/24 | 24/24 |
| cardBill | 12/12 | 12/12 | 12/12 | 12/12 |
| qr (amount ok) | 15/24 (20) | 14/24 (19) | 16/24 (24) | 13/24 (22) |
| charge | 7/12 | 10/12 | 11/12 | 6/12 |
| refund | 12/12 | 12/12 | 12/12 | 12/12 |
| list | 32/36 | 32/36 | 34/36 | 23/36 |

## 5. Flagged files
**dateUnsafe ≥ 1:** none.

**unsafe ≥ 1:** none.

**sure=false** (25 receipts, unsafe = 0 and dateUnsafe = 0 for all of them):

B (fmt1):
- `049-receipt.png` (not a photo): amount correct, date correct, "金額の文字が読みにくいです（文字の確かさ 59）。画像で金額を確かめてください". This is the only miss in (b1).

C (rc3/fmt2), amount not found (no why):
- `049-receiptDisc-photo.jpg`, `099-receiptDisc-photo.jpg`

C, amount found but flagged:
- "金額の文字が読みにくいです（文字の確かさ N）…": `034-receiptDisc-photo` (62), `042-receipt-photo` (44), `064-receiptDisc-photo` (63)
- "合計と検算（お預り − お釣り）が合いません…": `007-receipt-photo`, `054-receiptDisc-photo`
- "合計の読み取り（なし）が検算（小計 − 値引 ＋ 税・お預り − お釣り）と合わないため、816円にしました…": `074-receiptDisc.png` (not a photo)
- "合計の読み取り（なし）が検算（小計 ＋ 税）と合わないため、1,399円にしました…": `092-receipt-photo`

D (default/fmt2):
- Amount not found: `033-receipt-photo.jpg`, `089-receipt-photo.jpg`, `099-receipt-photo.jpg`
- "合計と検算（小計・税・お預り − お釣り）が合いません…": `049-receipt-photo`
- "合計の読み取り（2,254円）が検算（小計 ＋ 税）と合わないため、2,234円にしました…": `069-receipt-photo`
- "金額の文字が読みにくいです（文字の確かさ 66）…": `073-receipt-photo`
- "合計と検算（お預り − お釣り）が合いません…": `119-receipt-photo`

E (rc3/fmt3):
- Amount not found: `007-receipt-photo.jpg`, `034-receiptDisc-photo.jpg`, `062-receipt-photo.jpg`
- Amount correct, date wrong, "金額の文字が読みにくいです（文字の確かさ N）…": `012-receipt-photo` (63), `024-receiptDisc-photo` (65), `052-receipt-photo` (69)

F (default/fmt3):
- Amount not found: `099-receipt-photo.jpg`
- `103-receipt-photo.jpg`: amount correct, date wrong, "金額の文字が読みにくいです（文字の確かさ 58）…"

Most of the fmt2 and fmt3 misses are photos:

| group | photo sure | non-photo sure |
|---|---|---|
| (b2) | 33/48 | 23/24 |
| (b3) | 35/43 | 29/29 |

For context, these receipts have a correct amount but a wrong date, all blocked by a confirmation (dateUnsafe = 0):
- fixed rc3: `009-receiptDisc-photo`, `052-receipt`, `064-receiptDisc-photo`, `097-receipt-photo`, `107-receipt`, `114-receiptDisc-photo`
- fixed v52: `033-receipt`, `069-receipt-photo`, `079-receipt-photo`, `113-receipt`
- A: `054-receiptDisc-photo`, `102-receipt-photo`, `109-receiptDisc-photo`, `117-receipt-photo`

## 6. Comparison with round 3 (f8abb54)
Same layout. Round 3 used different seeds for (b1)–(b3); (a) uses the same images.

| group | round | n | amount ok | sure | sure rate | confirm-req | amount acc | unsafe | dateUnsafe | date acc | Wilson95 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) fixed | r3 | 72 | 72 | 72 | 100% | 0% | 100% | 0 | **2** (+qr 1) | 86.1% | 94.9–100% | FAIL (dateUnsafe) |
| (a) fixed | **r4** | 72 | 72 | 72 | 100% | 0% | 100% | 0 | 0 | 86.1% | 94.9–100% | **PASS** |
| (b1) fmt1 | r3 | 72 | 72 | 72 | 100% | 0% | 100% | 0 | **2** | 91.6% | 94.9–100% | FAIL (dateUnsafe) |
| (b1) fmt1 | **r4** | 72 | 72 | 71 | 98.6% | 1.3% (1) | 100% | 0 | 0 | 94.4% | 92.5–99.8% | **PASS** |
| (b2) fmt2 | r3 | 72 | 66 | 49 | 68.0% | 23.6% (17) | 91.6% | 0 | 0 | 91.6% | 56.6–77.7% | FAIL (sure) |
| (b2) fmt2 | **r4** | 72 | 67 | 56 | 77.7% | 15.2% (11) | 93.0% | 0 | 0 | 93.0% | 66.9–85.9% | **FAIL** (sure) |
| (b3) fmt3 | r3 | 72 | 66 | 65 | 90.2% | 1.3% (1) | 91.6% | 0 | 0 | 1.3% | 81.2–95.3% | FAIL (sure) |
| (b3) fmt3 | **r4** | 72 | 68 | 64 | 88.8% | 5.5% (4) | 94.4% | 0 | 0 | 1.3% | 79.5–94.3% | **FAIL** (sure) |

What changed:
- **dateUnsafe went from 4 receipts + 1 qr to 0.**
  - On the fixed sets (identical images), compared row by row with round 3's report.json, **exactly 3 rows changed**: `107-receipt.png` (rc3), `069-receipt-photo.jpg` (v52) and `072-qr-dark.png` (v52). These are the three files round 3 listed as dateUnsafe.
  - Each still has the correct amount and the wrong date, but now carries a confirmation, so dateUnsafe dropped from 1 to 0 for each.
  - Every other row is identical: amount, date, sure, confidence and image used. Date read accuracy on the fixed sets did not change (86.1%).
  - Because those file names were published before the fix, the fixed-set improvement is not independent evidence.
  - The independent evidence is the fresh fmt1 sets. Of 4 receipts with a correct amount and wrong date, plus 1 qr, none is registrable without confirmation.
- **fmt1 sure went from 72/72 to 71/72** (new seeds). The pass is at the exact limit: 98% of 72 allows one miss. The Wilson lower bound is 92.5%, so ≥ 98% is not shown at 95% confidence.
- **fmt2 went from 68.0% to 77.7%** (new seeds). The intervals overlap (56.6–77.7 vs 66.9–85.9). The code between f8abb54 and 17c6d26 also changed: the date-line reread, `amountReread.ts`, `parse.ts` and `fields.ts`. I can't tell how much of the difference is seed variation and how much is the code. It is still far below 98%.
- **fmt3 went from 90.2% to 88.8%.** Date read accuracy is unchanged at 1/72. dateUnsafe stays 0.
- **Speed is slower** (§7). Receipt median went from 0.98–1.39 s in round 3 to 1.32–1.64 s now, consistent with the added date-line reread. CPU sharing may also contribute, so I can't attribute it cleanly.

## 7. Speed (app variant, Node + tesseract.js in this container)
- **All items:** median 210–372 ms, p95 1512–1995 ms, max 2437 ms.
- **Receipts:** median 1321–1636 ms, p95 1683–2124 ms, max 2437 ms.
- **Per-set wall time:** 57–99 s for 120 images (`timing.txt`). The sum of per-item times was 53–95 s.

## 8. Caveats
- **Fonts:** same environment as round 3. Noto Sans/Serif CJK JP, which the generator's CSS asks for, are not installed.
  - `fc-match` resolves them to Inter. `sans-serif:lang=ja` and `serif:lang=ja` both resolve to WenQuanYi Zen Hei. IPAGothic, IPAPGothic and Unifont-JP are also installed. There is no Japanese Mincho font.
  - fmt3's "明朝" is therefore probably DejaVu Serif for Latin and digits, plus a gothic or Chinese-style fallback for kana and kanji. I can't confirm this without opening images.
  - Results may not carry over to other font setups.
- **Reruns:** none. Each set was measured exactly once.
  - Every run.log contains one tesseract message, "Error opening data file ./.traineddata … Failed loading language ''". The same message appears once in every round 3 run.log, and all runs passed. I did not investigate it.
  - The two fixed-set output folders were written as `rc3-unseen-…`/`v52-unseen-…` and renamed to `fixed-…` after the runs finished; `timing.txt` records the input path.
- **CPU sharing:** 4 vCPUs with 2 runs in parallel; the load average during the runs was 1.1–2.2.
  - No other test process was running when I started. The 1-minute load average was 3.4 just before, presumably from the other process finishing.
  - Speed numbers are indicative only. They are Node figures, not phone-browser figures.
- **Small samples:** 72 receipts per group. A 98% target means at most 1 miss out of 72. Even 72/72 gives a Wilson lower bound of only 94.9%.
- **The metric covers the amount only:** see §3.1. report.json stores only booleans for dates, so the dates the drafts produced, and any non-amount checks, cannot be seen.
- **Eval vs app:** the eval runs in Node and calls the same core functions. I checked only that the eval's date-line reread uses the same condition as `src/lib/ui/ocr.ts`. I did not audit full parity.
- **Synthetic data only:** all images are synthetic and fictional. The fixed holdout sets have been seen in earlier rounds. fmt2 was used by the implementer for development. fmt3 has not been generated by the implementer, according to IQ05_OCR.md.

## 9. Freeze check at end
Checked at 2026-11-20T06:39Z, after the last measurement and the file copy.

- **HEAD had moved:** `git log --oneline -1` gave `628bc6b 根本原因の工程 35: 説明書に、ログアウトの欠陥（SEC-R04 の直しが入れた）と原因不明の読み込みの止まり（RCL-R23）を書く`.
- **What moved it:** four commits landed after my start check: `c9ed129`, `decebd9`, `613fd2f` and `628bc6b`.
  - The reflog times are 06:19:19–06:22:42Z. That is before my first measurement started at 06:28:08Z and before the seeds were drawn.
  - `git diff --name-only 9a70994 HEAD` lists only files under `kurashi-calendar/docs/rootcause_20261120/` and `kurashi-calendar/quality/`.
- **Code unchanged:** `git diff 17c6d26 HEAD -- src scripts eval` is empty, and `git diff 17c6d26 -- src scripts eval` (working tree) is empty. `git status --short src scripts eval` is still empty.
- **My files:** the only untracked files from me are this report and `quality/evidence/iq05-frozen-eval-final/`.
- **Conclusion:** the measured code, the generator and the fixed sets are identical to 17c6d26.

## Files
- **Records (no images):** `quality/evidence/iq05-frozen-eval-final/<set>/` holds `report.json`, `run.log`, `timing.txt` and `labels.json`. For the fixed sets, `labels.json` is a copy from `eval/ocr-fixed/`. The set folders are:
  - `fixed-rc3-unseen-seed20261302`
  - `fixed-v52-unseen-seed20261303`
  - `A-rc3-fmt1-s168223064`
  - `B-default-fmt1-s922924330`
  - `C-rc3-fmt2-s788590333`
  - `D-default-fmt2-s974056092`
  - `E-rc3-fmt3-s865846583`
  - `F-default-fmt3-s179676996`
- **Scripts and logs** in `quality/evidence/iq05-frozen-eval-final/`:
  - `analyze.mjs`: round 3's script, with only the set folder names changed. It produced the tables, and its output is `analysis.txt`. Running it on the evidence folder reproduces the same output.
  - `extra.mjs`: the §3.1 numbers and the row-by-row diff of the fixed sets against round 3's report.json.
  - `run-queue.sh`: the measurement queue.
  - `queues.log`: exit codes and load average.
- **Images:** only in the scratchpad, at `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval4/<set>/img/`.
