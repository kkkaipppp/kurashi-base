<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

## IQ02 final: revised N3-c applied — 135 tests, all pass

**Result:** 135 tests, 135 pass, 0 fail. N4 is fixed and kept as two regression tests. No disagreement remains.

**Rerun:** `cd /home/user/kabu-hantei/kurashi-calendar && npx vitest run src/lib/core/__tests__/iq02-independent-oracle.test.ts` (about 0.8 s, typecheck clean).

**REPORT.md was not written.** The environment refused it ("Subagents should return findings as text, not write report files"). Its full content is below for you to save as `src/lib/core/__tests__/iq02/REPORT.md` if you want it.

**The change, from the rule text:** in `model.ts` the payment-dialog key is now (statement, sorted ids of the live payment rows linked to it when the dialog opens). A row's id is a short hash of its key, so the same key gives the same row and the later amount wins. A key that belongs to a cancelled row re-creates that row. In the 20 random seeds:
- a new dialog never produced the id of a live row;
- 16 new dialogs re-created a cancelled row;
- 3 same-dialog sends replaced a live row;
- there were 19 cancellations.

The implementation agrees with the model on all of it. My files: `src/lib/core/__tests__/iq02-independent-oracle.test.ts` and `src/lib/core/__tests__/iq02/{model,sim,impl}.ts`. No existing file was modified by me.

---

# IQ02 — independent expected values: final summary

**Final state:** 135 tests, **135 pass, 0 fail**.
Rerun: `cd /home/user/kabu-hantei/kurashi-calendar && npx vitest run src/lib/core/__tests__/iq02-independent-oracle.test.ts` (about 0.8 s).

## Files

| File | Purpose |
| --- | --- |
| `../iq02-independent-oracle.test.ts` | Hand-calculated tables, the seeded random suite, cross-screen checks, and the triage block (now regression tests). |
| `model.ts` | Independent model. It imports only types and has its own date arithmetic. |
| `sim.ts` | PRNG (mulberry32), world per seed, operation generator, implementation runner, aspect comparison, greedy shrinker. |
| `impl.ts` | The only place that imports implementation functions (the same ones the screens call). |

## How the expected values were made

- Every expected number is either a literal computed by hand (written next to it in the test) or comes from `model.ts`.
- Neither source is the implementation. No function body in `src/lib/core` was read; only types, exported signatures and their doc comments, `quality/BASELINE_283.csv` and the view code (to find which functions each screen calls) were used.
- Rules that were ambiguous are written as `READING:` comments in the model. Rules decided during triage are marked `DECIDED`.

### Random suite

- 20 seeds × 50 operations.
- Each seed has its own 150-day window, starting 2026-10, 2027-11 or 2028-01, so the runs cross year end, February and Feb 29.
- Closing and pay days are random per card.
- Card Y's base unpaid is either 0 or 12,345.

**Operations generated:**
- purchases, including investment, advance (立替) and needs_review ones;
- income;
- refunds, with part applied to the advance;
- transfers and ATM withdrawals, with fees;
- recoveries and write-offs;
- statements: 90% equal to the cycle's usage, the rest with an extra amount; when entered without a closing date, some use a due date shifted by 1–3 days;
- payments: full, partial, over (with and without confirmation), from the same dialog state (second device / double tap), and cancellations;
- manual card payments;
- delete and ignore;
- suspend and resume a card;
- change or unset the pay account.

**Aspects compared:**
- operation accepted / rejected;
- monthly living expense (`monthSummary`, `householdMonth`, `spentBetween`) and today's usage;
- balances and overpaid amounts;
- statement state (linked payments only) and the statement row (`statementView`);
- bills, `unknownYen` and next bill;
- advance status;
- forecast end per bank and unassigned bills;
- which accounts are listed;
- the invariant: open bills + `unknownYen` = max(0, ledger unpaid).

When a seed fails, the message names the seed and a minimal failing sequence.

### Cross-screen check

The screens are read through the functions their views call:
- home: `homeChecks`, `homeModuleLines`, `householdMonth`, `todayUsage`;
- accounts: `accountsToShow`, `accountBalance`, `nextCardBill`, `statementView`;
- forecast: `balanceForecast`;
- household: `monthSummary`.

## Readings (my interpretations of ambiguous rules)

| Id | Reading |
| --- | --- |
| R1 | Card cycle = (previous closing, closing]. A purchase on the closing day is in that cycle. Due = payDay of the next month; a day past the month's length means month end. No business-day shift. |
| R2 | The due day is still "upcoming"; from the next day the bill is overdue and stays open. |
| R3 | A merchant refund reduces living expense on the refund date; the original month is not changed. A card refund belongs to the cycle that contains its date. |
| R4 | Only confirmed transactions count, for living expense and for balances. |
| R5 | An advance recovery is a transfer (neither income nor living expense). The part beyond the unrecovered amount reverses an earlier write-off on the receipt day; more than unrecovered + written-off is rejected. A recovery moves no account unless one is assigned. |
| R6/R8 | Superseded by the decided rules below. |
| R7 | Payments must be positive integers. The overpay check was replaced by N3-b. |

## Decided product rules (from triage)

| Rule | Text |
| --- | --- |
| R-A (D3) | A statement covers the cycle with the same closing date. If its closing date is null, it covers the cycle whose computed due date is within ±7 days of the statement's due date. Covered cycles get no estimate. |
| R-B (D2) | An uncovered cycle with a negative net gives a credit. Credits are applied in order of their own due date, each to the oldest bills due strictly after it. Leftover is dropped. |
| R-B(ii), revised after N2 | The excess of an overpaid statement joins the R-C payment pool (it is not a later-bills-only credit). |
| R-C (D4) | One pool = unlinked card payments + overpaid-statement excess. It pays the oldest open bills, confirmed ones included; on the same day, confirmed first. |
| R-D (D1) | `unknownYen` = clamp(ledger − Σ all bills, 0, base); null when the base is unset. |
| R-E | Compute all cycles and statements first, then filter by horizon. overdue = dueOn < today. |
| N1/N2 | "Next debit" and "has open debt" look ahead 400 days. A suspended card counts in both the home and the accounts 差引 iff its unpaid ledger > 0 or it has an open bill within 400 days. |
| N3-a | Statement row: remaining = the open bill the schedule keeps for that statement; paid = amount − remaining. A row is overpaid only by linked payments. The row also shows the amount covered by other money. |
| N3-b | Without `allowOverpay`, a payment is rejected if it exceeds the row remaining plus the previous amount of the same operation. |
| N3-c, revised after N4 | Operation id = f(statement, sorted ids of the live payment rows linked to it when the dialog opens). |

## Discrepancies and final status

All 8 were accepted as defects (or rule flaws) and fixed. Each is now a passing regression test.

| Id | What was wrong | Minimal repro (hand test) | Status |
| --- | --- | --- | --- |
| D1 | A confirmed statement erased the card's base unpaid amount (`unknownYen` = max(0, base − Σ statements)). | CardY 20/29, base 12,345, purchase 17,500, statement 2/29 of 17,500 → unknown was 0; ledger 29,845. | Fixed (R-D) |
| D2 | A refund after the statement closed (a negative cycle) was dropped, so bills exceeded the ledger and the forecast over-deducted. | CardX 15/10: 10,000 (statement), refund 3,000 in the next cycle, then 5,000 → bills were 15,000; expected 12,000. | Fixed (R-B) |
| D3 | A statement entered with the bank's shifted due date was double counted. | 1/10 is a Sunday; statement entered as due 1/12 → an estimate plus the confirmed bill; forecast 180,000 instead of 190,000. | Fixed (R-A) |
| D4 | A manual card payment made before the statement was entered was ignored afterwards: double count and a false urgent alert. | Purchase 10,000, manual payment 10,000, then statement 10,000 → shown overdue 10,000. | Fixed (R-C) |
| N1 | `nextCardBill` had a hidden horizon of about 61 days. | CardX 5/29, purchase 4/07, due 6/29, today 4/18 → null. | Fixed (400 days) |
| N2 | The home 差引 left out a suspended card that the accounts 差引 included. | A suspended card overpaid overall but with an open bill → home 135,000 vs accounts 137,000. | Fixed (same rule on both screens; R-B(ii) revised) |
| N3 | A statement row showed 未払い after the pool had paid its bill, so a second payment was possible. | The D4 and N2 data → row unpaid 10,000 / 8,000 while the schedule had nothing open. | Fixed (N3-a/b) |
| N4 | The first N3-c rule (key = linked total) collided after a cancellation or correction: a new payment overwrote a live one. | A 3,000, B 3,000, cancel A, then C 2,000 → B became 2,000 (bank 198,000 instead of 195,000); the correction case was similar. | Fixed (revised N3-c) |

### Issues in my own harness or readings, corrected along the way

- **Invariant for an overall-overpaid card:** a card overpaid as a whole owes nothing, so the invariant compares against max(0, ledger).
- **Forecast label:** the label for a suspended card's bill has an extra `（しまったカード）` part, which my label filter first missed.
- **Generator coverage bug:** sequences once covered only the first ~40% of the window. They now spread over the whole window, and that fix is what exposed N1 and N2.

## Coverage (20 seeds)

Exercised:
- closing day −1 / on / +1, month end, Feb 29, December→January;
- statements, partial and overpaid payments, rejected overpays and recoveries;
- payment cancellations and suspended cards.

Counts:
- 18 negative cycles, with credits applied and dropped;
- 7 overpaid statements feeding the pool; the pool used on confirmed bills 12 times;
- 10 statements matched to a cycle with a shifted due date;
- 22 rows with an amount covered by other money;
- 4 N3-b rejections that the old linked-only rule would have accepted;
- 3 same-dialog re-sends that replaced a live payment row; 16 new dialogs that re-created a cancelled row;
- no new dialog ever produced the id of a live row.

## Not covered / limits

- A bill marked "uncertain" because the pay account was checked after the due date: banks are always checked at the base instant.
- Changing a card's closing day while statements exist.
- Cancelling a purchase that is already on a confirmed statement.
- Forecasts with income, fixed costs or event budgets.
- Future-dated transactions; the model assumes everything is after the base and on or before today.
- The random suite reads the forecast horizon from the implementation's `f.to`; a hand test checks that a 30-day forecast runs to today + 30.
- Results are against the working tree while other processes were changing it (`accounts.ts`, `home.ts`, `ops.ts` and the view files).

