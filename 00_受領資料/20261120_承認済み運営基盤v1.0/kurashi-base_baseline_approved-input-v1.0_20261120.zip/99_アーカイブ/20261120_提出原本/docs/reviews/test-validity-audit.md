<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

I audited 44 high-risk PASS rows in `quality/RESULTS_283.csv`. I opened the source of every cited test, `e2e.mjs`, `e2e-qr-*.mjs`, `supabase/tests/*`, the evidence logs, and the implementation each test claims to cover. Nothing in the repo was edited, and I ran no builds, servers, Playwright or vitest. Source under `src`, `scripts` and `supabase` is identical between the evidence commit 86456b4 and HEAD 6218a33, so the evidence is not stale because of code drift.

**Result: 24 VALID, 17 WEAK, 3 INVALID.**

## Rows audited

| id | verdict | reason | what would make it VALID |
|---|---|---|---|
| EN03 | WEAK | In the rapid-tap step, taps 2 and 3 are `rec.click({timeout:500}).catch(()=>{})` (`e2e.mjs:1407-1408`, also `:390`). If the dialog closes after the first tap they never fire. The same-content check (`MoneyForm.tsx:141`) hides the double-submit guard anyway. The F10 retry step only checks that a ¥777 item exists, not that there is exactly one. | Fire several clicks synchronously inside `page.evaluate`, as `e2e-qr-ocr.mjs:481` does, with different content each time. Assert count===1 after the F10 retry. |
| RC4-08 | WEAK | The back and reload steps are good (count===1). The rapid-tap step has the same swallowed-click problem. | Same as EN03. |
| OC07 | WEAK | `ocr-v52.test.ts:111` is conditional: `if (!d.investBucket) expect(...)`. It also leaves `categoryConfirmed` unset, so the false result has two possible causes. `canRegister` returns true for any transfer (`screenshot.ts:333`), and no test requires confirmation for a transfer. | Assert `investBucket` is null unconditionally and set `categoryConfirmed:true`. Add a test that an ambiguous transfer (charge, bill, remittance) cannot be registered without confirmation. |
| OC08 | WEAK | The amount/date confidence tests are valid. The cited "危ない誤り 0 across all sets" comes from `ocr-eval.gen.test.ts`. That suite is skipped in the final `vitest.log` and asserts nothing about accuracy. | Make the dangerous-error count an asserted number and run that suite in CI. |
| OC09 | INVALID | The per-type totals are computed only inside `ScreenshotImportView.tsx:318-321` (output labelled 選んだ候補の合計). No unit test or E2E references them. | Extract the totals function and unit-test a mix of expense, income, transfer and investment. Have the E2E check the rendered totals. |
| OC11 | VALID | Uses the real `commitLocal` on fake-indexeddb: 5 taps, quota then retry, 2 tabs, restart. The DB test checks a same-operation resend. | – |
| OC12 | VALID | Real modules, with negative cases for account scope and logout. | – |
| OC14 | WEAK | Only checks that the localStorage draft has no full text, `data:` or `blob:`. Nothing asserts that no image or text leaves the device. Nothing tests `revokeObjectURL` or `worker.terminate`. IndexedDB is not checked. | Capture all network requests during OCR and assert none carry image or text. Spy on URL release and worker termination. |
| LG01 | VALID | Fixed expected values, plus over-recovery and double-recovery negative cases. | – |
| LG02 | WEAK | Refund, recovery, write-off and later recovery are covered. The audit history (`advanceStatus().history`, `ledger.ts:158`) is never asserted. | Assert the history contents and order. |
| LG04 | VALID | BUDGET-04/05 use fixed values and check for double deduction. | – |
| LG05 | VALID | FIN-04/06, IN07 and needs_review exclusion are covered. | – |
| ACC04 | VALID | Fixed balances; household totals unchanged. | – |
| ACC07 | VALID | A foreign-key failure inside one `kurashi_apply_changes` call leaves no fee transaction. | – |
| ACC08 | INVALID | The cited unique index `account_movements_statement_once` was dropped (`v54_rc.sql:14`). Dedupe now relies on `statementPaymentId(s.id, opId)`, and the UI makes a fresh `opId = newId()` each time the dialog opens (`AccountsView.tsx:165`). Two devices paying the same bill both get saved; `payments_concurrency_test.sh` even accepts 81,000 against an 80,000 statement. Tests only prove a resend of the same operation is deduplicated. | Either derive the operation key from the statement (or add a server-side overpay guard), then test two different `opId`s sent concurrently → one payment or a conflict. |
| ACC09 | WEAK | Every refund in the tests falls before the statement closes. A refund after the statement is confirmed or paid ("請求後") is never tested. | Refund after closing and after full payment → overpaid/credit carried to the next bill. |
| RC-F04 | VALID | Fixed values. | – |
| RC-F05 | VALID | Unit test plus the concurrent same-id DB test. The ledger cites only `vitest.log`; the DB proof is in `test-db.log`. | – |
| RC-F06 | VALID | Correction, cancellation and overpay are covered. | – |
| RC4-02 | WEAK | The list and forecast checks are real. The home 差引 assertion passes a stub balance function, `(a)=>a.kind==='card'?80000:…` (`rc4-archived-card.test.ts:49`). | Use the real `accountBalance` and assert the accounts-screen total. |
| RC4-05 | INVALID (as cited) | `rc3-local-protect.test.ts` tests `local.ts` `saveLocal`. Production uses that only when `NEXT_PUBLIC_KURASHI_STORAGE_ROLLBACK=1` (`StoreProvider.tsx:603`); the default is IndexedDB. The DP01 E2E saves one after the other, not simultaneously. | Cite `qr-p0-storage.test.ts` QG01/QG02, which do cover the default path. |
| IN01 | VALID | Constants and inner-count checks. A gap remains on the lifetime-growth limit (mutation #5 below). | – |
| IN03 | VALID | Fixed values: partial sale, next-year recovery, over-selling. | – |
| REV01 | WEAK | Runs on `MemoryRepo`, which re-implements the investment-history filter (`repo.ts:683-697`). `SupabaseRepo.all` pagination (`repo.ts:163-171`) and the chunked refund queries never run in any test, so "all pages of the API" is unproven. | A `SupabaseRepo` test with a fake client returning more than 1000 rows (PAGE). |
| REV02 | VALID | The calculation is checked with fixed values (same API caveat as REV01). | – |
| FIN02 | WEAK | No boundary test at the transaction maximum (`schemas.ts:9` and the DB CHECK, both 100,000,000). Overflow is tested only with 1e13 against the 1e12 limit for account movements. | Test 1e8 accepted and 1e8+1 rejected at UI, API and DB, plus 0.5 and -1 for each transaction kind. |
| UI14 | VALID | Scans text and ARIA attributes on 47 screens and checks the service-worker cache. Bare numbers and percentages are not scanned. | – |
| RC-U05 | WEAK | The regex at `e2e.mjs:920` misses the "1.2万円" format (`util.ts:63`, used for amounts ≥10,000) and 3-digit amounts. It scans only `main` and `aria-label`. | Reuse UI14's `MONEY_PATTERNS` scanner. |
| SEC13 | WEAK | `check-bundle-secrets.mjs:14` scans only `.next/static` and `public`, not the server-rendered HTML/RSC under `.next/server` that browsers also receive. There is no sentinel for `VAPID_PRIVATE_KEY`. The log test covers only `serverError`; `handlers.ts:227` and `:244` log the raw `e.message`. | Add `.next/server/app` to the scan, add a VAPID sentinel, and test every `console.*` site. |
| SE02 | VALID | DB permission matrix enumerated from `pg_catalog`, with negative cases. Caveat: the API layer is tested on `MemoryRepo`, and the service-role path relies on `.eq('user_id')` filters that no test covers. | – |
| SEC11 | VALID | – | – |
| RC-S06 | VALID | – | – |
| SE03 | VALID | E2E AUTH-13/14 counts sends per account. | – |
| WG04 | WEAK | The test oracle calls the implementation it is testing: fixtures use `secretHash: hashToken(token)`, and `widget-link.test.ts:55` asserts `toBe(hashLinkCode(...))`. Nothing asserts that the stored hash differs from the token or matches a known SHA-256 value. `ingest_devices.secret_hash` has no format CHECK. | Assert a known SHA-256 vector and that the stored value ≠ the plaintext token. |
| WG05 | VALID | Harness covers 401 with cache, 403, cache from another account, and expiry. Minor gap: no 403-with-cache case. | – |
| SE04 | VALID | One caveat: the header-tamper test changes only the PBKDF2 iteration count, which changes the key anyway, so binding the header as AES-GCM additional data (AAD) is never tested on its own. | – |
| SE05 | VALID | Restore and snapshot DB tests. They depend on timing (see systemic findings). | – |
| SE06 | WEAK | Account deletion is tested on `MemoryRepo` (a Map delete). The hand-maintained table list in `SupabaseRepo.deleteAllData` (`repo.ts:551-566`) is never checked against the schema. The E2E mocks `/api/account/withdraw`. | A DB test that every table with `user_id` is emptied for the account. |
| RC-D03 | WEAK | The `rc3-local-protect` half of the evidence covers the rollback-only storage path. `backup.test.ts`, F10 and DP02 are valid. | Re-cite to `qr-p0-storage` QG02/QG03. |
| DATA04 | VALID | Wrong passphrase, 1-byte tamper, truncation, quota; a failed restore writes nothing. | – |
| DATA05 | VALID | – | – |
| NOTE07 | VALID | E2E against the real `handlers.ts` (on `MemoryRepo`) checks send counts, the 409 conflict and the draft. | – |
| RC-S03 | WEAK | After B logs out, the page sits signed-out for 1.5 s and then navigates to `/login`, which unmounts the editor, before A logs in. The pending autosave timer can never fire under A's uid. | Log A in from a second tab while tab 1's editor stays mounted with a pending timer; assert nothing is written to A. |
| RC-S05 | WEAK | Only asserts that `writeDraft()` returns false. How `NoteEditor` handles that (`NoteEditor.tsx:119` and `:162`) is never tested. | A UI test that a quota failure on the draft shows "not saved" and keeps the input. |

## Systemic findings
1. **Most PASS rows are copied forward, not checked.** 189 of the 237 PASS rows are carried over by `quality/update_results.py:63-72`. It regex-matches keywords in the baseline evidence text (`kinds_of`, `:19-30`), such as "E2E" or "単体", and attaches whole-suite logs as proof. Nothing maps a row to a specific test, and the assertion column is filled from a template.
2. **The vitest log cannot prove any particular test ran.** `quality/evidence/final-86456b4/vitest.log` is a summary only ("92 passed | 3 skipped") with no test names.
3. **Skipped suites.** `describe.skipIf` at `restore-sql.gen.test.ts:33` (this one does run inside `test-migrations.sh`), `ocr-eval.gen.test.ts:17` and `ocr-preprocess-eval.gen.test.ts:32`. The two OCR evaluation suites assert only the row count (`:87`, `:156`) and hard-code `unsafe: false` (`ocr-eval.gen.test.ts:43`).
4. **Conditional assertion:** `ocr-v52.test.ts:111`.
5. **E2E steps that swallow failures.**
   - Taps after the first are discarded with `.catch(()=>{})` at `e2e.mjs:390` and `:1407-1408`, and inside `rapid()` at `e2e-qr-sync.mjs:368-369`.
   - At `e2e.mjs:1731`, the assertion that previously loaded data shows while offline is wrapped in `.catch(()=>{})`, so the title's claim is never enforced.
   - `e2e-qr-cal.mjs:54-61` `press()` retries a click up to 5 times, which hides a UI that ignores the first tap.
6. **Timing-dependent, non-binding negative control.** In `supabase/tests/snapshot_test.sh:41`, failing to reproduce the old bug only prints a warning. It relies on 0.5 s / 1.5 s sleeps, so if the write lands late the test passes without testing anything.
7. **The thing under test is mocked.**
   - `SupabaseRepo` has zero tests; every server test uses `MemoryRepo`, which re-implements filtering and ownership (`repo.ts:589+`).
   - `setTestUsers` / `setTestRepo` hooks in production code (`auth.ts:97` and `:129`) send tests down a test-only branch, so the real `requireUser` / `deviceOwner` code never runs.
   - The fake server in `e2e.mjs` upserts by id (`:80-90`), so a duplicate send with the same id is invisible there.
8. **Tests whose expected value comes from the code under test:** `widget-link.test.ts:55`; the `hashToken()` fixtures in `handlers.test.ts:19`, `beta-auth.test.ts:26`, `review.test.ts:38` and `v51review-server.test.ts:70`; and the stub balance function at `rc4-archived-card.test.ts:49`.
9. **Stale or mismatched evidence.**
   - ACC08 relies on the dropped index (`v54_rc.sql:14`).
   - RC4-05 and RC-D03 cite tests of the rollback-only localStorage path.
   - The ledger cites E2E steps by number, e.g. SE04 "E2E 23・29", SE03 "32・38", SE06 "39". In the current `e2e-normal.log`, #23 is RC-S02 (notes) and #29 is manual entry, and the backup tests are #43 and #49.
10. **Narrow leak scanners:** `e2e.mjs:920` (the money regex) and `check-bundle-secrets.mjs:14` (scanned folders exclude `.next/server`).

## Top 10 mutations predicted to survive
1. **`src/lib/server/auth.ts:114` `requireUser`:** delete the `email_confirmed_at` / `confirmed_at` 403 check. Every server test calls `setTestUsers`, which returns early at `:97`, and the E2E mocks the API. Unconfirmed accounts would read data.
2. **`src/lib/server/tokens.ts` `hashToken`:** return the token unchanged. Fixtures and lookups both call `hashToken`, there is no known-vector test, and the column has no CHECK. Widget, ingest and backup tokens would be stored in plaintext.
3. **`src/lib/server/repo.ts:270` `SupabaseRepo.loadDataset` `sel()`:** drop `.eq('user_id', userId)`. The widget summary uses the service-role repo, which bypasses database row-level security, and `SupabaseRepo` is never tested. Other accounts' data would leak through the widget.
4. **`repo.ts:169` `SupabaseRepo.all`:** stop after the first page (`if (true) break`). Untested; history over 1000 rows would be silently truncated (REV01).
5. **`src/lib/core/invest.ts:351` `nisaStatus` `addable.growth`:** remove `Math.max(0, NISA_LIFETIME.growth - lifeGrUsed)`.
   - The only exhaustion test (`qr-in05-nisa` s29) also exhausts the 18M total, which hides this.
   - The test with 12M+1 of growth only does not assert `addable`.
   - Effect: a user who has used the 12M growth limit would be told they can still buy 2.4M.
6. **`src/lib/core/backup.ts:205` and `:281`:** remove `additionalData` from both encrypt and decrypt. The header-tamper test changes only the iteration count, so it fails for another reason.
7. **`src/components/views/ScreenshotImportView.tsx:320` totals:** put every type under one key, or use `-=`. Nothing tests it (OC09).
8. **`src/lib/core/ingest/screenshot.ts:332-333` `canRegister`:** move `if (d.type==='transfer') return true` above the amount/date confidence check. No test has a transfer with a low-confidence amount, so a misread bill amount would be pre-selected for registration.
9. **`src/lib/core/ledger.ts:158` `advanceStatus.history`:** return `[]` or drop the refund filter. `history` is never asserted (LG02).
10. **`src/lib/schemas.ts:9` `yen`:** raise `.max(100_000_000)` to 1e9 or remove it. There are no boundary tests. Local mode would accept amounts the DB CHECK later rejects, leaving changes stuck in the unsent queue.

Runners-up:
- `NoteEditor.tsx:162` → `setDraftOk(true)` (RC-S05).
- Dropping `'notes'` from `SupabaseRepo.deleteAllData` (`repo.ts:563`).
- `payStatement` overpay tolerance `amountYen > rest + k` (`accounts.ts:238`).

I wrote no files; the scratch folder was created but left empty.

