<!-- 独立の担当の報告（そのまま保存）。凍結のコード a1fbd7a を、担当が選んだ種で1回だけ測った。2026-11-20 -->

I could not write REPORT.md: the harness refused the Write with "Subagents should return findings as text, not write report files", and I did not try to get around it. The full report is below. Everything else (report.json and run.log for each set, seeds.json, run-all.sh, runner.log, analyze.mjs) is in `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval/`.

# IQ05 independent OCR evaluation (frozen code a1fbd7a)

## Verdict

The fixed holdout and the fresh fmt1 sets meet the target. The fresh fmt2 sets do not: they fail on both conditions.

| Group (receipt + receiptDisc) | n | sure | sure rate | dangerous (unsafe) | Target (sure ≥ 98% and unsafe = 0) |
|---|---|---|---|---|---|
| (a) Fixed holdout (rc3-unseen-seed20261302 + v52-unseen-seed20261303) | 72 | 72 | 100.00% | 0 | **PASS** |
| (b1) Fresh fmt1 (A + B) | 72 | 71 | 98.61% | 0 | **PASS**, by exactly one receipt (70/72 = 97.22% would fail) |
| (b2) Fresh fmt2 (C + D) | 72 | 56 | 77.77% | **1** | **FAIL** on both conditions |

Percentages are truncated to 2 decimals, never rounded up. fmt1 and fmt2 are reported separately and never pooled. No code, thresholds, eval script or synth script was changed. Nothing was tuned or committed, and no images were opened.

## 1. Freeze check
- `git log --oneline -1 -- src/lib/core/ingest src/lib/ui/ocr.ts` showed `a1fbd7a`, which was also HEAD at the start.
- `git status --short` on the three frozen paths was empty. `scripts/ocr-synth.mjs` and `eval/` were also clean.
- **HEAD moved during the runs.** At 01:53:07 UTC another agent committed `307077b`, which adds only docs and quality evidence.
  - `git diff a1fbd7a HEAD` is empty for the ingest folder, `ui/ocr.ts`, the eval test, `__tests__/helpers.ts`, `scripts/ocr-synth.mjs`, `eval/`, `public/tesseract` and `package*.json`.
  - The last commit touching the frozen paths is still a1fbd7a, and the frozen paths were clean again after the runs. So the code measured is a1fbd7a.
- An unrelated `quality/build_verdicts.py` is modified in the working tree. I did not make that change.

## 2. Seeds
- **How they were picked:** one `node -e` call at 01:49:54 UTC, before any image was generated.
  - It drew `crypto.randomInt(30000000, 99999999)` four times.
  - It would have rejected seeds on the used list (20261118, 20261302, 20261303, 20261900–20261999); none were rejected.
  - The draws went to A, B, C, D in order and are saved in `seeds.json`.
- **The seeds:**
  - **A = 39517106**: VARIANT=rc3, fmt1
  - **B = 56485346**: v52, fmt1
  - **C = 72612291**: VARIANT=rc3, RECEIPT_FORMAT=fmt2
  - **D = 84617896**: v52, RECEIPT_FORMAT=fmt2
- **Label check (labels.json only):**
  - Every set has 120 items, and the seed, variant and receiptFormat metadata are correct.
  - Each set has 106–127 distinct amounts.
  - No (kind, amount, date) combination is shared with the fixed sets or between sets.
- **Fresh receipt counts:** A 48 and B 24 (fmt1 = 72); C 48 and D 24 (fmt2 = 72).

## 3. Commands
All run from `/home/user/kabu-hantei/kurashi-calendar`, with `E=/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval`:
```
SEED=39517106 VARIANT=rc3                     node scripts/ocr-synth.mjs $E/A-rc3-fmt1-seed39517106 120
SEED=56485346                                 node scripts/ocr-synth.mjs $E/B-v52-fmt1-seed56485346 120
SEED=72612291 VARIANT=rc3 RECEIPT_FORMAT=fmt2 node scripts/ocr-synth.mjs $E/C-rc3-fmt2-seed72612291 120
SEED=84617896 RECEIPT_FORMAT=fmt2             node scripts/ocr-synth.mjs $E/D-v52-fmt2-seed84617896 120

KURASHI_OCR_PRE_EVAL=<set> KURASHI_OCR_PRE_REPORT=<out>/report.json KURASHI_OCR_PRE_VARIANTS=app \
  timeout 3000 npx vitest run src/lib/core/__tests__/ocr-preprocess-eval.gen.test.ts > <out>/run.log 2>&1
```
- `$E/run-all.sh` ran the measurements in pairs: (A, B), then (C, D), then (fixed rc3, fixed v52).
- For the fixed sets, `<set>` was `eval/ocr-fixed/...` and `<out>` was `$E/F1-rc3-unseen-seed20261302` and `$E/F2-v52-unseen-seed20261303`.
- **Each set was measured exactly once, with no reruns.**
  - All six runs exited 0 with "Tests 1 passed" and 120 rows.
  - Wall times: A 72s, B 46s, C 83s, D 51s, F1 72s, F2 48s.
- `analyze.mjs` reads only the report.json files. Its per-kind counts, recomputed from rows[], match summary.app exactly.

## 4. Per-set receipt results (summary.app)
How the columns are computed:
- **sure**: a draft with the correct amount exists and has no amount check flag.
- **confirm**: (n − sure) / n.
- **amount**: amount / n.

| Set | Seed / variant / format | Kind | n | amount | sure | date | unsafe | sure % | confirm % | amount % |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 fixed | 20261302 / rc3 / fmt1 | receipt | 24 | 24 | 24 | 21 | 0 | 100.00% | 0.00% | 100.00% |
| | | receiptDisc | 24 | 24 | 24 | 21 | 0 | 100.00% | 0.00% | 100.00% |
| F2 fixed | 20261303 / v52 / fmt1 | receipt | 24 | 24 | 24 | 20 | 0 | 100.00% | 0.00% | 100.00% |
| A fresh | 39517106 / rc3 / fmt1 | receipt | 24 | 24 | 24 | 20 | 0 | 100.00% | 0.00% | 100.00% |
| | | receiptDisc | 24 | 24 | 24 | 17 | 0 | 100.00% | 0.00% | 100.00% |
| B fresh | 56485346 / v52 / fmt1 | receipt | 24 | 24 | 23 | 21 | 0 | 95.83% | 4.16% | 100.00% |
| C fresh | 72612291 / rc3 / fmt2 | receipt | 24 | 20 | 19 | 20 | 0 | 79.16% | 20.83% | 83.33% |
| | | receiptDisc | 24 | 21 | 17 | 21 | **1** | 70.83% | 29.16% | 87.50% |
| D fresh | 84617896 / v52 / fmt2 | receipt | 24 | 22 | 20 | 22 | 0 | 83.33% | 16.66% | 91.66% |

Group totals:

| Group | n | sure (%) | confirm (%) | amount (%) | date (%) | unsafe |
|---|---|---|---|---|---|---|
| (a) fixed F1+F2 | 72 | 72 (100.00%) | 0 (0.00%) | 72 (100.00%) | 62 (86.11%) | 0 |
| (b1) fresh fmt1 A+B | 72 | 71 (98.61%) | 1 (1.38%) | 72 (100.00%) | 58 (80.55%) | 0 |
| (b2) fresh fmt2 C+D | 72 | 56 (77.77%) | 16 (22.22%) | 63 (87.50%) | 63 (87.50%) | 1 |

Split by the report's `photo` field:
- **fmt2:** photo receipts 28/41 sure (68.29%) with 1 unsafe; non-photo 28/31 (90.32%) with 0 unsafe.
- **Fresh fmt1:** photo 45/45; non-photo 26/27.
- **Fixed:** photo 48/48; non-photo 24/24.

### Receipts with sure = false or unsafe ≥ 1
File names and reasons are taken from report.json only.

**B (1)**
- `109-receipt.png`: correct amount, flagged for low character confidence (65). Not unsafe.

**C (12)**
- Correct amount, but flagged for confirmation (5):
  - `014-receiptDisc-photo.jpg`: total disagrees with the cross-check.
  - `059-receiptDisc.png`: low confidence (65).
  - `064-receiptDisc-photo.jpg`: total was set from the cross-check.
  - `074-receiptDisc-photo.jpg`: total disagrees with the cross-check.
  - `082-receipt-photo.jpg`: read as 11,895, corrected by the cross-check to 1,895.
- No draft with the correct amount (7):
  - `017-receipt-photo.jpg`, `027-receipt-photo.jpg`, `034-receiptDisc-photo.jpg`, `057-receipt-photo.jpg`, `072-receipt-photo.jpg`, `119-receiptDisc-photo.jpg`.
  - **`054-receiptDisc-photo.jpg`, unsafe = 1.** This is the only dangerous result among the 216 receipts measured.
    - Its row has `fields.points = false`, meaning a point value appeared among the drafts' amounts or amount options. All its other fields are true.
    - The report does not record the wrong value itself.

**D (4)**
- Correct amount but flagged:
  - `013-receipt.png`: total agrees with the cross-check only after correcting a misread.
  - `019-receipt.png`: total disagrees with the cross-check.
- No draft with the correct amount: `033-receipt-photo.jpg`, `049-receipt-photo.jpg`.

**F1, F2, A:** none.

The 16 fmt2 confirmation requests break down as follows:
- 7 had the correct amount but were flagged.
- 9 had no correct-amount draft. Of those, 8 had no registrable wrong value, and 1 (`054`) had one.

### fieldsSummary
Only the fresh sets have one, because the fixed sets' labels have no `fields`.

| Set | Kind | subtotal | tax | deposit | change | discount | points |
|---|---|---|---|---|---|---|---|
| A | receipt | 24/24 | 24/24 | 23/24 | 22/24 | – | – |
| A | receiptDisc | 24/24 | 24/24 | 24/24 | 23/24 | 24/24 | 24/24 |
| B | receipt | 24/24 | 24/24 | 24/24 | 23/24 | – | – |
| C | receipt | 18/24 | 20/24 | 13/24 | 15/24 | – | – |
| C | receiptDisc | 21/24 | 18/24 | 19/24 | 20/24 | 22/24 | 22/24 |
| D | receipt | 19/24 | 21/24 | 20/24 | 18/24 | – | – |

## 5. Non-receipt kinds (app path)
Each cell shows sure / n (sure %) followed by amount %. **unsafe = 0 for every non-receipt kind in all six sets.**

| Kind | Fixed F1+F2 | Fresh fmt1 A+B | Fresh fmt2 C+D |
|---|---|---|---|
| card | 48/48 (100.00%), 100% | 48/48 (100.00%), 100% | 48/48 (100.00%), 100% |
| cardDetail | 24/24 (100.00%), 100% | 24/24 (100.00%), 100% | 24/24 (100.00%), 100% |
| cardBill | 12/12 (100.00%), 100% | 12/12 (100.00%), 100% | 12/12 (100.00%), 100% |
| qr | 15/24 (62.50%), 83.33% | 15/24 (62.50%), 95.83% | 16/24 (66.66%), 87.50% |
| charge | 7/12 (58.33%), 100% | 7/12 (58.33%), 100% | 9/12 (75.00%), 100% |
| refund | 12/12 (100.00%), 100% | 12/12 (100.00%), 100% | 12/12 (100.00%), 100% |
| list | 32/36 (88.88%), 100% | 29/36 (80.55%), 100% | 36/36 (100.00%), 100% |
| balanceOnly | n = 0 (no transaction expected), unsafe 0 | same | same |

For non-receipt kinds, fmt2 changes only the shop names.

## 6. Speed
App path, milliseconds per image, measured inside the test (model load excluded).

| | F1 | F2 | A | B | C | D |
|---|---|---|---|---|---|---|
| Median / p95, all kinds | 345 / 1312 | 207 / 1348 | 325 / 1508 | 216 / 1047 | 370 / 1511 | 204 / 1273 |

Receipts only, median / p95: fixed 983 / 1691, fresh fmt1 996 / 1558, fresh fmt2 1191 / 1572.

## 7. Caveats
1. **No reruns.** Each of the six sets was measured once, and all exited 0.
2. **Tesseract warning.** Every run.log prints `Error opening data file ./.traineddata … Failed loading language ''` once.
   - Every run still passed with 120 rows.
   - It appears just the same in the fixed and fmt1 sets, which score 100% and 98.6%, so it does not explain the fmt2 drop. I did not investigate it further.
3. **What the metrics leave out.**
   - The frozen script's "sure" checks only for an *amount* flag. It does not also require `canRegister`, which needs a date, no date flag and a matching category.
   - "unsafe" counts only registrable drafts with a wrong amount. A registrable receipt with the right amount and a **wrong date** is not counted as dangerous.
   - Receipt date accuracy is 86.11% (fixed), 80.55% (fmt1) and 87.50% (fmt2). This script does not measure whether those wrong dates were flagged.
4. **Small samples.**
   - 95% Wilson intervals for receipt sure rate: fixed 72/72 is 94.9–100%, fmt1 71/72 is 92.5–99.8%, fmt2 56/72 is 66.9–85.8%.
   - PASS means the observed rate meets the target. It does not show that the true rate is at least 98%.
   - fmt1 passes by one receipt; set B alone is 23/24 (95.83%).
5. **Synthetic images only.** The fixed sets have no fieldsSummary.
6. **Speed is indicative.** Two runs shared a 4-vCPU machine, alongside the next-server on port 3600 and another agent's processes.
7. **The development results don't carry over to fmt2.** fmt2, the layout never used during development, has a proportional font, "円" after amounts, and different label wording and shop names. On it, sure falls to 77.77% and one dangerous registration appears.

## Files
All under `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/iq05-eval/`:
- `seeds.json`
- `run-all.sh`
- `runner.log`
- `analyze.mjs`
- `A-rc3-fmt1-seed39517106/`, `B-v52-fmt1-seed56485346/`, `C-rc3-fmt2-seed72612291/`, `D-v52-fmt2-seed84617896/`: each has `img/`, `labels.json`, `report.json` and `run.log`.
- `F1-rc3-unseen-seed20261302/`, `F2-v52-unseen-seed20261303/`: each has `report.json` and `run.log`.
