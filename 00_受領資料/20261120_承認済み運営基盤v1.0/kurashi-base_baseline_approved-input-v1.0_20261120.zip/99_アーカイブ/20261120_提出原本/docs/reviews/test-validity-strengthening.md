<!-- 独立の QA 担当の報告（そのまま保存）。弱い証拠の行の試験を強め、変異で確かめた。アプリのコードは直していない。2026-11-20 -->

## Summary
I added 8 new test files with 83 tests. All pass. The full suite `npx vitest run src/lib` gives 112 files passed and 4 skipped (the 4 skipped are the `.gen` files: ocr-eval, ocr-line-variants, ocr-preprocess-eval, restore-sql). That is 1413 tests passed and 4 skipped. `npx tsc --noEmit -p .` exits 0, and `npx eslint` on the new files exits 0. I made no changes to app code in the repo.

**Git state needs your attention.** While I was working, another process committed an in-progress copy of my 8 files as **9cff59a** (02:09). In that commit, `rcr-validity-se04.test.ts:114` has a typecheck error (TS2352). I fixed it in the working tree: I import `type KcbHeaderV2` and cast to it. That fix is not committed, because I was told not to commit. `git diff --stat src` shows only that one file.

## Per row: what the new test checks that the old one didn't

- **OC07** `src/lib/core/__tests__/rcr-validity-oc07.test.ts`
  - Asserts `investBucket` is null with no `if` around it.
  - With `categoryConfirmed:true` and `fieldChecks:[]`, `canRegister` and `initiallySelected` are false. Adding any of the 4 buckets makes `canRegister` true, so the bucket is the only cause.
  - Each bucket wording maps to the right bucket; plain "NISA" gives null.
  - `changeDraftType` to investment resets the bucket and blocks registration.
  - `draftChanges` writes the bucket to `subcategory`.
  - The confirmation-required tests for ambiguous transfers fail, so they are in the scratch file (defect 1 below).
- **LG02** `src/lib/core/__tests__/rcr-validity-lg02.test.ts`
  - Steps: refund → recovery → write-off → later recovery. At each step, `advanceStatus().history` must equal a hand-written list (kind, subcategory, amount, date, source id, status) in newest-first order.
  - Excluded from history: needs_review refunds, another source's recovery, and the source expense itself.
  - Earlier entries carry over unchanged at every step.
  - Monthly own-spend lands on the right dates: Oct 9,000, Nov 3,000.
  - A recovery larger than what is outstanding splits into recovery + reversal rows.
- **WG04** `src/lib/server/__tests__/rcr-validity-wg04.test.ts`
  - Known SHA-256 values written as literals, computed separately with `sha256sum`. They cover `hashToken` ("abc", empty string, Japanese text, a fixed `kc_wg_` token) and `hashLinkCode`.
  - For each of the 3 scopes, the stored `secretHash` equals node:crypto SHA-256 of the token, is not the token, does not contain it, and is 64 hex characters. The device list API returns neither the hash nor the token.
  - Lookup also hashes: a row that stored the plaintext token gets 401.
  - All 3×3 key/endpoint pairs: only matching scopes work; the rest get 403 and write nothing.
  - The prefix check and the database-scope check are each tested on their own.
  - A token in the URL query gets 401.
- **FIN02** `src/lib/server/__tests__/rcr-validity-fin02.test.ts`
  - For expense, income, transfer, refund and investment, at both the schema and `handleMutate` (MemoryRepo):
    - 100,000,000 is accepted and stored exactly.
    - These are rejected with 400 and nothing is stored: 100,000,001, -1, 0.5, 1.5, 1e13, NaN, Infinity, "1000", and values beyond the safe-integer range.
  - A batch mixing good and bad rows stores nothing.
  - The same limit applies to advance, recurring rule, occurrence and event budget amounts.
  - Movement limits differ by kind: adjustment may be negative, 0 is rejected, the limit is ±1 trillion. Card statements are 0 to 1 trillion.
  - The test reads the DB CHECK bound from `supabase/migrations/20261114000000_init.sql:129` and asserts it equals the API limit.
  - The user entry paths reject 0.
- **RC4-02** `src/lib/core/__tests__/rcr-validity-rc4-02.test.ts`
  - Uses the real `accountBalance` and the same calls as AccountsView.tsx:33-34/78-88 and HomeView.tsx:98.
  - At each step (unpaid 80k → statement → 30k partial payment → full payment), the accounts-screen total equals the home 差引 and a hand value, including per-account balances.
  - After full payment the archived card leaves the list. An archived bank account is never counted.
  - Control: a non-archived card stays in the list after payment.
- **SE04** `src/lib/core/__tests__/rcr-validity-se04.test.ts`
  - The PBKDF2 parameters (kdf, iteration count, salt), the IV and the ciphertext stay identical; I checked this in each test. Only the header changes:
    - v1: `v` changed to 1.5 (still passes the format checks), `"v":1.0` (same value, different bytes), added `createdAt`, reordered keys, added whitespace, and `len` plus one extra byte.
    - v2: the same kinds of changes, plus an extra field inside `pk`.
  - All are rejected with `decrypt`. Control: rewriting the identical header still decrypts.
  - **Every header field in v1 and v2 is authenticated**, because the whole header byte string is the AES-GCM AAD. I found no unauthenticated field.
- **REV01** `src/lib/server/__tests__/rcr-validity-rev01.test.ts`
  - Production path: `handleDataset` → real `requireUser` with Supabase → `SupabaseRepo`. The fake client is PostgREST-like: it applies the filters, ordering and range, and caps responses at 1000 rows.
  - Data: 1,701 investment rows and 1,700 rows in the date range, so both need 2 pages. A 2024 cancellation with no category is linked to a purchase in the 9th group of 150 ids.
  - Result: used 3,400,000 and remaining 14,600,000. All 2,902 rows are loaded, with no duplicates, no other-user rows, and no 2024 household rows.
  - Every read carries the `user_id` filter. The `laterRefunds` group-of-150 path is also covered.
- **SE06** `src/lib/server/__tests__/rcr-validity-se06.test.ts`
  - The existing `rcr-delete-all.test.ts` does build the table list from the migrations. But it regex-reads the *source text* of `deleteAllData` and never runs it.
  - The new test parses the SQL itself, stripping comments and function bodies and splitting columns at the top bracket level. It then runs `deleteAllData` against a recording fake client and checks:
    - Each user_id table gets exactly `delete().eq('user_id', U)`.
    - Tables without user_id must be classified: `push_report_log` cascades from `push_subscriptions`; `beta_allowed_emails` and `api_rate_events` hold no per-user rows.
    - Tables whose foreign keys are neither cascade nor set null are deleted child-first (card_statements and account_movements before money_accounts).
    - A database error on any table makes the call fail; "table missing" is tolerated only for tables added in later migrations.
  - **No table is missing:** all 25 user_id tables are deleted.

## Mutation check
I ran the mutations in a scratch copy of the repo whose `src` was identical to HEAD, then deleted the copy. 30 mutations, 3 to 6 per row, including audit mutations #2, #4, #6, #9 and #10. **All 30 are caught by the new tests. 23 of them are missed by the previously cited tests**, for example: `history=[]`, removing the AAD, `yen` max raised to 1e9, both scope checks removed, only the first group of 150 read, the `user_id` filter on the wrong column, and the delete order reversed. The runner scripts are `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/mutations.py` and `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/mutations_old.py`.

## Suspected defects
The failing tests are only in `/tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/validity-failing.test.ts`. All 10 fail on the intended assertion. Run them with `npx vitest run --config /tmp/claude-0/-home-user-kabu-hantei/400c991e-db06-5080-b112-7f50d6b01692/scratchpad/vitest.scratch.config.mjs validity-failing`.

1. **OC07: ambiguous transfers can be registered, and are pre-selected, without any confirmation.**
   - `buildDrafts({text:'証券会社D\n2026/11/17\n入金がありました 50,000円', capturedAt:'2026-11-17T10:00:00.000Z'}, ds())` gives type transfer with confidence `typeLevel:'low'` and the reason "買い付けなら投資に直して". Yet `canRegister` and `initiallySelected` are both true.
   - The same happens for `山田さんに送金しました 3,000円`: it is labelled the user's own money moving, and is registrable.
   - A card bill whose draft carries "確かめてください" has `initiallySelected` true.
   - `口座振替 12,000円 電気代` is classified as a transfer and pre-selected.
   - Cause: `screenshot.ts:342` `if (d.type === 'transfer') return true;`. There is no gate on `typeLevel` or on a confirmed type. `initiallySelected` excludes only duplicate and fixed-cost checks.
2. **FIN02: the UI accepts amounts above the API/DB limit of 100,000,000.**
   - `evalAmount('100,000,001')` returns 100000001; its cap is 1e9 (`insights.ts:115`).
   - `MoneyForm.tsx:139` checks only `>0` and safe integer.
   - Screenshot `canRegister` has no maximum: a draft edited to 100,000,001 returns true.
   - `transactionSchema` rejects these, so `/api/mutate` returns 400 and the change cannot be sent.
3. **FIN02 (low confidence; needs a spec decision): a confirmed transaction of 0 yen is accepted by the API for every kind.** `yen` is `min(0)` and the DB CHECK is `>=0`. 0 is used on purpose as the placeholder amount for needs_review ingests (`pipeline.ts:87`), and the UI rejects 0. But there is no zero check that depends on kind or status.
