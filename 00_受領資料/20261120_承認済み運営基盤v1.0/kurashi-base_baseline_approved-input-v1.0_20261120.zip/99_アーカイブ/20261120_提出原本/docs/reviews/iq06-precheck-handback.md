<!-- 独立の担当の報告（そのまま保存。実装者の要約ではない）。担当は実装を直していない。2026-11-20 -->

## IQ06 pre-check: REPORT.md not written, full text below

The tool refused the REPORT.md write ("Subagents should return findings as text, not write report files"), so I did not get around it. Please save the block below as `/home/user/kabu-hantei/kurashi-calendar/quality/evidence/iq06-precheck/REPORT.md`. Everything else is in that folder: `screenshots/`, `actions.log`, `tasks.log`, `replay-result.json`, `step.js`, `replay.js`, `make-receipt.js` and `fixtures/fake-receipt.png`. I changed nothing else in the repo. I started no servers; each step script launched its own headless browser. I deleted the browser profile and the downloaded `.kcb` backups afterwards.

**The app did not offer a storage choice on first open.** It started in クラウド同期 without a login, so the first save failed. I switched to この端末だけ through the 「未ログイン」 chip, which is not signposted (P1).

**Results**

| Task | Success | Steps (ideal) | Seconds: exploration / clean replay | Wrong turns | Unclear moments |
|---|---|---|---|---|---|
| T1 Expense ¥1,280 | Yes, only after a workaround | 14 (4) | 73 / 4.3 | 2 | After the save error, no way forward on screen; amount lost |
| T2 Image import | Yes, confirmation appears before anything is registered (not registered) | 1 to picker, 3 to upload | 91 / 2.7 | 0 | Why 「登録」 stays disabled; help text overlapped |
| T3 歯医者 Tue 11/24 15–16 | Yes | 7 | 43 / 1.7 | 0 | Minor: default start time 19:00 |
| T4 Change to ¥1,380 | Yes, ¥1,380 shown in 家計 › 履歴 | 7 | 42 / 2.6 | 0 | None |
| T5 Backup and restore | Yes: `.kcb` exported, restore preview opened, step 3 not pressed | 5 + 4 | 58 / 2.0 | 0 | Jargon |
| T6 Widget page | Page found; next step not understandable in この端末だけ mode | 2 | 30 / 1.6 | 0 | Dead end |

**Top problems**
- **Blocking (P1):** a first-time user can't save in the default mode. The error 「ログインしていないため保存できませんでした。入力はそのまま残しています」 has no button or link. 「ログインする」 leads to an invitation-only page that doesn't mention この端末だけ.
- **Major:**
  - P2: the typed expense is gone after going to fix P1, even though the message says the input is kept.
  - P3: on the import confirmation, the sticky footer text is printed over the card text, and three separate actions are needed to enable 「登録」.
  - P4: in この端末だけ mode the widget page says 「ウィジェットはつなげません」 but still marks step 1 「いまここ」 (install Scriptable). Step 2 has no link, and it refers to a 「つながったか確かめる」 button that isn't shown.
- **Minor:**
  - P5: translucent header and nav let text show through.
  - P6: the sticky 「保存」 button covers the memo field.
  - P7: the storage-switch confirmation appears under the wrong option.
  - P8: invisible status chip in local mode.
  - P9: jargon in backup and restore.
  - P10: the import privacy wording conflicts with saved candidates.
  - P11: back link says 「家計」 from Home; default start time 19:00.

This automated pre-check does not replace testing with real users on a real iPhone.

---BEGIN REPORT.md---
# IQ06 pre-check: first-time user tasks (automated, screen-only)

- Date: 2026-11-20 (JST). Target: production-like build at `http://localhost:3600`. Access code `test-aikotoba` was entered at `/gate`.
- Method: Playwright 1.63 headless Chromium, fresh profile, 390×844, `isMobile`/`hasTouch`, iPhone user agent, `ja-JP`, `Asia/Tokyo`. I chose every tap from visible text, the ARIA snapshot and screenshots I took and looked at. I did not read the app's source code or e2e scripts. All data was fictitious: an expense of ¥1,280 → ¥1,380, the event 「歯医者」, a generated receipt image for 「テスト商店 架空店」 and the passphrase `kasou-tesuto-…-2026`.
- Two runs:
  1. **Exploration run** (`step.js`). Each step launched the same persistent profile, so typed but unsaved input was lost between steps and some steps were replayed. Every action is logged with a timestamp in `actions.log`, and the task start and end times are in `tasks.log`.
  2. **Clean replay** (`replay.js`). The paths found in the exploration run were replayed in one fresh browser context, without relaunching, to measure machine-only time and to recheck the problems. Results are in `replay-result.json` and `screenshots/R-*.png`.
- Storage choice: **the app did not ask on first open** how to store data. It started in 「クラウド同期（Supabase）」 without a login. I chose 「この端末だけ」 after the first save failed (see P1).

> **This automated pre-check does not replace testing with real users on a real iPhone.** The run used headless Chromium, not Safari or WebKit. Native date, time and file pickers, the software keyboard, Add to Home Screen/PWA behaviour, Scriptable and real widget rendering were not exercised. The automated agent also learns across tasks (for example, it had already seen the Settings list in T5 before T6). The times are machine or agent times, not human times.

## Results T1–T6

| Task | Success | Steps taken (ideal) | Seconds: exploration / clean replay | Wrong turns / backtracks | Moments where the next step was unclear | Error messages |
|---|---|---|---|---|---|---|
| T1 Expense ¥1,280 コンビニ today | **Yes, only after a workaround** | 14 (4 once storage is set) | 73 / 4.3 | 2: first save failed; the 「ログインする」 path led to an invitation-only login page (dead end) | After the failure there was no way forward on screen. The fix (status chip → 「データと保存先」 → 「この端末だけ」 → 「切り替える」) is not signposted. The typed amount was gone afterwards. | 「ログインしていないため保存できませんでした。入力はそのまま残しています」 |
| T2 Image import (画像取込み) | Yes. Picker screen reached in 1 tap. A test PNG was uploaded. **A confirmation step appeared, and nothing was registered without explicit confirmation.** I stopped before registering. | 1 to the picker screen, 3 to upload (registering would need 3 more: category, 「登録する」 checkbox, bottom button) | 91 / 2.7 (OCR about 1–2 s on a desktop CPU) | 0 (1 automation retry, not a UX issue) | Why the bottom button stays disabled. Its help text is printed over other text and can't be read. The 「登録する」 checkbox is off-screen when you choose the category. | none (button label 「登録する候補を選んでください」 while disabled) |
| T3 Event 「歯医者」 Tue 11/24 15:00–16:00 | Yes | 7 (more on iPhone, because native pickers need about 2 taps each) | 43 / 1.7 | 0 | Minor: 「日付を指定」 opens only a native picker (not visible headless). The start time defaults to 19:00 and the end time is empty. | none |
| T4 Change to ¥1,380 and verify in history | Yes | 5 to edit and save, plus 2 for 家計 → 履歴 (7) | 42 / 2.6 | 0 | none. After saving, the day view already showed −¥1,380, and 家計 › 履歴 showed it too. | none |
| T5 Encrypted backup and restore entry | Yes. A `.kcb` file was downloaded (then discarded). Restore entry found, and 「2. 中身を見る（まだ何も変えません）」 previewed the file. **Step 3 was not pressed.** | 5 to export (設定 → バックアップ → passphrase ×2 → 「暗号化して書き出す」), 4 more to preview a restore (9) | 58 / 2.0 | 0 | After exporting: 「ブラウザからは、ファイルが保存できたかが分かりません」. It is honest but leaves the user unsure. The restore preview uses jargon. | none |
| T6 Widget setup page | Page found: yes (設定 → 「ウィジェット」, 2 taps). **Would a first-time user know what to do next? No**, in 「この端末だけ」 mode. | 2 | 30 / 1.6 | 0 (but with prior knowledge of Settings from T5) | The page says the widget can't be connected, yet still marks step 1 「いまここ」 and asks you to install Scriptable. Step 2 has no link to fix the prerequisite. | none (status 「ウィジェットはつなげません」) |

"Exploration" seconds come from `tasks.log`. They include the agent's own analysis and the per-step browser relaunch, so they are only a rough upper bound. "Clean replay" seconds are pure automation time with no think time. Neither is a human time.

## Usability problems, by severity

### Blocking

**P1. A first-time user can't save anything: the app starts in cloud mode without a login, and the error gives no way out.**
- On first open, no storage choice was offered (`01-after-gate.png`). The header shows a red banner 「ログインしていません。ログインする」 and a chip 「● 未ログイン」. In 「データと保存先」 the default radio is 「クラウド同期（Supabase）」 (`T1-05-settings-data.png`).
- The first save fails with the red message **「ログインしていないため保存できませんでした。入力はそのまま残しています」** (`T1-03-after-submit.png`, `R-T1-save-error.png`). The message has no button or link.
- The obvious next step, 「ログインする」, opens an invitation-only page: **「くらしベースは招待制の友達限定のテスト版です。招待されたメールアドレスだけが使えます。」** It doesn't mention 「この端末だけ」 (`T1-04-login-page.png`).
- The working route was: tap the small 「未ログイン」 chip → 「データと保存先」 → radio 「この端末だけ」 → 「切り替える」 → back to Home → enter everything again (`T1-06-after-choose-local.png`, `T1-07-after-switch.png`). I found it only by trying the chip. An uninvited user is stuck. An invited user is still forced to log in before recording anything.
- Minimal fixes (pick one or more):
  - Offer the three storage choices once on first open, or default to 「この端末だけ」 when nobody is logged in.
  - Add a button to the save-failure message, such as 「この端末だけに保存する」 or 「保存先を選ぶ」 → `/settings/data#mode`.
  - Add one line to the login page: 「招待がない方は『この端末だけ』で使えます」 with a link.

### Major

**P2. The typed expense is lost while the user fixes P1, even though the message says the input is kept.**
- In the clean replay, the amount field was empty after the detour (close sheet → login page → status chip → switch → Home → 「支出・収入」). `replay-result.json` shows `amount kept after detour=""`.
- Wording that misleads here: 「入力はそのまま残しています」. The event form already restores drafts (「保存していない入力があります（歯医者・…）。まだ記録していません。入力に戻す / 捨てる」, `T3-05-before-submit.png`).
- Minimal fix: keep the expense sheet draft the same way the event form does, or reword the message to 「この画面を閉じると入力は消えます」.

**P3. Image import confirmation: the instructions overlap other text, and the confirm control is hard to find.**
- The sticky bottom area (disabled button 「登録する候補を選んでください」 plus the text **「確かめた候補の『登録する』に、チェックを入れてください。」**) has no solid background. Its text is drawn on top of the card text and can't be read (`T2-04-after-read-viewport.png`, `T2-08-candidate-top-after-category.png`).
- To register you need three actions in three places:
  1. Choose a category, or tap 「このカテゴリ（その他）でよい」, near the bottom of the card.
  2. Scroll up and tick the small 「登録する」 checkbox next to the candidate title.
  3. Press the bottom button.
- When you choose the category, the checkbox is off-screen and the button stays disabled (`T2-07-after-category.png`).
- Positive: the safety promise holds. 「確かめて『登録』を押すまで、何も記録しません。」 is true, and the confidence hints are good (「カテゴリの確かさ：低 店名から分類できません」).
- Minimal fixes:
  - Give the sticky footer an opaque background, and add bottom padding to the page so content can scroll clear of it.
  - Tick 「登録する」 automatically once the user has confirmed the category, or repeat the checkbox at the bottom of each card.

**P4. In 「この端末だけ」 mode the widget page sends the user to a dead end.**
- Status: **「いまは『この端末だけ』なので、ウィジェットはつなげません（実際には、つながっていません。下の見た目は目安）。」** Step 1 is still badged **「いまここ」** and says 「App Store で Scriptable（無料）を入れる。」 (`T6-01-widget-page.png`).
- Step 2 only says **「クラウド同期でログインすると、ここでつなげます。」**, with no link, and login is invitation-only (`T6-02-step2-connect.png`).
- 「うまくいかないとき」 refers to **「上の『つながったか確かめる』」**, but no such control is visible in this mode.
- A first-time user would understand the three steps in general. They would not know what to do next, and might install a third-party app for nothing.
- Minimal fixes:
  - In local mode, move the 「いまここ」 badge to a prerequisite line: 「ウィジェットにはクラウド同期（招待制）が必要です」, with a link to 「データと保存先」.
  - Grey out steps 1–3 until that prerequisite is met.
  - Show the troubleshooting paragraph only when the button exists.

### Minor

**P5. The translucent sticky header and bottom navigation let page text show through.** Text collides with 「くらしベース」 and with the tab labels (`T5-04-after-export.png`, `T5-07-restore-preview.png`, `T6-02-step2-connect.png`, `T6-03-step3-place.png`). The rendered backgrounds were measured at about 88% and 94% opacity, with no blur. Fix: use opaque backgrounds, or check the blur on iOS Safari.

**P6. The sticky 「保存」 button covers the 「メモ」 field** on 「記録を編集」 (`T4-03-edit-form.png`). Fix: add bottom padding equal to the button height.

**P7. The storage-switch confirmation appears under the wrong option.** After tapping 「この端末だけ」, the radio still shows 「クラウド同期」 as selected. The confirmation 「『この端末だけ』に切り替えます…」 with 「切り替える / やめる」 appears below the cloud option (`T1-06-after-choose-local.png`). Fix: show the box under the chosen option, or mark that option as pending.

**P8. Invisible status chip in local mode.** The header link with accessible name 「同期の状態: この端末」 is an empty 20×28 px tap target. Sighted users see no storage indicator, while screen-reader users hear a link that sighted users can't see (`X-home-local-mode-header.png`). Fix: show a small 「この端末」 label, or remove the empty link.

**P9. Jargon in backup and restore.** Examples:
- 「クラウドでは、できるだけ1回のトランザクションで入れます（全部入るか、何も入らないか）」
- The table headings 「競合」 and 「似ている」
- 「形式の版：1・同期がそろっていたとき」
- 「トークン・端末キー」
- The checkbox 「月の予算などの設定も、バックアップの内容にする」, which doesn't say whether current settings are overwritten.

Screenshots: `T5-02-backup-page.png`, `T5-07-restore-preview.png`. Fixes: drop the transaction sentence in 「この端末だけ」 mode, and reword the checkbox as 「…設定も、バックアップの内容で上書きする」.

**P10. The image-import privacy wording conflicts with what the app keeps.** The page says 「画像と読み取った文字は保存も送信もしません」, but after leaving, the app shows 「前回の候補が 1件 残っています まだ登録していません」 (`T2-04-after-read-viewport.png`). Fix: add 「候補（金額・店名・日付）は登録か『捨てる』まで、この端末に残ります」.

**P11. Small wayfinding issues.**
- The import page's back link reads 「‹ 家計」 even when it was opened from Home (`T2-01-import-page.png`).
- The new-event form defaults the start time to 19:00 with an empty end time, so both had to be changed (`T3-03-after-time-check.png`).

## What worked well
- T3 and T4 were direct, with no wrong turns. The success messages name what was saved and offer 「取り消す」 (「支出 ¥1,280（コンビニ）を記録しました」, 「予定『歯医者』を追加しました」, 「保存しました」).
- Image import reads only on the device, says clearly that nothing is registered until confirmed, and the confirmation step really appeared.
- Backup: the passphrase rule (「12文字以上」, 「十分な長さです」) and the warning 「忘れると、このバックアップは誰にも戻せません。」 are clear. The restore steps 「1. ファイルを選ぶ → 2. 中身を見る（まだ何も変えません）→ 3. 足す」 are safe, and re-importing the same file reported 「3. 足すものはありません（すべて同じ）」 (no duplicates).
- No page errors were recorded in the clean replay.

## Test-environment caveats (not app findings)
- Date and time inputs appear as `11/20/2026` and `03:00 PM` in screenshots because headless Chromium uses US formatting for native inputs. iPhone Safari will show its own pickers.
- The software keyboard was not simulated. On a real iPhone the keyboard may cover 「支出を記録」 while the amount field is focused; this was not checked.
- The OCR speed (about 1–2 s here) and the real Scriptable widget were not measured on a device.

## Files
- `screenshots/` holds the screenshots named above. `T*` files come from the exploration run, `R-*` from the clean replay, and `X-*` from a probe.
- `actions.log` (every action, with time) and `tasks.log` (task start and end times).
- `replay-result.json` holds the clean replay results: steps, seconds and notes per task.
- Scripts: `step.js` (exploration runner), `replay.js` (clean replay), `make-receipt.js` (generates `fixtures/fake-receipt.png`, a fictitious receipt).
- The browser profile and the downloaded `.kcb` backups were deleted after the run.
---END REPORT.md---
