<!-- 独立のリリース審査担当（IQ08）の報告（そのまま保存。実装者の要約ではない）／Independent release reviewer's report (IQ08), saved as-is. 2026-11-20 -->

# IQ08 independent release review: kurashi-calendar, final code 17c6d26

Reviewer: independent release reviewer (IQ08). I did not implement anything here. I set out to falsify the implementer's claims. Untested or not-run items are never counted as PASS.

Scope: branch `claude/kurashi-root-cause`. HEAD was `1a2b26b` when I started and `e3d9f3a` when I finished; the implementer committed the mutation results while I was reviewing. The code was frozen at `17c6d26`, and `git diff 17c6d26 e3d9f3a -- src scripts eval supabase` is still empty. The final regression evidence is in `quality/evidence/final-17c6d26/` and the mutation results are in `quality/evidence/iq01/final-17c6d26/`.

I modified no product code, tests, evidence or docs. The only file I wrote is this report. I made no commits, ran no state-changing git commands, and touched no real database or external service.

While mutation run IQ01 was running, I ran no E2E, build, server or full vitest suite. I did not touch `.rcr-mut` or port 3410 either.

## 1. Verdicts

### IQ01 to IQ08

| ID | Verdict | Reason (one line) | Evidence |
|---|---|---|---|
| IQ01 detection power | **PASS** | 58 mutants: 56 killed, 2 survived (M07, M39), 0 invalid, worktree clean. The M39 equivalence argument is sound. M07 is not strictly equivalent: the "unsent N" count differs. It is an acknowledged test gap, but data-safe. Sampled e2e kills all fail on the mutated behaviour. M57 and M58 are killed by the RC-U09 loading test, and M58 by its content check. | `quality/evidence/iq01/final-17c6d26/RESULTS.json`, `M5[78].e2e_e2e_qr_ui.log` |
| IQ02 independent oracle | **PASS** (local) | The model imports only types from the implementation. The final vitest run passes 162/162. However, the ledger's cited "green" for D1–D4 actually contains a failing test (discrepancy D5). | `src/lib/core/__tests__/iq02/model.ts`, `final-17c6d26/vitest-results.json` |
| IQ03 faults on the real path | **BLOCKED** | The local fault behaviour passes (`e2e-rcr-faults` 4/4, `e2e-rcr-storage` 3/3). But the e2e server side is MemoryRepo plus `setTestUsers`, reached through Playwright route interception, not PostgreSQL as the status claims. "DB abort" is an injected 500. A real Supabase, an iPhone force-quit and a power cut need an external environment or a person. | `scripts/lib/real-api.mjs`, `scripts/e2e-rcr-faults.mjs`, `final-17c6d26/e2e-rcr-faults.log` |
| IQ04 long-term (simulated) | **PASS** (simulation only) | 1 year + 1 month of data, 4 time zones, same results, with counts and timings recorded. The card and forecast checks are only implementation self-consistency or smoke tests. Not a substitute for real use. | `final-17c6d26/iq04-*.log`, `iq04-*.json` |
| IQ05 OCR | **FAIL** (real images BLOCKED) | Unconfirmed accuracy is fmt2 77.7% and fmt3 88.8%. Counting dates too, it is at most 86.1% on fixed and 93.0% on fmt1; the target is 98%. Dangerous errors: 0. | `reviews/iq05-frozen-eval-4.md`, `quality/evidence/iq05-frozen-eval-final/` |
| IQ06 users (iPhone) | **BLOCKED** | The owner's real-device, unguided record is missing. The automated pre-check does not replace it. | `IQ06_DEVICE_PROCEDURE.md`, `final-17c6d26/e2e-rcr-ux.log` |
| IQ07 security (isolated environment) | **BLOCKED** | The local findings were reproduced and fixed. The isolated Supabase run (Auth, PostgREST, rate limits) has not been approved or run. | `IQ03_IQ04_IQ06_IQ07.md`, `OWNER_STEPS.md` |
| IQ08 independent release review | **FAIL** | Final HEAD, clean tree, exit codes, counts, baseline hash and the three gates all reproduce. The ledger and log correspondence fails for several rows (D4–D7). One PASS row is not true at the final HEAD (D3), and 4 PASS rows that the audit rated WEAK were never addressed (D1). The IQ03 environment is misstated (D2). | This report, §8 |

### QG01 to QG13

| QG | Verdict | Reason (one line) | Evidence |
|---|---|---|---|
| QG01 | PASS (local) | Two Chromium tabs saving at once, a restart, 50 random orderings. WebKit not run. | `final-17c6d26/e2e-qr-storage.log`, `vitest.log` |
| QG02 | PASS (local) | abort, quota and no-IndexedDB cases do not show success, and the input is kept. M01 and M04 are killed. | `final-17c6d26/e2e-qr-storage.log`, `e2e-normal.log` |
| QG03 | PASS (local) | Old localStorage migration: 2 tabs, interruption, corrupt old data. The old SW is covered by SE08 (80/80). | `final-17c6d26/e2e-qr-storage.log`, `e2e-qr-sw-update-*.log` |
| QG04 | PASS (local) | A failed ingest save keeps the text, and a retry inserts once. M05 and M06 are killed by QG04. | `final-17c6d26/e2e-qr-storage.log` |
| QG05 | PASS (local) | Conflict parking, resends and other-account rejection. The server side is MemoryRepo. The DB function semantics are tested on real PostgreSQL (`test-db`). Real cloud not run. | `final-17c6d26/e2e-qr-sync.log`, `test-db.log` |
| QG06 | PASS | Card boundary × state matrix (55 tests). M09–M13 are killed. | `final-17c6d26/vitest.log`, `e2e-qr-finance.log` |
| QG07 | PASS (local) | Two vertical slices (6/6 and 25/25), including backup and restore to another store. Restore on an isolated Supabase (DATA03) is external. | `final-17c6d26/e2e-qr-slice*.log` |
| QG08 | **BLOCKED** | The owner must do the post-login checks on the real preview. "Separate project" is not met (RC4-09). The live preview is still `86456b4`, not `17c6d26`. | `quality/evidence/night-preview-final/deploy-in-project.log`, `final-17c6d26/preview-verify-local.log` |
| QG09 | PASS (simulated) | The deploy-script failure tests and ops03 rollback A–E all pass. ops03 was built at `9a70994`, which has the same source. Production not run. | `final-17c6d26/ops03-run.log` |
| QG10 | **FAIL** | Gate local fails (2: OC04, RC-U01) and release fails (28). I reran both and they match the stored output. | `final-17c6d26/gate-*.json` |
| QG11 | PASS (local) | Brand upgrade 3/3 keeps the data, theme and caches. The iPhone home-icon swap is left to the owner. | `final-17c6d26/e2e-night-brand-upgrade.log` |
| QG12 | PASS (local) | Tap targets, focus and keyboard-only input 7/7. Visual hierarchy is a human check (RC-U01). | `final-17c6d26/e2e-night-ux.log` |
| QG13 | PASS (local) | Rehearsal reports FAIL 0, but see D9: section F shows an existing test failing under Supabase's auto-expose privileges. That is not in the QG13 notes. | `final-17c6d26/db-rehearsal.log` |

### Friend-release decision: **NO-GO**

The handoff's conditions are not met:

- The fixed 265 rows are not all PASS: 237/265, which is 89.43%.
- QG08 is BLOCKED and QG10 is FAIL.
- IQ05 is FAIL, IQ03, IQ06 and IQ07 are BLOCKED, and IQ08 is FAIL.
- There is no real-device, isolated-DB or real-deployment evidence for 17c6d26.
- The owner has not approved the release.

The review-only preview is a separate decision. It is still at 86456b4 and was not redeployed in this phase.

## 2. Final HEAD and freeze (check 1)

- **Clean tree at the start of the run.** `00-env.txt` gives HEAD 17c6d26 at 05:40:21Z and "dirty 1 files". The one dirty entry is the output folder itself: the `00-env.txt` redirect creates it before `git status` runs, and git lists an untracked directory as a single line.
- **No commits during the run.** 17c6d26 was committed at 05:40:11. The next commit is 9a70994 at 06:06:52, after `head-unchanged` ran.
- **Both builds embedded 17c6d26.** `preview-verify-local.log` shows "コミット：17c6d26". Both `.next/static` and `.next-review/static` (BUILD_ID 05:43) contain `17c6d26` and not `9a70994`.
- **No source change after the freeze.**
  - `git diff 17c6d26 HEAD -- src scripts eval supabase` is empty.
  - `git diff --name-only 17c6d26 HEAD` touches only `kurashi-calendar/docs/` (6 files) and `kurashi-calendar/quality/` (867 files).
  - The gate script `quality/quality_gate.py` did not change. Only RESULTS, ADDITIONAL_GATES, the ledger and its build script, verdicts and evidence changed.
- **Some evidence ran on 9a70994, not 17c6d26.** The mutation worktree (`worktreeHead` 9a70994) and the ops03 build both ran on 9a70994, an evidence-only commit with source identical to 17c6d26.

## 3. Step logs versus exit codes (check 2)

All 37 steps in `00-summary.txt` have exit=0, and the run ended with `done`. Test counts are taken from the logs.

| Step | Count inside the log | Contradiction? |
|---|---|---|
| lint | 0 errors, 2 warnings | no |
| typecheck | no output (tsc) | no |
| vitest | 1431 tests: **1427 passed, 0 failed, 4 skipped**. 118 files (114 passed, 4 skipped). The JSON marks all 118 files as "passed" | The skips are the env-gated `.gen` suites (OCR eval ×3, SQL generator ×1). OC08 relies on one of them (D1) |
| iq04 ×4 | 8/8 each. The start times reflect each TZ (UTC 05:41, Tokyo 14:41, LA 21:41, Kiritimati 19:41) | no |
| test-db | every suite "すべて成功". The only ERROR line is the expected concurrency conflict | no |
| db-rehearsal | "結果：すべて PASS（FAIL 0）" | **partly**: §F lists "13 件成功・1 件失敗" and §G "55 件成功・4 件失敗", and §E logs a segfault while restoring a corrupt dump. These are reported but not counted as FAIL (D9) |
| widget | 49/49 | no |
| build-normal, build-review | route tables, exit 0 | no |
| bundle-secrets | "秘密の値は入っていません（304ファイル）" | no |
| e2e-normal | 63/63 | no |
| e2e-night-ux | 7/7 | no |
| e2e-qr-cal / finance / ocr / slice / slice2 / storage / sync / ui | 48 / 8 / 25 / 6 / 25 / 5 / 8 / 30 | no |
| e2e-rcr-faults / storage / ux | 4 / 3 / 14 | no |
| e2e-qr-sw-update ×4 | 20/20 each, `failedSeeds:[]` | the line "/sw.js を返した版：" is blank, while the JSON says v3 (cosmetic) |
| e2e-night-brand-upgrade | 3/3 (PREBRAND_DIR was supplied) | no |
| ui-review-sheet | 57 screens | not a pass/fail step |
| e2e-review / e2e-review-qr | 14 / 7 | no |
| preview-verify-local | every check ok, commit 17c6d26 | no |
| review-guard | the unsafe configurations return 503 and the correct one 401 | no |
| head-unchanged | **0-byte log**. The exit code is its only evidence | weak (D7) |

The E2E harness has no retry logic, and no log contains a skip, a retry or a timeout under an `ok`. There are no error lines in `server-normal.log`.

## 4. Ledger versus logs (check 3): 16 rows sampled, plus a scan of all 40 FIXED rows

The ledger is reproducible. Running `build_ledger.py` with a redirected output dir produces a byte-identical `ROOT_CAUSE_LEDGER.csv` and `ROOT_CAUSE_SUBCONDITIONS.csv`. `ROOT_CAUSE_LEDGER_INPUT.csv` matches the handoff's ledger. All fix commits exist and are ancestors of 17c6d26.

**Reds I reproduced myself.** I ran each current test file against the pre-fix source, taken read-only with `git archive <fix>^` into a scratch dir:

- `rcr-iq05-receipt-points.test.ts` @ d7c1667^ gives 2 failed / 1 passed. The P0 receipt case fails, which shows the red is genuine.
- `rcr-acc08.test.ts` @ 89d01dc^ gives the RC-F05 case failing: `[79000]` instead of `[79000, 80000]`.
- `rcr-delete-all.test.ts` @ 417acbd^ fails with `['widget_link_codes']` missing.

At HEAD the same 3 files pass (9/9).

| Row | Red shows failure before? | Green shows pass after? | Fix commit touches the claimed code? | Reproduction test asserts the stated expectation? |
|---|---|---|---|---|
| RCL-ST01 (P0) | yes (`rcr-red/e2e-rcr-storage-RED-6218a33.log`: local record lost, cloud record merged) | yes 3/3 | yes (8418819: `loadCloud` checks the mode again after the await) | yes. M36 is killed by ST-01 |
| RCL-UX02 (P0) | yes (`rcr-ux/iq06-fixes-RED.log` UX-02) | yes | yes (4e242a0: `SignedOutNotice.tsx`, AddSheet, MoneyForm, StoreProvider) | mostly. It checks that the exit is shown before input and that the input survives the switch. It confirms the save only through the toast, not the stored record. M43 is killed |
| RCL-OCR02 (P0) | log truncated: it shows only the date-check failure ("2 failed"). **Reproduced by me**: the receipt case fails | yes 3/3 | yes (d7c1667: `ingest/screenshot.ts`) | yes (no registrable draft, no 23/271 amount). M49 and M50 are killed |
| OC04 | n/a: still FAIL/OPEN | n/a | yes (a1fbd7a, d7c1667, c2c4268: OCR code) | correctly not PASS (IQ05) |
| RCL-F08 (ACC08) | yes (2 rows instead of 1, 00:56:55, before the c9a25ab commit) | yes 4/4 | yes (c9a25ab: `accounts.ts`, AccountsView) | yes (1 movement, paid). c9a25ab introduced the RC-F05 regression |
| RCL-F10 (RC-F05) | log truncated and **timestamped 01:21:50, after the green (01:21:40)**. **Reproduced by me** at 89d01dc^ | yes 5/5 | yes (89d01dc: `accounts.ts`) | yes (both rows plus overpaid state). The ledger root cause does not say the bug came from this phase's own c9a25ab (D8) |
| RCL-SEC05 (SE06) | yes. **Reproduced by me** | yes | yes (417acbd: `repo.ts` deleteAllData) | **weaker than stated**: a static regex scan of `repo.ts` against the migrations. Nothing exercises "after deletion, no new device key can be made" (D11) |
| RCL-T01 | no red/green file. The start `vitest.log` shows night-brand 1 failed | (final vitest) | yes (8418819: night-brand test) | n/a. No independent approval recorded |
| RCL-T02 | yes (vacuous PASS lines with 0-byte dumps) | the after-log FAILs on read failures, as intended | yes (8418819: `db-rehearsal.sh`) | yes |
| RCL-T03 | run1 RESULTS.json (survivors) | run2 RESULTS.json, and the final run kills M19, M26, M28–M30, M32 | yes (c9a25ab adds `rcr-iq01-*`) | tests written to kill specific mutants (low risk of overfitting) |
| RCL-T04 | the "red" is a planted-leak detection (exit 1) by the new scanner, with no before-fix log | `bundle-secrets.log` | yes (417acbd: `check-bundle-secrets.mjs`) | yes |
| RCL-T05 | **no red** | `e2e-normal.log` | yes (417acbd: `e2e.mjs`) | M32 is killed |
| RCL-T06 | **no red file** | green is a review doc | yes (9cff59a: 8 test files) | the independent QA reports 30/30 |
| RCL-T07 | yes (`e2e-normal-RED-147e18b.log`, 10 FAIL) | yes 63/63 | 1de9a08 changes **only product components**: it restores the test's `.mode-chip` hook on a hidden status and rewords fixed "0円" text. A test defect closed by changing the product. No independent approval recorded (D10) | — |
| RCL-T08 | **invalid**: `rcr-rcu09/red.log` holds 3 runs, and all 3 are fixture **build failures** (`UNRESOLVED_IMPORT …/scripts/src/lib/core/review-seed.ts`), not the claimed `waitForSelector` failure. The real red is the single run in `final-4ed6ae9/e2e-qr-ui.log` | yes 5/5 | yes (17c6d26: `e2e-qr-ui.mjs`, `lib/qr-ui.mjs`) | supported by mutation: M57 and M58 are killed by test 17. M58 is killed by the content check "読み込み中に空・0円を出した" (D4) |
| RCL-T09 | yes (`final-4ed6ae9/preview-verify-local.log`: "NG コミット：4ed6ae9 が見つからない") | **0-byte** `head-unchanged.log` | yes (17c6d26: `qa-all.sh`) | the step passes if *either* build contains the SHA. I confirmed both builds by hand |

**Scan of all 40 FIXED rows** (00_STATUS claims every one has red, green, independent and final-regression evidence):

- **Red evidence is empty** (or plain text with no file) for RCL-ST04, ST05, F05, F06, F07, T01, T05 and T06.
- **Independent evidence is empty** for ST04, ST05, T01, T02 and T04.
- RCL-OCR01 cites the same JSON as both red and green.
- **The cited green for RCL-F01 to F04 is a failing run.** `rcr-iq02/D1-D4-GREEN-after-fix.log` shows "1 failed | 7 passed": the random D1/D2 `unknown:afterStatement` check mismatches on seeds 2 and 14. The final vitest has the test passing.

## 5. Data hashes (check 4)

- `quality/BASELINE.sha256` is the single digest `a37a57d5…f7d2e`. `sha256sum quality/BASELINE_283.csv` gives the same value, so it **matches**.
- `quality/BASELINE_283.csv` is byte-identical to the handoff's `reference/BASELINE_283.csv`.
- In `quality/RESULTS_283.csv` versus the baseline:
  - 283 IDs, same set, same order.
  - The fixed columns (id, source, priority, condition, expected, baseline, baseline_evidence, baseline_actual, baseline_notes, plus group, action, external_dependency) show **0 differences**.
- **Regressions: 0.** No baseline PASS row is anything but PASS now.
- **No status changed** between the start (6218a33) and the final RESULTS: 237 PASS both times.
- All 237 PASS rows carry commit `17c6d26`, and each has at least one proof under `final-17c6d26/`.

## 6. Gates (check 5)

I reran `python3 quality/quality_gate.py --results quality/RESULTS_283.csv --evidence-root . --stage <s> --head 17c6d26` for each stage. The output is **identical** (deep-equal JSON) to the stored `final-17c6d26/gate-*.json`.

| Stage | Exit | Errors | Notes |
|---|---|---|---|
| progress | 0 | 0 | PASS 237, in-scope rate 89.43% |
| local | 1 | 2 | OC04 FAIL, RC-U01 PARTIAL |
| release | 1 | 28 | 26 external rows plus the 2 above |

The gate checks only that proof files exist and are non-empty. It does not check what they say (see D3 and D1).

## 7. Mutation (IQ01) (check 6)

`RESULTS.json` was created at 07:40Z. `worktreeHead` is 9a70994 (same source) and `worktreeClean` is true. All 10 baseline layers exit 0. Totals: 58, with 56 killed, survived M07 and M39, and no invalid mutants.

**M39** removes the control-character and backslash rejection in `safeNext`, but the WHATWG URL parse, the origin check and the `/gate` and `/api/` filters stay. Tabs and newlines are stripped and `\` becomes `/` before the origin check, so `/\t/evil` turns into `//evil` and fails the origin check. The function returns the normalised `pathname+search+hash`. **The equivalence for the security property (same-site only) is sound.** Only odd same-site paths behave differently.

**M07** removes the `doneOps`/outbox duplicate check in cloud `persist`.

- `useSave` keeps an operation ID only until success, and cloud `persist` fails only before it enqueues. So no normal UI path re-commits the same operation ID after it was enqueued.
- Server rows are keyed by IDs derived from the operation ID, and replay is local-only.
- So the argument that **the data is the same** is plausible.
- But M07 is **not an equivalent mutant**: the "未送信 N 件" count can differ. The implementer correctly records it as a test gap, not as an equivalence exclusion.
- Data-level idempotency is covered elsewhere: M03, M37/ST-02, ACC08 and the DB tests.

**Flaky-kill check.**

- The tool counts *any* non-zero exit as killed (timeouts, server failures). There is one baseline run and no flakiness measurement.
- I read the failing log of every e2e-layer kill: M04, M05, M06, M36, M37, M43, M44, M48, M57 and M58.
- Each failure is in the test aimed at the mutated behaviour. For example:
  - M04: "画面は ok なのに保存は false"
  - M06: "保存できなかったのに文が消えた"
  - M36: the local record is lost and the cloud record is merged
  - M37: "支出 2件"
  - M43, M44 and M48: UX-02, UX-05 and UX-04
- M57 also tripped an unrelated qr-ui test 7 (long event names in the month calendar), which passes in the baseline and in M58. That is collateral, and the targeted test 17 failed as well.
- The unit-layer kills all come from related test files. For example, M41 is killed by `rcr-acc08` and the oracle, M42 by `rcr-delete-all` and `rcr-validity-se06`, and M47 by `rcr-iq05-amount-reread`.
- The DB kills (M16–M18) are real assertion errors ("他人の取引が見える", "service_role で他人の行を上書きできた", "ほかの人として保存できた").

**M57 and M58** are both killed **by the RC-U09 test specifically** (qr-ui test 17).

- M57 removes the loading marker, so `waitForSelector [data-testid="store-loading"]` times out.
- M58 keeps the marker and renders the empty data underneath. It fails on the content check: "/: 読み込み中に空・0円を出した … 今日の使用分 ¥0". That is the assertion the T08 test fix was meant to protect.
- So the fixed test does detect a broken app, which offsets the invalid red in D4.

## 8. Discrepancies (claim versus evidence), ranked by severity

**High**

- **D1. Four PASS rows rated WEAK by the independent test-validity audit were never strengthened or acknowledged.** They are still PASS, with the same evidence "re-run at 17c6d26". This goes against the handoff's "既存の合格証拠も最終HEADで有効性を確認". The other 19 audited WEAK or INVALID rows were addressed. Source: `docs/rootcause_20261120/reviews/test-validity-audit.md` versus `quality/RESULTS_283.csv`.
  - **RC-S03 (P0, "保存タイマー発火直前のログアウト → 旧データを新uidへ書かない").** The audit found that the e2e unmounts the editor before A logs in, so the timer can never fire under A's uid. The test therefore cannot detect the defect.
  - **RC-S05 (P1).** Only `writeDraft()` returning false is asserted. The NoteEditor's handling is untested.
  - **OC14 (privacy).** Nothing asserts that no image or text leaves the device, and nothing tests the URL or worker release.
  - **OC08.** The cited "dangerous errors 0" comes from a suite that is skipped in vitest.
- **D2. The IQ03 test environment is misstated.** `00_STATUS.md` (IQ03 row) and `IQ03_IQ04_IQ06_IQ07.md` say the faults ran on "本物の PostgreSQL の上のサーバーの処理". In fact:
  - `scripts/lib/real-api.mjs` uses `MemoryRepo` plus `setTestUsers` (the test path that RCL-T03 itself calls a test defect), called through Playwright `ctx.route` interception.
  - The header of `scripts/e2e-rcr-faults.mjs` itself says "handlers.ts・MemoryRepo".
  - "DB abort" is an injected HTTP 500.
  - The handoff forbids "モックのみで実環境合格". The local fault behaviour is still verified, which is why I give IQ03 BLOCKED, not FAIL.
- **D3. PV19 is PASS with commit 17c6d26, but its own expected value is "別URLの最新版を確認、未配備ならBLOCKED/NOT RUN".**
  - The only real preview is `86456b4` (`quality/evidence/night-preview-final/deploy-in-project.log`: `kurashiCommit":"86456b4"`).
  - 00_STATUS itself says this phase did not deploy.
  - The assertion "最終のコミットで出し直した" was carried over from the night phase.
  - The cited "final-HEAD rerun" is the local `preview-verify-local.log`.
  - PV04 and RC4-11 also rest on the 86456b4 deployment, and RC4-11's "rerun" is `vitest.log`, which is irrelevant to it.
  - So the 237 PASS count is overstated by at least 1 (PV19).

**Medium**

- **D4. RCL-T08's red evidence is invalid.** All 3 runs in `quality/evidence/rcr-rcu09/red.log` are fixture build errors (`UNRESOLVED_IMPORT …/scripts/src/lib/core/review-seed.ts`). `NOTE.md` nevertheless says "3回とも落ちる". The genuine red is one run in `final-4ed6ae9/e2e-qr-ui.log`. Mitigated by M57 and M58 (§7).
- **D5. The green evidence for RCL-F01 to F04 fails.** `quality/evidence/rcr-iq02/D1-D4-GREEN-after-fix.log` reports "Tests 1 failed | 7 passed": seeds 2 and 14 mismatch on `unknown:afterStatement`. The final state passes 162/162, so the fix was finished later (c9a25ab). But the ledger cites a red log as green.
- **D6. 00_STATUS claims every one of the 40 fixed rows has red, green, independent and final-regression evidence. The ledger does not support that.**
  - Red is empty or text-only for RCL-ST04, ST05, F05, F06, F07, T01, T05 and T06.
  - Independent is empty for ST04, ST05, T01, T02 and T04.
  - RCL-OCR01 uses one file for both red and green.
  - The handoff's "テスト自体の欠陥修正は…独立承認を記録" is not met for T01, T02, T04, T05 and T07.
  - Source: `quality/rootcause/ROOT_CAUSE_LEDGER.csv`.
- **D7. RCL-T09's green and the `head-unchanged` step are weak.** `final-17c6d26/head-unchanged.log` is 0 bytes. The check `grep -rqs <sha> .next/static .next-review/static` passes if *either* build contains the SHA. I confirmed both builds contain 17c6d26, so the claim holds, but the step alone would not show it.
- **D8. RC-F05's red was produced after its green.** `RCF05-RED-before-fix.log` starts at 01:21:50 and `RCF05-GREEN-after-fix.log` at 01:21:40. The red log is also truncated: it has no RUN header. I reproduced the red independently, so the claim is true, but the revert-to-make-red is not documented. RCL-F10's root cause also does not say the defect was introduced by this phase's c9a25ab. Only the RESULTS RC-F05 assertion discloses it.
- **D9. The DB rehearsal reports "すべて PASS（FAIL 0）" while §F shows an existing test failing.** Under the Supabase auto-expose default privileges, `qr_se02_two_owners_test` fails because anon can EXECUTE `kurashi_export_snapshot`. The function rejects anon internally, so no data leaks. §G also shows 4 old-version tests failing, which is an expected difference in spec. The §F result is in `docs/night_20261120/REMAINING.md` but not in the QG13 notes or `docs/rootcause_20261120/REMAINING.md`. Source: `final-17c6d26/db-rehearsal.log`.
- **D10. RCL-T07 is classed as a test defect but was fixed in product code.** 1de9a08 changes only `src/components/*`: it restores the `.mode-chip` hook for the test on a hidden status element and rewords the fixed "0円" text so the strengthened regex no longer matches. Rewording is defensible, but it is the product being adapted to the test, with no independent approval recorded.

**Low**

- **D11. SE06's reproduction test only scans source text.** `rcr-delete-all.test.ts` matches a regex over `repo.ts` against the migrations. The ledger's expectation (no new device key within 5 min after deletion) is never exercised.
- **D12. UX-02 confirms a save only through the success toast.** The IndexedDB lookup in the test collects store names and asserts nothing (`scripts/e2e-rcr-ux.mjs`).
- **D13. Some IQ04 checks are not independent.** The card check compares two implementation functions, and the forecast check is a smoke test (`iq04-long-term.test.ts`).
- **D14. The mutation tool does not check why a test failed.** It counts any non-zero exit as killed and runs the baseline once. My sample found no flaky kills.
- **D15. Mutation and ops03 ran on 9a70994, not 17c6d26.** The source is identical, and this is now stated in `IQ01_MUTATION.md`.
- **D16. Cosmetic issues.**
  - The vitest JSON marks 4 skipped files as "passed".
  - The SW logs print a blank "/sw.js を返した版：".
  - RCL-OCR02's red log is truncated, though the red is real: I reproduced it.

## 9. What I ran and what I did not

- **Ran**:
  - the three gate stages
  - a scratch rebuild of the ledger (no writes to the repo)
  - `sha256sum`, a column-by-column RESULTS/BASELINE comparison, and a start/final RESULTS comparison
  - 3 single unit test files against pre-fix sources taken with `git archive` into my scratch dir, and the same 3 files at HEAD
- **Read**: every final step log, `vitest-results.json`, every e2e-layer mutant log, and the diffs of fix commits.
- **Did not run**: E2E tests, builds, servers, the full vitest suite, anything on a real device or a real Supabase, or any deployment.
- **Not verified by me**: the IQ05 OCR numbers (I took them from the independent evaluator's report and did not re-measure), and the iq06 pre-check recordings.
