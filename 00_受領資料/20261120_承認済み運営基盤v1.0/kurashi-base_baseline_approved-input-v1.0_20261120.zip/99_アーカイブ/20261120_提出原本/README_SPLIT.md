# 分割した返却 ZIP（根本原因の工程・2026-11-20）

7つの ZIP は、どれも単独で開けます。全部を**同じ場所**に展開すると、1つのフォルダ `KURASHI_ROOT_CAUSE_RESULT_20261120/` に戻り、
`run_gate.sh`（ZIP の中身だけで3段のゲートを回し直す）が動きます（1・2・3・4・5・6 が要る。7 の画面の写真は要らない）。

| ZIP | 中身 | まず読むもの |
|---|---|---|
| part1_docs | 状況（00_STATUS.md）・残課題・本人の手順・説明書・独立の担当の報告（reviews）・手順書（実機・前の版へ戻す・DB）・台帳・ゲートの出力・開始からの差分・変異の定義・run_gate.sh | **00_STATUS.md** |
| part2_source | 最終のソース（コード・試験・SQL・スクリプト・受入表）。証拠のフォルダを除く | |
| part3_final_regression | 最終の全回帰（17c6d26）の全部の段のログ・vitest の結果・ゲート・速さ・前の版へ戻す試験・DB のリハーサル | `00-summary.txt` |
| part4_mutation | 変異試験（IQ01）の結果（RESULTS.json・変異ごとの diff とログ） | `iq01/final-17c6d26/RESULTS.json` |
| part5_regression_failed_runs | 途中の全回帰（4ed6ae9：失敗の記録を含む） | `00-summary.txt` |
| part6_evidence | 直す前に失敗する記録・直したあとの記録・開始の地点の全回帰・IQ03/IQ04/IQ06 の下見・IQ05 の凍結の評価（画像なし）ほか | `tests/README.md`（part1） |
| part7_screens | 画面の写真（最終の全画面・UX の直す前と後） | |
