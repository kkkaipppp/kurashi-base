# UX v3 実装計画と、実際の構成

入力：`KURASHI_CLAUDE_UX_V3_UPDATE_20261114.zip`（00〜05 の文書とモック画像）
作業ブランチ：`claude/loving-curie-madwt7`（PR #8、未マージ）。**本番へのデプロイはしない。**

## Phase A：着手前の状態（2026-11-14 に確認）

### Git とテスト
- 作業ツリーはクリーン。直前のコミットは `b2b38d9`。
- 前回レビューの同期 P0 は、このブランチで対応済み（`docs/review-20261114/FIX_SUMMARY.md`）。
  - 複数タブの未送信キュー：F01
  - 競合の退避：F05
  - DB の同時更新・原子性：F02 / F03 / F08
- 再現テストはすべて成功している。
- 上の理由で、UI の変更は同じブランチ（PR #8）に積む。DB・同期の仕組みには手を入れない。
  - 年次レポートの取得 API は読み取りだけで、RLS が効くクライアントで実装する。
- **本番の Supabase には、まだ v2 の SQL を流していない。** PR #8 はマージ前に SQL を流す必要がある（`docs/review-20261114/MIGRATION_RUNBOOK.md`）。

### 機能の状態（v3 着手前）

| 機能 | 状態 | v3 での扱い |
|---|---|---|
| 予定の追加・編集・削除、繰り返し、複数日の帯、祝日、月/週/日、検索 | 実装済み | 保持。月のマスは整理し、詳細は選択日のリストへ |
| 支出・収入の入力（MoneyForm）、電卓、カテゴリのよく使う順、予定との紐づけ | 実装済み | 保持 |
| 「よく使う入力」（frequentEntries / quickSave） | 実装済み | 保持。開閉式にする |
| 自然文の「クイック入力」（`quick-input.ts`・＋シートの「クイック入力」タブ） | 実装済み | **機能ごと削除** |
| 下のメニュー（カレンダー/家計/＋/やること/設定） | 実装済み | **ホーム/カレンダー/家計/固定費/振り返り** に変更。＋は各画面の追加ボタンへ |
| 固定費 → カレンダー（`expandFixed`・`buildCalendar` の派生表示） | 基本は実装済み | 再利用し、プレビュー・案内・カレンダーへの導線を補強 |
| ふり返り（月次・6か月グラフ・年の配当など） | 部分的 | 月次／年次の切り替え。年次の12か月グラフ・合計・カテゴリ・比較を追加 |
| 予算・カテゴリ予算・NISA・有給・やること・通知・バックアップ・Face ID・取込・ウィジェット | 実装済み | 保持。導線は「その他」メニューに集める |
| 配色（紫系・グラデーション） | 実装済み | Calm & Clear のトークンへ。ライト／ダーク／自動を選べるように |

## モックとルートの対応

| 下のタブ | ルート | 画面 | 旧ルートとの関係 |
|---|---|---|---|
| ホーム | `/` | HomeView | 同じ |
| カレンダー | `/calendar` | CalendarView | 同じ（`/calendar/new`・`/calendar/[id]` も同じ） |
| 家計 | `/money` | MoneyView | 同じ（`/money/new`・`/money/[id]` も同じ） |
| 固定費 | `/money/fixed` | FixedList | 同じ（`/money/fixed/new`・`/money/fixed/[id]` も同じ） |
| 振り返り | `/money/report` | ReportView | 同じ。`?view=month&month=YYYY-MM` と `?view=year&year=YYYY` を足した |

「その他」メニュー（上の見出しの右、全画面）から開けるもの：
- やること・買い物（`/todo`）
- 検索（`/search`）
- 取込・確認待ち（`/import`）
- NISA（`/?detail=nisa`）、有給（`/?detail=leave`）
- 設定（`/settings`）。表示（テーマ）・通知・Face ID・バックアップはここから
- ウィジェット（`/setup/widget`）、ショートカット（`/setup/shortcuts`）、バックアップ（`/setup/backup`）

## 部品の構成

| 部品 | 役割 |
|---|---|
| `src/components/Section.tsx` | 開閉できるセクション。`aria-expanded`・`aria-controls` を持つ。閉じても見出しと件数・金額は見える。開閉の状態は端末の中に表示設定としてだけ保存する（`kurashi.fold.<id>`） |
| `src/components/AddSheet.tsx` | 旧 `QuickAdd.tsx`。支出・収入／予定の2タブだけにした |
| `src/components/MoreMenu.tsx` | 「その他」メニュー |
| `src/components/YearChart.tsx` | 年次グラフ（SVG）。12か月の支出（棒）と収入（線）、タップで選ぶボタン、代替の表 |
| `src/lib/core/annual.ts` | 年次集計の純関数 `yearReport()`・`periodTotals()`・`samePeriodComparison()`・`yearsOverview()`・`cloudCoverageFrom()` |
| `src/lib/ui/fold.ts` | 開閉の状態の読み書き（`kurashi.fold.<id>`、表示の設定だけ） |
| `src/components/ThemeSetting.tsx` | 設定 → 表示（自動／ライト／ダーク） |
| `src/lib/ui/theme.ts` + `layout.tsx` のインラインスクリプト | テーマ（自動／ライト／ダーク）。描画の前に `<html data-theme>` を決める |
| `GET /api/report/year?year=YYYY` | 端末に読み込んでいない古い年を、サーバーで1年分だけ集計して返す（RLS が効く本人のクライアント・読み取りだけ） |

## テスト計画
- 単体：`annual.test.ts` に Y02〜Y08・Y11・Y12 を入れる（年間合計＝12か月の合計＝カテゴリの合計、返金、投資、固定費の二重計上なし、予定の予算、0件、閏年、12/31、未到達の月、未取得の月）。
- API：年次の取得（本人だけ・範囲外の年を断る）。
- E2E
  - Q01〜Q06：クイック入力がない／通常の入力・電卓・よく使う入力／ショートカットの画面がある
  - 5タブと「その他」の導線：U06
  - 開閉：U01・U02
  - 月次⇄年次：Y01
  - 固定費の登録 → カレンダー → 支払済み → 二重計上なし：F01・F05
- スクリーンショット：390・320・430px、デスクトップ、ライト／ダーク、文字200%。
- 既存のテストをすべてもう一度流す。

## 実装の結果（計画から変えた・決めたこと）

### 年次集計の決まり（`src/lib/core/annual.ts`）
- **各月の `monthSummary()` を足し上げる。** 家計の画面（月）と年次の数字が必ず一致する。カテゴリの合計＝年間支出も、同じ足し上げなので一致する（単体テスト Y02）。
- 支出：確定した支出 − 返金（返金は元の支出の日・月に寄せる。年をまたいでも元の年）。投資（NISA など）と投資の返金は入れず、「投資」として別に数える。
- 固定費：支払済みの回だけ。取引と紐づいた回は取引の金額で1回、取引なしで支払済みにした古い回は予定額で1回。未払いの予定は入れない。
- 予定の予算は入れない。確認待ち・無視・資金移動も入れない。
- 収入：確定した収入（給料・賞与・配当・ポイント・配給など、種類を問わず `kind = income`）。
- 収支差額＝収入−支出。収支余剰率＝収支差額÷収入（収入が0以下なら出さない）。「貯蓄率」とは書かない。
- 月の状態
  - `done`：過ぎた月。
  - `current`：今月（途中）。
  - `future`：まだ来ていない月。値は null で、0円ではない。
  - `unloaded`：読み込んでいない月。値は null。
- 年の状態
  - `complete`：1〜12月がそろっている。
  - `to_date`：今年（年初から今日まで）。
  - `partial`：読み込んでいない月がある。
  - `unloaded`：1か月も読み込んでいない。
  - `future`：まだ来ていない年。
  - 「年間」という言葉は `complete` のときだけ使う。
- 前年との比較
  - 今年：1/1〜今日と、前年の 1/1〜同じ月日（2/29 は 2/28）。
  - 過去の年：通年。
  - 前年を読み込んでいなければ比べない。0円とはみなさない。

### 古い年の扱い
- クラウドで端末に読み込むのは「おととしの1月1日から」（`/api/dataset`。前回の修正 F12）。それより前の年は `unloaded` と表示する。
- 「この年だけクラウドで集計する」で `GET /api/report/year` を呼ぶ。
  - サーバーはその1年の取引と、翌年以降の返金のうち元の取引がその年にあるものだけを読む（`LoadOptions.laterRefunds`）。
  - 同じ `yearReport()` で集計し、集計だけを返す。明細は返さない。
- 全部の年を一度に読むことはしない。端末にも保存しない（画面を閉じれば消える）。

### 画面で決めたこと
- **カレンダーの月のマス**：帯にするのは終日・複数日の予定だけ（`weekBars()` はそのまま使う）。時刻のある1日の予定は点にした。予定の名前・時刻・金額は、選んだ日の一覧で見る。
- **年次グラフ**
  - 縦軸は1本（円）。棒＝支出、線＋点＝収入。
  - 目盛りの文字や月の数字は SVG ではなく HTML に置いた（拡大してもつぶれない）。
  - 月はボタン（読み上げのラベル付き）で選ぶ。
  - 色は配色チェックで合格したものを、ライト・ダークで別に決めた（`--chart-spend`・`--chart-income`）。
- **300px 以下**（320px の端末を拡大したときなど）の規則
  - ロゴの文字を隠し、追加ボタンは縦に並べる。
  - 開閉の見出しは2行にする。
  - 一覧の行は、金額を次の行に送る。
- **固定費の保存の知らせ**：端末に保存できたときだけ出す。
  - クラウドでオンライン：「クラウドへ送信中」。
  - オフライン：「端末に保存しました（未送信）」。
  - 送れたかどうかは、見出しの同期の表示（同期済み・未送信）で分かる。
- **固定費の月あたりの合計**から、投資の積立を除いた（ホームの「今月の固定費」と同じ考え方）。

### 変えていないもの
- `StoreProvider`・ChangeSet・未送信の控え（outbox）・競合の退避・`kurashi_apply_changes`・RLS・認証・service_role・Cron・端末キー・合言葉・Face ID ロック。
- DB の表・列・関数（migration の追加なし）。

### 変えたファイル
`docs/ux-v3/FEATURE_DIFF.md` を参照。主なもの：
- 共通：`AppShell.tsx`、`MoreMenu.tsx`、`AddSheet.tsx`（旧 `QuickAdd.tsx`）、`Section.tsx`、`globals.css`
- 5画面：`views/HomeView.tsx`、`CalendarView.tsx`、`MoneyView.tsx`、`FixedViews.tsx`、`ReportView.tsx`
- グラフ：`YearChart.tsx`
- 集計と API：`lib/core/annual.ts`、`lib/server/handlers.ts`（`handleYearReport`）、`lib/server/repo.ts`（`laterRefunds`）、`app/api/report/year/route.ts`、`lib/store/cloud.ts`（`fetchYearReport`）
- テスト：`scripts/e2e.mjs`、`scripts/ux-v3-screenshots.mjs`
