# くらしカレンダー 実装計画

作成日: 2026-11-14 ／ 元の仕様: `docs/spec/`（MVP_REQUIREMENTS / WIDGET_REQUIREMENTS / IOS27_SHORTCUT_SETUP / CLAUDE_CODE_PROMPT / START_HERE）

自分専用の「予定＋家計簿」PWA。予定が主役で、お金は同じカレンダーに自然に並ぶ。
App Store 公開・課金・銀行API・有料AI APIは使わない。

---

## 0. リポジトリの現状と置き場所

- このリポジトリ（kabu-hantei）は、ルートに株アプリ、`yudai-chat/` `tanaka-chat/` に独立アプリを置く構成。
- くらしカレンダーも **`kurashi-calendar/` に独立して置く**（フォルダごと別リポジトリへ移しても動く）。
- 既存アプリと同じく Next.js 16.4.6 / React 19.3 / TypeScript strict / Vitest。
- 既存アプリと違い、ショートカットとウィジェットの受け口（Route Handler）が要るので静的書き出しはしない。

## 1. 動作モード（デモと実データを混ぜない）

| モード | データの置き場所 | 用途 |
|---|---|---|
| `demo` | ブラウザ localStorage `kurashi.demo.v1` | 初回起動時。架空データ。画面上部に常に「デモデータ」帯を出す |
| `local` | ブラウザ localStorage `kurashi.local.v1` | Supabase 未設定でも自分のデータで使う。端末1台だけ |
| `cloud` | Supabase（Postgres + RLS） | 本番。ショートカット取込・ウィジェットはこのモードだけ |

- 3つは別の入れ物で、**表示時に混ぜない**。切り替えは設定画面から明示的に行う。
- デモデータは「今日」を基準に毎回作るので、いつ開いても今日・今月の例が見える。
- 計算（カレンダー統合・集計・取込判定）は全部 `src/lib/core/` の純関数で、3モードとサーバー（ウィジェットAPI）が同じ関数を使う。

## 2. 画面遷移

```mermaid
flowchart TD
  Home["/ 今日（ホーム）"]
  Cal["/calendar 月・週・日"]
  EvNew["/calendar/new 予定の追加"]
  EvEdit["/calendar/[id] 予定の編集"]
  Money["/money 家計（収支・内訳・予算）"]
  TxNew["/money/new 支出・収入の記録"]
  TxEdit["/money/[id] 取引の編集"]
  Fixed["/money/fixed 固定費・サブスク"]
  FixedEdit["/money/fixed/new ・ /money/fixed/[id]"]
  Import["/import 取込（確認待ち・履歴・スクショ・貼り付け）"]
  Review["/import/review/[id] 確認"]
  Settings["/settings 設定"]
  Short["/setup/shortcuts ショートカット設定"]
  Widget["/setup/widget ウィジェット設定"]
  Login["/login ログイン"]
  FAB(("＋ すぐ追加"))

  Home --> Cal & Money & Import
  Cal -->|日付をタップ| Cal
  Cal --> EvNew & EvEdit & TxEdit
  Money --> TxNew & TxEdit & Fixed
  Fixed --> FixedEdit
  Import --> Review
  Settings --> Short & Widget & Login
  FAB -->|クイック入力| EvNew & TxNew & FixedEdit
```

- 下のタブ: **カレンダー｜家計｜（＋）｜取込｜設定**。左上のアプリ名で「今日」（`/`）へ戻る。
- 「＋」はどの画面からでも開くシート。1行入力（「明日19時 飲み会 5000円」）の解析結果を見て1タップで保存。
- ウィジェットから: 中サイズ → `/calendar?view=day&date=今日`、小（予定）→ `/calendar`、小（支出）→ `/money`。

### 見た目のきまり
- 紫を基調にした、余白の多いシンプルな画面。白いカード、角丸、細い線。ダークモード対応。
- 色の意味: **予定=青、支出=橙、固定費=紫、収入=緑**。色だけに頼らず、必ず「予定」「支払」「固定費」「収入」のラベルとアイコンを付ける。
- 予定の予算は「予定 ¥5,000」、実績は「支払 ¥4,800」と書き分ける（合算に見せない）。
- 取込の状態は「自動登録済み」「確認待ち」「重複候補」「無視した」の4つで表示。

## 3. DB設計（Supabase / PostgreSQL）

マイグレーション: `supabase/migrations/20261114000000_init.sql`。全テーブル `user_id` 単位の RLS。

| テーブル | 主なカラム | メモ |
|---|---|---|
| `profiles` | `user_id PK`, `timezone`(既定 Asia/Tokyo), `monthly_budget_yen`, `budget_mode`(`includes_fixed`/`variable_only`), `include_planned_budgets`, `auto_confirm_sources text[]` | 予算の方式を明示して固定費の二重控除を防ぐ |
| `ingest_devices` | `id`, `user_id`, `name`, `scope`(`ingest`/`widget`), `secret_hash`, `token_hint`, `last_used_at`, `revoked_at` | 平文は保存しない（SHA-256）。発行時に1回だけ表示 |
| `capture_events` | `id`, `user_id`, `device_id`, `client_event_id`, `source_type`, `source_app`, `captured_at`, `redacted_excerpt`, `excerpt_expires_at`, `parser_version`, `status`, `result_json` | `unique(user_id, device_id, client_event_id)` で冪等。抜粋はマスク済みで30日で消す |
| `transactions` | `id`, `kind`(expense/income/transfer/refund), `amount_yen`(正の整数), `occurred_on date`, `occurred_at timestamptz null`, `merchant`, `category_id`, `payment_method`, `status`(confirmed/provisional/needs_review/ignored), `confidence`, `dedupe_signature`, `reference_id`, `duplicate_of_id`, `related_transaction_id`, `related_fixed_occurrence_id`, `related_schedule_event_id`, `related_schedule_occurrence_date`, `source` | 時刻なしの取引は `occurred_at` を null にする |
| `categories` | `id`, `user_id null`(null=標準), `name`, `kind`, `icon`, `color` | 標準カテゴリはマイグレーションで投入 |
| `merchant_rules` | `id`, `user_id`, `match_pattern`, `category_id` | 店名→カテゴリの学習（ルールベース） |
| `recurring_rules` | `id`, `title`, `kind`, `category_id`, `expected_amount_yen`, `frequency`(weekly/monthly/yearly), `interval_count`, `day_of_month`, `day_of_week`, `month_of_year`, `last_day_policy`(clamp/skip), `start_date`, `end_date`, `is_active`, `match_keyword`, `payment_method`, `is_subscription` | 固定費・サブスク |
| `recurring_occurrences` | `id`, `recurring_rule_id`, `scheduled_on`, `expected_amount_yen`, `status`(expected/paid/skipped), `transaction_id` | `unique(recurring_rule_id, scheduled_on)` |
| `schedule_events` | `id`, `title`, `start_at`, `end_at`, `all_day`, `local_start_date`, `local_end_date`, `location_text`, `note`, `budget_yen`, `recurrence_rule`, `series_id`, `original_occurrence_date`, `is_cancelled` | 繰り返しの例外は `series_id`+`original_occurrence_date` の行で表す |
| `ingest_parsing_candidates` | `id`, `capture_event_id`, `candidate_json`(検証済みキーのみ), `confidence`, `decision`, `matched_transaction_id` | 通知全文・口座番号は入れない |

### 固定費の予定の作り方
- 予定日は **ルールから毎回計算**する（月をまたいで登録し直さなくてよい）。
- 状態が変わった回（支払済み・スキップ・金額変更）だけ `recurring_occurrences` に行を作る。
- 31日指定は「その月に31日がなければ月末に繰り上げ」（`clamp`）が既定。「その月は飛ばす」（`skip`）も選べる。画面に適用ルールを書く。

### 繰り返し予定
- `recurrence_rule` は RRULE の一部（`FREQ=DAILY|WEEKLY|MONTHLY|YEARLY;INTERVAL=n;BYDAY=..;UNTIL=YYYYMMDD;COUNT=n`）。
- 「この回だけ変更／削除」は例外行（`series_id` と `original_occurrence_date`、削除は `is_cancelled=true`）。「すべて」はマスター行を直す。
- 毎月29〜31日の予定も固定費と同じく、ない月は月末に表示する（画面に注記）。

## 4. API（自作。決済会社・銀行APIは使わない）

| メソッド・パス | 認証 | 内容 |
|---|---|---|
| `POST /api/ingest` | `X-Ingest-Token`（取込専用） | 通知/スクショOCR文字列の受信。検証→冪等→マスク→解析→重複判定→保存 |
| `POST /api/ingest/test` | `X-Ingest-Token` | 接続確認だけ。何も記録しない |
| `GET /api/widget/summary` | `Authorization: Bearer`（ウィジェット読み取り専用） | ウィジェット用の最小要約 |
| `GET /api/dataset` | Supabase ログイン | PWA が使う本人の全データ（取引は直近24か月） |
| `POST /api/mutate` | Supabase ログイン | PWA の変更をまとめて反映（upsert/delete、テーブルごとにZod検証、RLS） |
| `GET /api/calendar?from=&to=` | Supabase ログイン | 予定・取引・固定費を型付きで統合 |
| `GET /api/summary?month=YYYY-MM` | Supabase ログイン | 実績・未決済固定費・予定予算・残り予算と内訳 |
| `GET /api/transactions?month=` | Supabase ログイン | 取引一覧 |
| `GET/POST /api/ingest-devices`, `DELETE /api/ingest-devices/[id]` | Supabase ログイン | 端末キーの発行・一覧・失効 |
| `GET /api/export?format=json|csv` | Supabase ログイン | 書き出し |
| `DELETE /api/account` | Supabase ログイン | 自分のデータを全部消す |

- 仕様書の「予定・取引・固定費ごとの CRUD API」は、**`/api/mutate` の1本にまとめた**。理由: 承認＋固定費の支払済み化＋店名ルール学習のような複数テーブルの変更を、1回の送信で同じ検証にかけたいから。読み取り用の `calendar` / `summary` / `transactions` は仕様どおり用意する。
- 取込キーは **書き込み専用**（受信だけ）。ウィジェットキーは **要約の読み取りだけ**。どちらも取引一覧や削除には使えない。
- `user_id` はリクエストから受け取らない。キーまたはログインから決める。
- 返すステータス: `accepted`（`auto_registered`/`needs_review`/`duplicate_candidate`/`ignored_not_payment`）・`duplicate_request`（同じ `client_event_id` の再送）・400（JSON・項目エラー）・401（キーなし・不一致）・403（失効）・413（大きすぎ）・429（送りすぎ）。

### 取込の流れ（`src/lib/core/ingest/`）
1. NFKC正規化（全角数字・￥）→ 機微情報のマスク（カード番号・口座番号・電話・メール・「○○様」・8桁以上の数字）。
2. 決済の証拠を判定（「金額」と「支払いを示す語」の両方）。なければ記録しない（`ignored_not_payment`）。本人確認書類らしい語があれば抜粋も残さない。
3. 種別判定: 支払い／入金／返金／チャージ・引落・振替（資金移動）／残高・ポイントだけ（取引にしない）。
4. 金額候補を抽出し、残高・ポイント・利用可能額の金額は除外。支払い金額が1つに決まらなければ確認待ち。
5. 日時・店名・取引番号・支払手段を抽出し、確信度を計算。
6. 重複判定: 同じ取引番号 → 重複（無視として残し、戻せる）。同額・同日±1日・店名が近い → 重複候補（確認待ち）。取引番号が違う、または時刻が5分以上離れた通知どうしは別取引。
7. 固定費照合: キーワード一致＋金額近似で予定を「支払済み」に。カード代金の引落は購入と別の資金移動として扱い、支出に足さない（家賃の口座振替など固定費キーワードに一致するものは固定費の支払い）。
8. 自動登録は **既定OFF**。設定で取込元ごとにONにでき、ONでも確信度0.85以上・金額1つ・重複なしのときだけ。

## 5. 計算のきまり（`src/lib/core/summary.ts`）

- すべて Asia/Tokyo（固定 +09:00、夏時間なし）。日付は `YYYY-MM-DD` の暦日で計算し、実行環境のタイムゾーンに左右されない。
- 支出は購入日で数える。カード引落は資金移動（transfer）で支出に入れない。
- 固定費の予定は予測。実績と照合したら予定は消え、実績だけを数える（足し合わせない）。
- 予定の予算は見積り。支払いと紐づけたぶんだけ「使った」とみなし、残りを見込みにする。
- 残り予算
  - 固定費込み予算（既定）: `月予算 − 当月の確定支出 − 当月の未決済固定費 − 今日以降の予定予算の残り`
  - 変動費だけの予算: `月予算 − 当月の確定変動費 − 今日以降の予定予算の残り`（固定費は実績も予定も引かない）
  - 予定予算を見込むかは設定で切替。月予算が未設定なら「予算未設定」。
  - 過去の予定で支払いの紐づけがないものは、すでに実績に入っているとみなして見込みに含めない（二重控除を防ぐ）。画面の内訳にこの扱いを書く。
- 返金は元の支出がある月の支出から引く（元が分からなければ返金日の月）。

## 6. 技術選定

| 項目 | 採用 | 仕様からの変更点と理由 |
|---|---|---|
| フレームワーク | Next.js 16.4.6 App Router + React 19.3 + TypeScript strict | — |
| スタイル | 素のCSS（CSS変数でテーマ）| 仕様はTailwind。リポジトリ内の他アプリと揃え、依存を増やさないため |
| フォーム | React の state | 仕様はReact Hook Form。項目が少なく、依存を増やさないため |
| 検証 | Zod 4 | — |
| 日付 | 自前の暦日モジュール `src/lib/core/date.ts` | 仕様は日付ライブラリ。JSTは固定オフセットなので、`Date` の実行環境TZ依存を避けた純関数の方が安全。月末・うるう年・週境界はテストで担保 |
| DB・認証 | Supabase（supabase-js 2）。メールのワンタイムコード／パスワード | iPhoneのホーム画面アプリはSafariと保存領域が別なので、メールのリンクより「コード入力」の方がPWA内でログインできる |
| OCR | ブラウザで Tesseract.js（日本語）。ショートカットは iOS の「画像からテキストを抽出」 | 画像はサーバーに送らない |
| PWA | `app/manifest.ts` + アイコン + 最小の Service Worker | オフラインでの動作・バックグラウンド動作は保証しない |
| ウィジェット | Scriptable の JavaScript（`scriptable/kurashi-widget.js`） | — |
| テスト | Vitest（単体・API結合）、ローカルPostgreSQLでマイグレーションとRLS、Playwrightで画面操作、Scriptable擬似実行 | — |

## 7. 実装の順番

1. **M1（モックで動く）**: 暦日・繰り返し・固定費・カレンダー統合・集計・クイック入力（純関数＋テスト）→ ホーム／カレンダー（月・週・日）／予定CRUD／家計／取引CRUD／固定費CRUD。デモデータとローカル保存。
2. **M2（取込の芯）**: 通知解析・マスク・重複判定・固定費照合（純関数＋テスト）→ 取込画面（貼り付け・確認待ち・一括承認）→ スクショ手動取込（Tesseract.js）。
3. **M3（クラウド）**: マイグレーション＋RLS（ローカルPostgresで検証）→ ログイン → `/api/dataset` `/api/mutate` → 端末キー → `/api/ingest` `/api/ingest/test` → `/api/widget/summary`。
4. **M4（iPhone）**: Scriptableウィジェット（中→小→大、モック→API、キャッシュ、プライバシーモード）→ ショートカット設定画面と手順書 → PWA（manifest・アイコン・SW）。
5. **M5（仕上げ）**: 書き出し・削除・空/読み込み/失敗の状態・README・NEXT_STEPS・lint/typecheck/test/build・E2E・スクリーンショット。

## 8. テスト計画

| # | 仕様のケース | テストの場所 |
|---|---|---|
| 1 | 980円の通知1回 → 1件・確認待ち | `ingest/pipeline.test.ts`, `server/ingest-handler.test.ts` |
| 2 | 同じ `client_event_id` を10回 → 1件 | `server/ingest-handler.test.ts` |
| 3 | 同額同店・別時刻・別取引番号 → 別々に残る | `ingest/dedupe.test.ts` |
| 4 | 通知→同じ取引のスクショ → 重複候補、確認後1件 | `ingest/pipeline.test.ts` |
| 5 | 支払980円・残高10,000円 → 980円（残高を支出にしない） | `ingest/parse.test.ts` |
| 6 | 家賃85,000円・毎月25日 → 翌月以降に予定、実績でpaid | `recurring.test.ts`, `ingest/pipeline.test.ts` |
| 7 | カード購入→翌月引落 → 支出は1回 | `ingest/parse.test.ts`, `summary.test.ts` |
| 8 | 「明日19時 飲み会 5000円」→ 予定予算であって確定支出でない | `quick-input.test.ts`, `summary.test.ts` |
| 9 | 月末・うるう年・日付境界・終日 | `date.test.ts`, `recurring.test.ts`, `events.test.ts` |
| 10 | 失効キー・別ユーザー・壊れたJSON → 拒否 | `server/ingest-handler.test.ts`, `scripts/test-migrations.sh`（RLS） |
| 11 | 関係ないスクショ → 送らない・取り込まない | `ingest/parse.test.ts`、ショートカット側は実機 |
| 12 | 連携なしでも手入力で使える | E2E `scripts/e2e.mjs` |
| W | ウィジェット: 0件・長文・0円・マイナス残額・通信失敗・古いデータ | `widget.test.ts`（要約）, `scripts/widget-harness.mjs`（Scriptable擬似実行） |

**実機でしか確かめられないもの**（`docs/IOS_27_VALIDATION.md` に記録）: iOS 27 の通知/スクショのオートメーションが渡す値、決済アプリごとの通知文面、ロック中・通信断の挙動、Scriptable の実際の描画と更新間隔、ホーム画面PWAのログイン維持、Tesseract.js の実画像での精度。

## 9. 本番向けの改修（v0.2）

| 項目 | やったこと |
|---|---|
| 他の人に見せない | `src/proxy.ts` の合言葉ゲート（`KURASHI_ACCESS_CODE`）。署名つき HttpOnly Cookie（約400日）。ショートカット・ウィジェットの受け口だけは端末キーで守る。noindex |
| データの引っ越し | 「この端末だけ」→ クラウドを分割して送る（参照の順を守る・同じ id は上書き＝やり直せる）。書き出した JSON の読み込み。デモは持ち込まない。古い版で空だった日時を直す |
| 入力を失わない | クラウドの変更は端末に控えてから送る（未送信キュー）。電波が戻る・開き直すと再送。前回読んだ内容を端末に置き、圏外でも起動（Service Worker で静的ファイルと開いた画面を保存） |
| 設定の確認 | `/api/health`（合言葉の内側）と設定の「本番の設定チェック」。Supabase の URL・キー・テーブル・新規登録の停止・メールの限定・合言葉 |
| 外部への依存を減らす | OCR（Tesseract.js）のエンジンと日本語データを自分のサイトから配る。CSP で外部は Supabase だけ |
| その他 | エラー画面、本番の既定はクラウド、ログアウトは端末だけで完結、すべての操作の結果がサーバーの検証を通るテスト |

## 10. 入力を簡単にする改修（v0.3 / v2 の入力）

ご本人の要望:「自動取込より、入力のかんたんさ。項目を減らす。カテゴリを絞る」。

| 項目 | やったこと |
|---|---|
| 入力の入口 | 下の「＋」→ **お金／予定／1行で** のタブ。ホームにも「使ったお金」「予定を追加」の大きなボタン。カレンダーの日付から開くとその日が入る |
| お金 | 使った／入った → 金額（大きな数字）→ カテゴリ（3列のボタン）→ 今日／昨日／日付を選ぶ → メモ（任意）→ 記録。時刻・支払い方法・固定費・予定との紐づけ・返金・資金移動は「詳しく」 |
| 予定 | 名前 → 種類（私用・仕事・友達・家族・有給）→ 今日／明日／日付 →（時間を決める／2日以上）→ 追加。予算・場所・繰り返し・メモは「詳しく」 |
| カテゴリ | 支出: コンビニ・遊び（飲み・外食）・日用品・固定費（家賃・光熱）・投資・医療費・その他（よく使う順）。収入: 給料・配給・配当金・ポイ活。前のカテゴリは古い記録の表示だけに残す |
| NISA | `src/lib/core/nisa.ts`。その年（1〜12月）の確定した「投資」を、つみたて（120万）・成長（240万）・NISA以外に分けて数え、残り枠を出す。投資は支出・残り予算・カレンダーの支払に入れない |
| ポイ活 | `profiles.point_programs`。入力でプルダウン、設定で追加・削除・並べ替え。選んだポイント名は `transactions.subcategory` |
| 祝日 | `src/lib/core/holidays.ts`（春分・秋分の計算、振替休日、国民の休日、2020・2021年の移動）。月表示は日曜・祝日を赤、土曜を青の地色、祝日名を小さく |
| 複数日の帯 | `weekBars()`（`src/lib/core/calendar.ts`）で週ごとに段へ詰める。長い・早い予定が上。3段をこえる分は「+n」 |
| 有給 | 種類「有給」の予定（1日／半休 0.5日）。`leaveSummary()` が付与日から1年の間で数える（複数日は土日祝を除く）。残り＝付与＋繰越−調整−使った日。設定で付与日・日数・繰越・調整を直せる |
| ホーム | 残り予算（押すと計算の内訳と予算組み）＋「支出・収入を記録」「予定を追加」＋今日の予定＋今月のまとめ（支出・収入・固定費・NISA・有給）。まとめの行を押すと詳細シート（`src/components/Details.tsx`）。家計の画面も同じまとめを月ごとに |
| 予算組み | `profiles.category_budgets`（カテゴリ id → 円）。`budgetPlan()` がカテゴリごとの予算・支出・残りと未割り当てを出す。投資は入れない |
| 言葉 | 支出・収入・固定費・残り予算・取得（有給）など、家計簿で一般的な言い方にそろえた |
| DB | `supabase/migrations/20261115000000_v2_inputs.sql`（列の追加と新しい標準カテゴリ。何回流してもよい）。前の版のデータは `normalizeDataset()` で欠けを埋めて読む |

## 11. ブラッシュアップ（v2.2）

| 項目 | やったこと |
|---|---|
| 今日あと使える額 | `dailyAllowance()`＝残り予算 ÷ 月末までの日数（今日を含む）。ホームの残り予算とウィジェット（`dailyAllowanceYen`） |
| よく使う入力 | `frequentEntries()`：最近120日に2回以上の「カテゴリ・メモ・金額」を候補に。押すとすぐ記録（固定費の支払いは除く） |
| 電卓 | `evalAmount()`：＋−×÷・かっこ。入力欄の下にボタン |
| カテゴリの並び | `orderByUsage()`：最近90日の回数順。「その他」は最後 |
| 予算の注意 | `budgetAlerts()`：カテゴリ予算の80%以上と超過、月の予算の超過。ホームに表示 |
| 有給の期限 | `leaveExpiry()`：付与期間の終わりまで60日以内で残りがあるとき |
| 記念日・カウントダウン | 予定の種類「記念日」と `schedule_events.countdown`。`countdowns()` がホームに「あと◯日」 |
| 予定の複製 | `duplicateEvent()`：時刻・日数そのまま、繰り返しなしで別の日に |
| 固定費の土日祝ずらし | `recurring_rules.holiday_shift`（none/next/prev）。ずらす前に保存した回も同じ回として扱う |
| 検索 | `search()`：予定・取引・やることから。見つかった支出の合計も出す（`/search`） |
| やること・買い物 | `todos` 表（RLS）。下のメニューの「やること」。期限のあるものはホームと通知に出る |
| ふり返り | `monthReport()`：先月比・カテゴリ別の比較・6か月の推移・今年の配当金・ポイ活・賞与・NISA（`/money/report`） |
| 毎朝の通知 | Web Push。`push_subscriptions` 表、`/api/push/*`、Vercel Cron `/api/cron/daily`（7:30 JST ごろ・同じ日に1回だけ）。VAPID 鍵は service_role キーから HKDF で作る（環境変数の追加なし）。`web-push@3.6.7` |
| Face ID ロック | WebAuthn（端末の生体認証）で開くまで中身を出さない。端末の中だけの設定。のぞき見防止で、データの守りは合言葉とログイン |
| 自動バックアップ | 端末キーに「バックアップ」（全データの読み取りだけ）。`GET /api/backup` をショートカットが週1回呼び、iCloud Drive に保存 |
| カテゴリ | 収入に「賞与」 |
| 下のメニュー | 「取込」→「やること」。取込は家計の画面から |
