# DB リハーサルの結果（夜間・2026-11-20）

> **調べたのは、このコンテナの使い捨てのローカル PostgreSQL 16.15 だけです。** 本物の Supabase・Vercel には一度も接続していません（DB はソケットだけで待ち受け、ネットワークは使っていない）。Supabase の役割と `auth.uid()` は `supabase/tests/supabase_stub.sql` で真似ています。
> **本物の DB がどの SQL まで流れているかは分かりません**（「SQL 13 まで」は確かめていない前提）。**流す SQL もまだ決まっていません**（`SQL_MIGRATION_PLAN.md` の 9）。

## 0. 実行したコマンドと結果

| コマンド（`kurashi-calendar/` で） | 終了コード | 時間 | 記録 |
|---|---|---|---|
| `npm run test:db:rehearsal`（`bash scripts/db-rehearsal.sh`） | 0（FAIL 0） | 約 95 秒 | `quality/evidence/night-db/db-rehearsal-run.log`・`REHEARSAL_SUMMARY.txt`・`commands.tsv`（各手順のコマンド・終了コード・ミリ秒） |
| `npm run test:db`（既存の DB の試験＋夜間に足した試験） | 0 | 約 12 秒 | `quality/evidence/night-db/checks/test-db.log` |
| `python3 scripts/check-readonly-sql.py supabase/checks/applied_status.sql supabase/checks/current_structure.sql` | 0 | 1 秒未満 | `checks/check-readonly-sql.log` |
| `sha256sum supabase/migrations/*.sql` とマニフェストの照合 | 0（14 本すべて一致） | — | `checks/sha256-manifest.log` |
| `npx vitest run` | 0（1079 件成功・3 件スキップ） | 約 12 秒 | `checks/vitest.log` |
| `npx tsc --noEmit` | 0 | 約 15 秒 | `checks/typecheck.log` |
| `npx eslint` | 0（エラー 0・警告 2。どちらも `src/` の既存の警告で、今回は `src/` を変えていない） | 約 25 秒 | `checks/lint.log` |

`commands.tsv` の「expect」が `fail` の行は、**わざと失敗させた手順**（壊した写し・壊れたダンプ・二重の復元・2回目の init など）で、終了コードが 0 以外なのが期待どおりです。

## 1. 一覧（SQL 15 本）

`SQL_MIGRATION_PLAN.md`・`SQL_MIGRATION_PLAN.csv`。14 本の SHA256 は参照のマニフェストとすべて一致。15 は夜間の【提案・未承認】。
1 本ずつ流したときの構造の差（表・列・制約・索引・ポリシー・権限・関数・トリガー）を自動で取りました：`quality/evidence/night-db/structure/diff_level*.txt`。

## 2. 読むだけの SQL（applied_status.sql・current_structure.sql）

- `applied_status.sql` は**1つの SELECT だけ**で、DDL・DML・副作用のある関数を含みません（文字の上の確かめ：文 1 つ・書き込みの言葉なし・呼ぶ関数は `to_regclass`・`to_regprocedure`・`coalesce`・`bool_or`・`aclexplode`・`acldefault` だけ）。15 の行（【提案・未承認】）を足しました。
- 新しく `supabase/checks/current_structure.sql` を作りました。1つの SELECT で、表・列・RLS・ポリシー・関数と EXECUTE の権限・トリガー・表の権限・索引・制約・既定の権限・拡張・CLI の移行の履歴と、**表ごとの件数だけ**を出します。**行の中身は1つも出しません**（関数の本文も md5 だけ）。件数は組み込みの `query_to_xml` で `count(*)` を数えるだけです。結果の行数（約 900 行）を自分で出すので、CSV が途中で切れていないか確かめられます。
- 確かめたこと（`readonly-checks.log`・リハーサル A）：
  - **0 段（何も流していない）〜15 段のどの段でも**、両方の SQL が**読み取り専用のトランザクションの中で通り、トランザクションの番号が付かない**（＝何も書いていない：`pg_current_xact_id_if_assigned()` が空）。
  - 各段で `applied_status` は「1〜その段が true・残りが false」（途中まで流した状態も正しく出る）。
  - 3 回ずつ流した前後で、行も構造も同じ。
  - Supabase の役割（anon など）がない素の DB でも、どちらも止まらない。
- **本人は明日、本物の DB でこの2つを流すだけ**（読むだけ）。ほかの場所では流しません。

## 3. リハーサル（使い捨ての DB）

| | やったこと | 結果 |
|---|---|---|
| A | 空の DB に 1〜15 を順に（1 本ずつ1つのトランザクション） | すべて成功。1 本 約 30〜110 ms（psql の起動を含む。ときどき 200 ms ほどの揺れ）。2〜15 はもう一度流しても構造が同じ（権限・関数の本文の md5 も）。1（init）は2回目に止まり、何も変わらない。15 のあとに 5 を流し直しても EXECUTE は外れたまま |
| B | 9・11・12・13 まで流した DB に、2人のオーナー（A・B）の架空のデータ（取引 46 件ずつ・予定（旅行の親子・繰り返しの例外）・投資の設定・固定費と回・旅行の予約（外貨）・口座とカード・請求と引落し・ノート・資格・学習・目標と実績など。13 の段で 283 行）→ 残りを流す | **4 つの段のすべてで、前からある列の値が全行同じ**（UUID・持ち主・NULL・timestamptz・JSON・金額。表ごとの md5 も）。件数・持ち主ごとの件数・金額の合計・親子と例外のつながり・NULL の数・時刻の範囲が同じ。足された列は既存の行で空か既定値だけ。移行のあとの構造は、空の DB に全部流したときと同じ。移行のあと、新しい版の表・列に書ける |
| B（移行のあと） | RLS・スナップショットの関数・保存の関数（同期）・競合・ほかの人の参照・トリガー（`supabase/rehearsal/after_checks.sql`・最後に ROLLBACK） | A は自分の行が全部見え B の行は 0 件・`kurashi_export_snapshot` の件数が表と一致・**前の版（v5.1 の列だけ）が取引を直しても新しい版の口座のつながりが残る**・古い版からの保存は KC409・B のカテゴリや旅行を参照すると 42501（トリガーの決まり）・2段の親子は 23514・B は A の行もスナップショットも読めない・anon は何も読めない・サーバーの役割でも A の行を B として上書きできない |
| C | 13 → 14 | 13 のとき `kurashi_schema_level`=13（いまのアプリは v5.4 の機能を保存しない・RC4 はオン）、14 のあと 14（どちらもオン）。**RC4（SQL 13 の列だけ）が目標・教材を保存しても `todo_id`・`budget_category_id`・`target_year` が残る**。B の行にはつなげない |
| D | 失敗の注入（壊したのは**一時ディレクトリの写し**だけ。14 本のファイルの SHA256 は前後で同じ） | 下の表 |
| E | DB 全体のバックアップと復元 | 5 を参照 |
| F | Supabase の「新しい表・関数を自動で公開する」既定の権限を真似た DB | 4 を参照 |
| G | 前の版の DB の試験を、いまの全部の移行のあとに | 6 を参照 |
| H | 多めの架空のデータ（約 2.6 万行・15 MB） | 12＝78 ms・13＝73 ms・14＝43 ms・15＝43 ms。前からある列の値は全部同じ |

### D 失敗の注入

| 流し方 | 結果 |
|---|---|
| D1 1つのトランザクション（`psql -1`。CLI と同じ考え方）で、14 の写しの途中（`kurashi_schema_level` を 14 にして `goals.todo_id` を足したあと）で失敗 | **何も残らない**（構造も行も流す前と同じ・`kurashi_schema_level` は 13 のまま） |
| D2 全文を1つの問い合わせで送る（SQL Editor の送り方の想定。明示の BEGIN がなければ PostgreSQL は全体を1つのトランザクションにする） | **何も残らない** |
| D3 1 文ずつ確定する流し方（`psql -f` だけ） | **途中までが残る**：`kurashi_schema_level`=14（アプリは v5.4 の機能をオンにしてしまう）・`todo_id` はあり・`budget_category_id` はなし。`applied_status` の 14 は false で気づける。**もとの 14 を流し直すと**（ロールフォワード）、構造は最初からきれいに流した DB と同じ・行は失敗の前と同じ（DROP も戻す SQL も使わない） |
| D4 12 の写し（表 6 つ・列・RLS・トリガーのあと）で失敗・5 の写し（自分で BEGIN・COMMIT を持つ）で失敗 | どちらも**何も残らない**（5 は 1 文ずつの流し方でも、ファイル自身のトランザクションの中で止まる） |
| D5 ほかの接続が goals を開いたまま 14 を流す | `lock_timeout=2s` なら 2 秒で止まり（55P03）何も残らない。付けないと 14 は待ち、**そのあいだに来たふつうの読み取りも 14 の後ろで待たされる**。先の接続が終われば 14 は通る（約 3 秒待って通った） |

## 4. 権限（anon・authenticated の A と B・service_role）

`supabase/tests/night_permissions_matrix_test.sql`（`npm run test:db` にも入れた。全体を ROLLBACK）。表は pg_catalog から数え上げ、28 表 × 4 つの役割 × 9 つの操作（読む自分／読む他人／足す自分／足す他人／変える自分／変える他人／自分の行を他人のものに／消す自分／消す他人）と、public の関数 14 個（16 通り）× 5 つの役割（anon・A・B・service_role・supabase_auth_admin）を試しました。結果の表：`quality/evidence/night-db/rehearsal/A/matrix_level15.log`（15 の前は `matrix_level14.log`）。

- **anon**：どの表も読めず（42501）・書けない。呼べる関数は `kurashi_schema_level` だけ。
- **authenticated（A・B）**：自分の行は全部の表で読める・書ける。**他人の行は読めない（0 件）・変えても消しても 0 件・他人の名前で足すと 42501・自分の行を他人のものにすると 42501**。サーバーだけの表（push_report_log・widget_link_codes・api_rate_events・beta_allowed_emails）はどの操作も 42501。端末キーは一覧を読むだけ。呼べる関数は `kurashi_apply_changes`（自分だけ。他人の id で 42501）・`kurashi_export_snapshot`（自分だけ）・`kurashi_schema_level`。
- **service_role**：RLS を通らないので全部の行を読める（サーバーは `p_user` で持ち主を確かめる）。サーバーの関数（通知・回数の制限・接続コード・片づけ）は呼べる。**ほかの人の行を参照する保存は、service_role でもトリガーで 42501**。
- **トリガー**：ほかの人の予定を親に → 42501／2段の親子 → 23514／子のある予定を子に → 23514／ほかの人の固定費 → 42501／ほかの人のカテゴリ・やること → 42501／サーバーの役割でも同じ／自分の旅行に子を足す → 通る。

### `kurashi_check_event_parent` の EXECUTE の監査（`quality/evidence/night-db/execute-audit.log`）

- **14 の段（いまの 14 本だけ）**：この関数（SECURITY DEFINER のトリガーの関数）の権限は「既定＝PUBLIC が EXECUTE を持つ」で、**anon・authenticated・service_role のどれも EXECUTE を持つ**。直接呼ぶと全員 0A000（トリガーとしてしか呼べない）なので、いまでも直接は悪用できない。もう一つのトリガーの関数 `kurashi_check_refs_owner` は 9 で外してあり、全員 42501。
- **提案の 15 を足しました**（`supabase/migrations/20261120000000_revoke_event_parent_trigger_execute.sql`・【提案・未承認・本物の構造を確かめてから】）。PUBLIC・anon・authenticated の EXECUTE を外すだけ。15 のあと：直接呼ぶと全員 42501、**トリガーはこれまでどおり動く**（上のトリガーの結果は 15 のあと。`night_m15_trigger_execute_test.sql` でも確かめた）、5 を流し直しても外れたまま、`kurashi_schema_level` は 14 のまま。どの版のアプリもこの関数を直接は呼ばないので、前の版のアプリに影響はありません。

### Supabase の「自動で公開する」既定の権限を真似た DB（F）

本物の Supabase は、設定によって、新しい表・関数・シーケンスに anon・authenticated・service_role の権限を自動で付けます（どちらの設定かは分からない。`current_structure.sql` の「10 既定の権限」で分かる）。その真似（`supabase/rehearsal/supabase_default_privileges.sql`）で全部を流すと：

- 権限の表の決まり（他人の行が見えない・変えられない・anon は何も読めない）は**そのまま守られた**（RLS と関数の中の確かめのため）。after_checks も成功。
- ただし権限そのものは広くなる：
  1. `kurashi_export_snapshot` を **anon も EXECUTE できる**（6 が anon から明示で外していないため）。中で anon を断るので 42501 になり、データは出ない。既存の試験 `qr_se02_two_owners_test` の「anon が呼べる関数は決めた一覧だけ」はこの設定では失敗する（`rehearsal/F/existing_suite.tsv`。ほかの 13 本は成功）。
  2. `kurashi_check_event_parent` は 15 のあとも **service_role だけが EXECUTE を持つ**（15 は service_role から外さない。直接は呼べない 0A000）。
  3. authenticated は多くの表に TRUNCATE（RLS を通らない）・REFERENCES・TRIGGER の権限を持ち、anon も todos・push_subscriptions に全部の権限を持つ（2 が anon から外していないため。RLS のポリシーは authenticated だけなので、読み書きは 0 件）。**API（PostgREST）からは TRUNCATE などは使えない**ので、アプリの経路からは悪用できないが、最小の権限ではない。
  - これらは本物の設定が分かってから決める**次の候補**で、15 には入れていません（`DB_USER_PROCEDURE.md` の 1 で見る場所を書いた）。

### Storage

Supabase の `storage` スキーマはローカルにないので、**Storage の権限は試せていません**。アプリ（`src/`）は Supabase Storage を使っていません（`storage.from` の呼び出しがない）。`current_structure.sql` は、本物の DB に storage があれば、バケットとオブジェクトの件数と storage のポリシーを出します。

## 5. バックアップと復元

### DB 全体（pg_dump・ローカル。`quality/evidence/night-db/rehearsal/E/`・`H/`）

| | 結果 |
|---|---|
| 小さなデータ（283 行・全部の表） | `pg_dump -Fc` 111 ms・約 192 KB。同じクラスタの新しい DB へ `pg_restore --single-transaction` 252 ms。**行（全部の列）・要約・構造が元と同じ**（文字の差は、検査の制約 1 つの括弧の付け方だけ。pg_dump が式を組み直して書くため。意味は同じ）。復元した DB でも RLS・関数・同期・トリガー・権限の表が決まりどおり |
| 別のクラスタ（新しく initdb した PostgreSQL） | 役割（`pg_dumpall --roles-only` から）→ DB → 復元 → 行の確かめまで 1.2 秒（復元そのものは 202 ms）。行が元と同じ。RLS・関数も動く |
| 多めのデータ（約 2.6 万行・15 MB） | `pg_dump` 208 ms・約 1.2 MB。`pg_restore` 430 ms。行が全部同じ |
| 途中で切れたダンプ・1 か所を書きかえたダンプ | どちらも復元は止まり、**復元先の DB に表は 1 つもない**（途中まで入らない）。書きかえたダンプでは `pg_restore` 自身が異常終了した（Segmentation fault）が、復元先は空のまま |
| 二重の復元（全体・データだけ） | どちらも止まり、**行は重ならず元のまま** |

- ローカルの RPO・RTO の目安：バックアップを取った時点より後の変更は戻らない（RPO＝最後のバックアップからの時間。移行の直前に書込みを止めて取れば、移行のぶんは 0）。復元の作業そのものは、この大きさなら 1 秒前後（RTO の目安は `DB_USER_PROCEDURE.md` の 7）。
- **ダンプには個人のデータが平文で入る**（アプリの .kcb と違って暗号化されない）。本物で取るなら、暗号化した場所に置き、要らなくなったら消す。

### アプリのバックアップ（暗号化 .kcb）は既存の試験で確かめ済み（今回は DB 全体の証拠だけを足した）

- `src/lib/core/__tests__/backup.test.ts`：BK-01（AES-GCM・本番の 60 万回）・**BK-02／BK-04（パスフレーズ違い・1 バイトの書き換え・ヘッダーの書き換え・途中まで・空は戻さない。失敗でいまのデータを変えない）**・**BK-03／BK-11（2 回戻しても二重にならない・新規／同一／競合／類似）**・BK-05（別のアカウントのバックアップは戻さない・件数とチェックサム）・BK-12（前の版の書き出しを版で見分ける）・自動バックアップの暗号化（公開鍵・パスフレーズ違い）。
- `src/lib/core/__tests__/v54-rc-restore.test.ts`（RC-D01 新しい表を含めて暗号化 → 空のところへ戻す・RC-D06 前の版との行き来）・`qf3-qg07-restore-count.test.ts`（足す件数＝足した件数）。
- `src/lib/server/__tests__/restore-sql.gen.test.ts`（`npm run test:db` の中で、本物の保存の関数に 300 件ずつ別のトランザクションで復元・途中で止めてやり直す）。
- E2E：`scripts/e2e-qr-slice2.mjs`（別のブラウザの保存場所へ戻して 16 の表を比べる）・`scripts/e2e.mjs` の F10・v5.1 暗号化バックアップ（台帳の DATA03・DATA04・SE04 の証拠）。
- `npx vitest run`（1079 件成功）にこれらが入っています。

## 6. 前の版のアプリの DB の試験を、いまの移行のあとに流す（G）

前の版のコミット（0f06dd3 v5.1β・7502662 v5.2・dba0d60 v5.3・759f99e RC3・468d406 RC4）から、その版の `supabase/tests/` と `scripts/test-migrations.sh` の試験の一覧を取り出し（`git archive`・読むだけ）、いまの 15 本を流した DB で、その版の順に流しました（`quality/evidence/night-db/rehearsal/G/old_tests.tsv`）。**59 件のうち 55 件が成功**。失敗した 4 件は、止まらずに最後まで流して全部の ERROR を出しました（`*_errors.txt`）：

| 前の版 | 試験 | 理由 | 判断 |
|---|---|---|---|
| v5.1β・v5.2・v5.3 | `three_accounts_test.sql` | 「user_id のある全部の表に、自分の行がある」と数える試験が、あとから足された表（資金の移動・資格など。その版の試験はデータを入れない）で「自分の行が見えない」と止まる。止まらずに流すと、**ERROR はこの 3 回（3 人分）だけで、ほかの分離・ほかの人の参照の確かめはすべて通った** | 試験の前提の違い（データ・権限の非互換ではない）。いまの `three_accounts_test.sql` は全部の表に行を入れて成功 |
| v5.3 | `v53_test.sql` | ACC08「同じ請求の引落しは 1 回だけ（別の id の 2 回目は断る）」が、13 で一意の索引を外したので通る。**ほかの確かめ（前の版の保存で account_id が残る など）はすべて通った** | **本当の非互換**（意図した変更）。13 のあとに v5.3 のアプリが残っていると、同じ請求の引落しが 2 件入りうる。13 を流す前に全部の端末を RC4 以降にする（`SQL_MIGRATION_PLAN.md` の 7） |

- RC3・RC4 の試験ファイルは、いまのものと中身が同じでした（いまの `npm run test:db` と同じ試験）。
- 前の版の `test-migrations.sh` は `.sh` の試験の前に「復元の SQL」（vitest が作る）を流していましたが、前の版のソースが要るので流さず、その SQL が作っていた利用者（5555…）だけを足して前提をそろえました。
- アプリの版の判定：RC4 のアプリは `kurashi_schema_level` が 13 以上で v5.4 の機能をオンにするので、14 のあとも動きます。

## 7. ローカルで確かめていないこと（本物でしか分からない）

- 本物の Supabase の**どの SQL まで・どの版の写しが流れているか**、CLI の履歴があるか、既定の権限の設定（自動で公開するか）。→ 明日の読むだけの SQL で分かる。
- 本物の**認証（GoTrue）**：ログイン・JWT の中身・`auth.uid()`・Before User Created のフック（Dashboard で有効か）。ローカルは `request.jwt.claim.sub` で真似ただけ。
- **PostgREST（API）**の公開のしかた（どの関数が `/rpc` に出るか・スキーマのキャッシュの更新）。ローカルは SQL で役割を切り替えただけ。
- **Storage**（ローカルにない。アプリは使っていない）。
- **ネットワーク**・SQL Editor の往復の時間・SQL Editor が全文を1つのトランザクションで流すか（D2 はローカルの PostgreSQL の決まりでの想定）・接続のプール。
- **容量・回数の上限**（無料枠のプロジェクト数・一時停止・DB の大きさ・バックアップの有無と保持期間）。
- 本物の **Dashboard のバックアップ（毎日・PITR）からの復元**と、その時間。本物の DB を `pg_dump` したときの Supabase の管理用のスキーマ（auth・storage など）の扱い。
- iPhone・ウィジェット・同期の実機の動き（端末内のプレビューでは本物の動きは確かめられない）。台帳の実機・実 Supabase でしか終わらない項目は未達のままです。

## 8. 台帳への提案（`quality/evidence/night-db/REPORT.json`）

| 行 | 提案 | 理由 |
|---|---|---|
| SE02 | PASS のまま | ローカルの条件（2 アカウント・全部の表・API・RLS・参照 ID）を、権限の表で 4 つの役割 × 28 表 × 9 操作・関数 14 個 × 5 役割・トリガー 9 件まで広げて確かめた。残りに書かれていた「kurashi_check_event_parent の EXECUTE」は、提案の 15 で外せることを確かめた（未適用） |
| SE07 | PARTIAL のまま | 旧データ・旧バックアップの非破壊の移行と、失敗の再実行・ロールフォワードはローカルで確かめた。行の条件の「実分離環境」は外部（承認と別の Supabase が要る） |
| DATA01 | PARTIAL のまま | v5.2 の状態（11 まで）＋架空のデータ → 移行で件数・ID・金額・関連が同じ・再実行・途中の失敗からの再開はローカルで確かめた。「分離 Supabase」「認証の保持」は本物でしか分からない |
| DATA03 | PARTIAL のまま | DB 全体の復元（別の DB・別のクラスタ・重複なし・壊れたダンプ）を足した。分離した Supabase での復元は未実施 |
| RC4-15 | BLOCKED のまま | 分離した Supabase と SQL の実行の承認が要る。ローカルの部分（旧版 → 全部の移行 → 復元 → 2 人の分離・件数／関連／金額の照合）は終えた |

## 9. 証拠の一覧（`quality/evidence/night-db/`）

- `REHEARSAL_SUMMARY.txt`（PASS／FAIL の一覧）・`commands.tsv`（コマンド・終了コード・ミリ秒）・`db-rehearsal-run.log`
- `readonly-checks.log`（読むだけの SQL の確かめ）・`execute-audit.log`（EXECUTE の監査）
- `structure/`（各段の構造の差・期待する構造の CSV：13・14・15 の段・比べる道具の確かめ）
- `rehearsal/A`〜`H`（各段のログ・時間・ロック・要約・md5・権限の表・前の版の試験）
- `checks/`（test:db・vitest・tsc・eslint・SHA256）
