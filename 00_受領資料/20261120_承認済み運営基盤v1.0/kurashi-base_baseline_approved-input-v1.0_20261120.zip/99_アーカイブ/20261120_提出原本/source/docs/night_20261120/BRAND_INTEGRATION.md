# くらしベース（KURASHI BASE）のブランドの反映（レビュー版）

名前は正式採用の候補（商標・ドメインは未確認。一般公開の前に本人が確かめる）。採用案は brand_kit の reference/selected-brand-board.png（左案）。

## 変えたもの（画面に出るものだけ）
| もの | 前 | 後 |
|---|---|---|
| 名前（見出し・ロック・テストモードの始め・エラー・ログイン・β の案内・通知の題・バックアップの共有の題・一時停止の知らせ・Face ID のロックの表示） | くらしカレンダー | くらしベース（`src/lib/brand.ts` の1か所） |
| ブラウザの題・applicationName・ホーム画面の名前（appleWebApp） | くらしカレンダー・くらし | くらしベース |
| manifest の name・short_name・description・theme_color・background_color | くらしカレンダー・くらし・#6A4CE0・#F6F4FB | くらしベース・くらしベース・#0B2545・#F2F8FA |
| アイコン（192・512・maskable 512・Apple 180・Next の icon/apple-icon）・favicon.ico | 前の絵 | brand_kit の絵（大きさは同じ） |
| 見出しのシンボル | 「暮」の四角 | 家のシンボル（ライト／ダークで切りかえ・`public/brand/`） |
| ウィジェット（Scriptable）の見出し・題 | くらしカレンダー | くらしベース |
| 形式が違うファイルの知らせ | 「くらしカレンダーの…ではありません」 | 「くらしベース（旧 くらしカレンダー）の…ではありません」 |

## 変えていないもの（互換性・試験 `night-brand.test.ts` で守る）
- manifest の start_url `/`・scope `/`・id なし（暗黙の id のまま＝ホーム画面の PWA を別物にしない）・アイコンのパス
- 保存のキー：`kurashi.mode`・`kurashi.theme`・`kurashi:lock:v1`・IndexedDB の名前 `kurashi`（テストモードは `kurashi-review`）
- Service Worker：控えの名前 `kurashi-`・VERSION `v3`・登録の scope
- 形式の識別子：書き出しの `app: 'kurashi-calendar'`・暗号化バックアップの `f: 'kurashi-calendar-backup'`・`KCB1`
- iCal の `PRODID:-//kurashi-calendar//JA`・`UID:…@kurashi-calendar`（変えると、取り込んだカレンダーで予定が二重になる）
- Web Push の鍵の導出の文字 `kurashi-calendar`（変えると、登録済みの通知が届かなくなる）
- 本番の URL の既定 `https://kurashi-calendar.vercel.app`・package の名前・ウィジェットのファイル名とペアリング・Supabase・認証の URL・DB
- 移行の SQL（14本）の先頭のコメント（SQL は書きかえない）
- 色の意味（支出・収入・注意・不足）とテーマの選択。ブランドの色は、シンボル・manifest・アイコンだけに使った

## 確かめたこと
- 単体 `night-brand.test.ts`（6件）：名前・manifest（start_url・scope・id なし・アイコン）・PNG の大きさ・favicon・合言葉の前に読めるアイコン・SVG に外への読み込みやスクリプトがない・保存のキーと形式の識別子が同じ・前の名前が互換の知らせのほかに残っていない
- 更新の互換 `scripts/e2e-night-brand-upgrade.mjs`：ブランドの前の版（1fe1bfb）で使っていた端末（同じ origin・同じ利用者のフォルダ）をブランドの版に入れかえ、記録（id も同じ）・テーマの選択・IndexedDB と SW の控えの名前が残り、見出し・題・manifest・アイコン（192・512・maskable・180）が新しくなり、新しく記録できる（3回とも成功）
- 通常の E2E 63/63（合言葉の前に、前の名前も新しい名前も見せない）
- 見出しの写真：`quality/evidence/night-brand/header-390-{light,dark}.png`

## 本人が確かめること
- iPhone のホーム画面のアイコンは、前の絵が残ることがある（iOS の仕様）。追加し直すときは、先に暗号化バックアップを取る（ホーム画面の PWA の保存は Safari と別のため）
- 名前・ロゴの正式採用・商標・ドメイン
