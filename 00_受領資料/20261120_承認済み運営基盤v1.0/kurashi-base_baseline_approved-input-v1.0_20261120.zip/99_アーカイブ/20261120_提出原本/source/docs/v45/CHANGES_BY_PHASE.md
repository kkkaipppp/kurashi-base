# v4.5 フェーズ別の変更

- 基準：`f37dc5a`（UX v3・PR #8）。
- 作業ブランチ：`claude/loving-curie-madwt7`。
- 本番デプロイ・PR のマージ・本番 DB の操作はしていない。

## Phase 0：UX v3 レビュー12件（コミット `6a681d9`）

再現テストを先に書いて失敗を確かめてから直した。詳しくは `REVIEW_12_RESULTS.md`。

| ファイル | 変更 |
|---|---|
| `src/lib/core/recurring.ts` | `cyclePeriod()`。日付を変えたあとの「同じ区切りの回」を1回とみなす（V3-01） |
| `src/lib/core/ops.ts` | `resumeRule()`。再開時に止めていた間の回を「今回はなし」で保存（V3-05） |
| `src/components/views/FixedViews.tsx` | 「再開する」を `resumeRule` に |
| `src/lib/store/outbox.ts`・`cloud-cache.ts`・`StoreProvider.tsx` | 未送信キューを1件1キーに（V3-06）。控えに書けたときだけキューから消す `parkRejected`（V3-02） |
| `supabase/migrations/20261116000000_v45_apply_changes_lock.sql` | 保存関数に `FOR UPDATE`（V3-07）。**新しいファイルのみ・本番未適用** |
| `supabase/tests/concurrency_test.sh`・`scripts/test-migrations.sh` | 2セッション同時保存のテスト |
| `src/lib/core/annual.ts` | `isLoadedMonth`・`afterToday`・`mergeOverview`・`fullYearComparison`（V3-03/04/08） |
| `src/components/views/ReportView.tsx`・`MoneyView.tsx` | 未取得の月は金額を出さない。古い年の集計を比較にも反映 |
| `src/components/Section.tsx`・`src/lib/ui/fold.ts`・`forms/MoneyForm.tsx` | 開閉の状態を `useSyncExternalStore` に（V3-09） |
| `src/lib/ui/chart.ts`・`src/components/YearChart.tsx` | マイナスの棒（V3-11）、44px の月ボタン（V3-10） |
| `src/lib/server/repo.ts` | 古い年 API の返金を DB 側で絞る（V3-12） |
| テスト | `v3review.test.ts`・`v3review-sync.test.ts`・`chart.test.ts`・`outbox.test.ts` |

## Phase 1：画面と OCR（コミット `2515339`・`4dd5d40`）

| ファイル | 変更 |
|---|---|
| `src/components/views/HomeView.tsx`・`InsightCard.tsx` | ホームを「今日の予定（3件）→今日使える→今月の残り予算」に。急ぎの「くらしの気づき」は1件だけ、なければ出さない。3日以内の固定費は予定の中に1行。追加ボタン・確認待ち・期限のやること・「もっと見る」（固定費・カウントダウン・まとめ）は下へ |
| `src/lib/core/calendar.ts`・`views/CalendarView.tsx` | 絞り込みを 全部・予定・支出・固定費 に（表示だけ。合計は変えない）。選んだものを端末に覚える |
| `src/lib/core/ingest/screenshot.ts`（新） | 取引の候補・種別とカテゴリの候補（理由・確かさ）・重複／固定費／返金の照合。保存はしない |
| `src/lib/core/ingest/parse.ts` | 店名の読み取りを強化（「○○で720円のお支払い」「○○ お会計」「Amazon でのご注文」、レシートの1行目）。「ご購入金額」を入金と読まない。注文・請求・合計を支払いの言葉に |
| `src/components/views/ScreenshotImportView.tsx`（新）・`src/app/import/screenshot/page.tsx`・`src/lib/ui/ocr.ts`（新） | 「スクショから追加」：端末内 OCR → 候補を確かめて直す → 登録 |
| `MoneyView.tsx`・`AddSheet.tsx`・`ImportView.tsx` | 「スクショから追加」の入口（家計の「＋支出を追加」の隣・追加シート・取込） |
| `views/FixedViews.tsx` | 次の支払いを先頭に。すべて・未払い・支払済み・停止中の絞り込み。登録画面のプレビューを次の3回と月あたりの額に |

## Phase 2：無料の分析（コミット `2515339`・`4dd5d40`・Phase 4）

| ファイル | 変更 |
|---|---|
| `src/lib/core/analytics.ts`（新） | 次の関数を追加した。 <br>・`weekReport`（月曜はじまり・前の週の同じ曜日まで／全体と比べる）<br>・`monthCompare`（先月・前年の同じ時期）<br>・`monthForecast`（月末の試算）<br>・`fixedReview`（見直し候補）<br>・`kurashiInsights` / `homeInsight`<br>・`periodByCategory` |
| `views/ReportView.tsx` | 振り返りを「週次｜月次｜年次」にした。 <br>・週次：期間・前の週との比較・8週の推移・カテゴリ・予定に紐づけた支出・気づき<br>・月次：同じ時期の比較・月末の試算・固定費の見直し候補・気づき |
| テスト | `analytics.test.ts`（26件） |

## Phase 3：週次・月次レポートの通知（コミット `4dd5d40`）

| ファイル | 変更 |
|---|---|
| `supabase/migrations/20261116010000_v45_report_push.sql`（新） | 次の3つを追加した。**新しいファイルのみ・本番未適用**。<br>・`push_subscriptions` の `daily_enabled` / `weekly_enabled` / `monthly_enabled`（週次・月次の初期値は false）<br>・`push_report_log`（端末・種類・期間ごとに1回）<br>・`kurashi_claim_report` |
| `src/lib/core/report-push.ts`（新） | いつ・どの期間を知らせるか（月曜〜水曜に前の週、1〜3日に前の月）。文面に金額なし。同じ日は1つにまとめる |
| `src/lib/server/handlers.ts`・`repo.ts`・`schemas.ts`・`src/app/api/push/prefs/route.ts`（新） | Cron に相乗り。端末ごとの設定 API（本人の端末だけ） |
| `src/lib/store/cloud.ts`・`push.ts`・`components/SecuritySettings.tsx` | 設定 → 通知に「毎朝・週次・月次」のチェック |
| テスト | `report-push.test.ts`（10件）、`rls_test.sql`（送信記録は本人から読めない） |

## Phase 4：検証と提出（このコミット）

- `scripts/e2e.mjs` に次の手順を足した（全27件）。
  - スクショから追加（2件のカード通知を端末内 OCR で読む）
  - 週次
  - カレンダーの絞り込み
  - V3-03（未取得の月）
- 月次の上のカードとカテゴリ別を「先月の同じ時期」との比較にした（今月の途中と先月の全体を比べない）。
- 比べる期間に記録がなければ比べない（0円とみなさない）。
- 週次グラフの8列と、文字200%・320px で横にはみ出さない規則。
- 画面写真 `SCREENSHOTS/`（`scripts/v45-screenshots.mjs`）。テストのログ `test-logs/`。
